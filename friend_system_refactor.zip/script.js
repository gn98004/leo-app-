
const state = {
  sent: [],
  received: [],
  friends: []
};

function render() {
  document.getElementById('sent').innerText = JSON.stringify(state.sent);
  document.getElementById('received').innerText = JSON.stringify(state.received);
  document.getElementById('friends').innerText = JSON.stringify(state.friends);
  document.getElementById('sentCount').innerText = state.sent.length;
  document.getElementById('receivedCount').innerText = state.received.length;
}

function addFriend(user) {
  if (state.sent.find(u => u.id === user.id)) return;
  state.sent.push(user);
  render();
}

function receiveFriend(user) {
  if (state.received.find(u => u.id === user.id)) return;
  state.received.push(user);
  render();
}

function acceptFriend(userId) {
  const idx = state.received.findIndex(u => u.id === userId);
  if (idx === -1) return;
  const user = state.received.splice(idx,1)[0];
  state.friends.push(user);
  render();
}

function initDemo(){
  window.testAdd = () => addFriend({id: Date.now(), name:"test"});
  window.testReceive = () => receiveFriend({id: Date.now(), name:"other"});
}
initDemo();
