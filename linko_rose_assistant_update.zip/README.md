# Linko Rose Assistant Update

- 儲值 / 安全中心改為玫瑰花束浮動助手
- 3 秒後自動縮小
- 可拖曳、可展開/收合
- 縮小圖示改為玫瑰花束風格
