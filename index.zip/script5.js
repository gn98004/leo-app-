
(function(){
  function hasVipAccess(){
    try {
      if (typeof hmIsVipEntitledActive === "function" && hmIsVipEntitledActive()) return true;
    } catch(e){}
    try {
      if (typeof hmGetVipLevel === "function" && hmGetVipLevel() > 0) return true;
    } catch(e){}
    return false;
  }

  function getDiaryFontPresetMeta(code){
    var map = {
      "zh-Hant": { label: "繁體中文", family: '"PingFang TC","Noto Sans TC","Microsoft JhengHei","Heiti TC",sans-serif' },
      "zh-Hans": { label: "簡體中文", family: '"PingFang SC","Noto Sans SC","Microsoft YaHei","Heiti SC",sans-serif' },
      "en": { label: "English", family: '"SF Pro Text","Inter","Helvetica Neue",Arial,sans-serif' },
      "ja": { label: "日本語", family: '"Hiragino Sans","Yu Gothic","Noto Sans JP","MS PGothic",sans-serif' }
    };
    return map[code] || map["zh-Hant"];
  }
  window.hmGetDiaryFontPresetMeta = getDiaryFontPresetMeta;

  function applyDiaryTypography(el, preset, sizePx){
    if (!el) return;
    var meta = getDiaryFontPresetMeta(preset);
    el.style.fontFamily = meta.family;
    if (sizePx) el.style.fontSize = String(sizePx) + "px";
    el.style.lineHeight = "1.75";
    el.style.wordBreak = "break-word";
  }

  function loadDiaries(){
    try {
      var raw = localStorage.getItem("hmMyDiaries");
      var arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch(e){
      return [];
    }
  }

  function saveDiaries(list){
    try { localStorage.setItem("hmMyDiaries", JSON.stringify(list || [])); } catch(e){}
  }

  function getDiaryLimit(){
    return hasVipAccess() ? 30 : 3;
  }

  function renderMyDiariesEnhanced(){
    var listEl = document.getElementById("myDiaryList");
    var limitTextEl = document.getElementById("myDiaryLimitText");
    if (!listEl || !limitTextEl) return;

    var diaries = loadDiaries();
    var limit = getDiaryLimit();
    if (hasVipAccess()) {
      limitTextEl.textContent = "目前已建立 " + diaries.length + " 則日記，VIP 身份最多可建立 " + limit + " 則；並可查看足跡名單。";
    } else {
      limitTextEl.textContent = "目前已建立 " + diaries.length + " 則日記，免費版最多可建立 " + limit + " 則；升級 VIP 後可到 30 則，並可查看足跡名單。";
    }

    listEl.innerHTML = "";
    if (!diaries.length) {
      var empty = document.createElement("div");
      empty.className = "diary-item";
      empty.innerHTML = '<div class="diary-date">尚未建立任何日記</div><div>可以寫幾句想讓別人看到的自我介紹或心情。</div>';
      listEl.appendChild(empty);
      return;
    }

    diaries.slice().reverse().forEach(function(diary){
      var item = document.createElement("div");
      item.className = "diary-item";

      var header = document.createElement("div");
      header.style.display = "flex";
      header.style.justifyContent = "space-between";
      header.style.alignItems = "center";

      var dateDiv = document.createElement("div");
      dateDiv.className = "diary-date";
      var time = diary.createdAt ? new Date(diary.createdAt) : new Date();
      var y = time.getFullYear();
      var m = String(time.getMonth() + 1).padStart(2, "0");
      var day = String(time.getDate()).padStart(2, "0");
      var hh = String(time.getHours()).padStart(2, "0");
      var mm = String(time.getMinutes()).padStart(2, "0");
      dateDiv.textContent = y + "-" + m + "-" + day + " " + hh + ":" + mm;

      var delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "btn btn-sm";
      delBtn.textContent = "刪除";
      delBtn.addEventListener("click", function(){
        if (!confirm("確定要刪除這則日記嗎？（Demo）")) return;
        var next = loadDiaries().filter(function(d){ return d.id !== diary.id; });
        saveDiaries(next);
        renderMyDiariesEnhanced();
      });

      header.appendChild(dateDiv);
      header.appendChild(delBtn);
      item.appendChild(header);
      var preset = diary.fontPreset || "zh-Hant";
if (diary.image) {
        var img = document.createElement("img");
        img.src = diary.image;
        img.alt = "日記圖片";
        img.style.maxWidth = (diary.imageSize || 100) + "%";
        img.style.borderRadius = "12px";
        img.style.marginTop = "6px";
        img.style.marginBottom = "8px";
        item.appendChild(img);
      }

      if (diary.text) {
        var textDiv = document.createElement("div");
        textDiv.innerHTML = String(diary.text).replace(/\n/g, "<br>");
        applyDiaryTypography(textDiv, preset, Math.max(Number(diary.textSize) || 22, 20));
        item.appendChild(textDiv);
      }

      listEl.appendChild(item);
    });
  }
  window.renderMyDiaries = renderMyDiariesEnhanced;

  function updateDiaryPreviewEnhanced(){
    var diaryInput = document.getElementById("myDiaryInput");
    var diaryImagePreview = document.getElementById("myDiaryImagePreview");
    var diaryImagePreviewImg = document.getElementById("myDiaryImagePreviewImg");
    var diaryTextPreview = document.getElementById("myDiaryTextPreview");
    var diaryImageSize = document.getElementById("myDiaryImageSize");
    var diaryImageSizeText = document.getElementById("myDiaryImageSizeText");
    var diaryTextSize = document.getElementById("myDiaryTextSize");
    var diaryTextSizeText = document.getElementById("myDiaryTextSizeText");
    if (!diaryInput || !diaryImagePreview || !diaryTextPreview || !diaryTextSize) return;

    var pending = window.__hmDiaryPendingImage || null;
    var hasImage = !!pending;
    var textValue = diaryInput.value.trim();
    var imageSize = Number(diaryImageSize && diaryImageSize.value) || 80;
    var textSize = Number(diaryTextSize.value) || 22;
    var preset = "zh-Hant";

    if (diaryImagePreview) diaryImagePreview.style.display = (hasImage || textValue) ? "block" : "none";
    if (diaryImagePreviewImg) {
      if (hasImage) {
        diaryImagePreviewImg.src = pending;
        diaryImagePreviewImg.style.display = "block";
        diaryImagePreviewImg.style.maxWidth = imageSize + "%";
      } else {
        diaryImagePreviewImg.removeAttribute("src");
        diaryImagePreviewImg.style.display = "none";
      }
    }
    if (diaryImageSizeText) diaryImageSizeText.textContent = "照片大小：" + imageSize + "%";
    if (diaryTextSizeText) diaryTextSizeText.textContent = "字體大小：" + textSize + "px";
    if (diaryInput) applyDiaryTypography(diaryInput, preset, Math.max(textSize, 18));
    if (diaryTextPreview) {
      applyDiaryTypography(diaryTextPreview, preset, textSize);
      diaryTextPreview.innerHTML = textValue
        ? String(textValue).replace(/\n/g, "<br>")
        : '<span style="color:#9ca3af; font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;">這裡會顯示日記文字預覽</span>';
    }
  }

  function bindDiaryInputsEnhanced(){
    if (window.__hmDiaryEnhanceBound) return;
    window.__hmDiaryEnhanceBound = true;

    var diaryInput = document.getElementById("myDiaryInput");
    var uploadInput = document.getElementById("myDiaryImageUpload");
    var cameraInput = document.getElementById("myDiaryImageCamera");
    var uploadBtn = document.getElementById("myDiaryImageUploadBtn");
    var cameraBtn = document.getElementById("myDiaryImageCameraBtn");
    var imageSize = document.getElementById("myDiaryImageSize");
    var textSize = document.getElementById("myDiaryTextSize");

    if (textSize && !textSize.value) textSize.value = "22";
    if (textSize) textSize.value = textSize.value || "22";

    function bindFileInput(input){
      if (!input || input.dataset.hmEnhanceBind === "1") return;
      input.dataset.hmEnhanceBind = "1";
      input.addEventListener("change", function(e){
        var file = e.target.files && e.target.files[0];
        if (!file) {
          window.__hmDiaryPendingImage = null;
          updateDiaryPreviewEnhanced();
          return;
        }
        var reader = new FileReader();
        reader.onload = function(ev){
          window.__hmDiaryPendingImage = ev && ev.target ? ev.target.result : null;
          updateDiaryPreviewEnhanced();
        };
        reader.readAsDataURL(file);
      });
    }

    if (uploadBtn && uploadInput && !uploadBtn.dataset.hmEnhanceBind) {
      uploadBtn.dataset.hmEnhanceBind = "1";
      uploadBtn.addEventListener("click", function(){ uploadInput.click(); });
    }
    if (cameraBtn && cameraInput && !cameraBtn.dataset.hmEnhanceBind) {
      cameraBtn.dataset.hmEnhanceBind = "1";
      cameraBtn.addEventListener("click", function(){ cameraInput.click(); });
    }

    bindFileInput(uploadInput);
    bindFileInput(cameraInput);

    [diaryInput, imageSize, textSize].forEach(function(el){
      if (!el || el.dataset.hmEnhanceInputBind === "1") return;
      el.dataset.hmEnhanceInputBind = "1";
      el.addEventListener("input", updateDiaryPreviewEnhanced);
      el.addEventListener("change", updateDiaryPreviewEnhanced);
    });

    updateDiaryPreviewEnhanced();

    var addBtn = document.getElementById("myDiaryAddBtn");
    if (addBtn && addBtn.dataset.hmEnhanceCapture !== "1") {
      addBtn.dataset.hmEnhanceCapture = "1";
      addBtn.addEventListener("click", async function(e){
        e.preventDefault();
        e.stopImmediatePropagation();

        var diaryInput = document.getElementById("myDiaryInput");
        var uploadInput = document.getElementById("myDiaryImageUpload");
        var cameraInput = document.getElementById("myDiaryImageCamera");
        var imageSize = document.getElementById("myDiaryImageSize");
        var textSize = document.getElementById("myDiaryTextSize");
        var publicCb = document.getElementById("myDiaryIsPublic");

        var text = diaryInput ? diaryInput.value.trim() : "";
        var image = window.__hmDiaryPendingImage || null;
        if (!text && !image) {
          alert("請先輸入日記內容或選擇一張圖片。");
          return;
        }

        var list = loadDiaries();
        var limit = getDiaryLimit();
        if (list.length >= limit) {
          alert("目前最多只能建立 " + limit + " 則日記。升級 VIP 後可擴充到 30 則。");
          return;
        }

        var now = new Date();
        var diary = {
          id: now.getTime(),
          text: text,
          image: image,
          imageSize: Number(imageSize && imageSize.value) || 80,
          textSize: Number(textSize && textSize.value) || 22,
          fontPreset: "zh-Hant",
          createdAt: now.toISOString()
        };

        list.push(diary);
        saveDiaries(list);

        try {
          var isPublic = publicCb ? !!publicCb.checked : true;
          if (typeof hmInsertDiaryToSupabase === "function") {
            if (isPublic && !text && !image) {
              alert("公開日記建議至少填寫一些文字，否則對外顯示會是空白。");
            } else {
              var sbRes = await hmInsertDiaryToSupabase(text || "", isPublic, image || null);
              if (sbRes && sbRes.ok) {
                diary.sb_id = sbRes.id || null;
                diary.is_public = isPublic;
                saveDiaries(list);
              }
            }
          }
        } catch(err) {
          console.warn(err);
        }

        if (diaryInput) diaryInput.value = "";
        if (uploadInput) uploadInput.value = "";
        if (cameraInput) cameraInput.value = "";
        if (textSize) textSize.value = "22";
        window.__hmDiaryPendingImage = null;
        updateDiaryPreviewEnhanced();
        renderMyDiariesEnhanced();
      }, true);
    }
  }

  function isUuidLike(v){
    return typeof v === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
  }

  function getRelativeVisitText(dateStr, fallback){
    if (!dateStr) return fallback || "最近來看過你";
    try {
      var ms = new Date(dateStr).getTime();
      if (!isFinite(ms)) return fallback || "最近來看過你";
      var diff = Math.max(0, Date.now() - ms);
      var mins = Math.floor(diff / 60000);
      if (mins < 60) return mins <= 1 ? "1 分鐘前看過你" : (mins + " 分鐘前看過你");
      var hrs = Math.floor(mins / 60);
      if (hrs < 24) return hrs + " 小時前看過你";
      var days = Math.floor(hrs / 24);
      return days + " 天前看過你";
    } catch(e){
      return fallback || "最近來看過你";
    }
  }

  function buildFootprintEntries(){
    var result = [];
    try {
      if (typeof people !== "undefined" && Array.isArray(people)) {
        people.slice(0, 6).forEach(function(p, idx){
          if (!p || !p.id) return;
          result.push({
            id: String(p.id),
            name: p.name || "未命名",
            region: p.region || "未設定",
            avatar: p.avatar || p.avatar_url || ("data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" + (360 + idx)),
            sub: getRelativeVisitText(p.last_seen_at, "最近看過你")
          });
        });
      }
    } catch(e){}

    if (result.length) return result;

    return [
      { id: "", name: "小茵", region: "台北", avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E", sub: "2 小時前看過你" },
      { id: "", name: "Ken", region: "高雄", avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E", sub: "昨天晚上路過你的檔案" },
      { id: "", name: "Rin", region: "新北", avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E", sub: "3 天前拜訪" }
    ];
  }

  function renderFootprints(){
    var listEl = document.getElementById("hmFootprintList");
    var hintEl = document.getElementById("hmFootprintHint");
    if (!listEl || !hintEl) return;

    var vip = hasVipAccess();
    var entries = buildFootprintEntries();

    hintEl.textContent = vip
      ? "VIP 已解鎖：可查看完整足跡、直接查看對方檔案，並從這裡加好友。"
      : "此功能限 VIP 使用。開通後可查看完整足跡、直接點進對方檔案並從這裡加好友。";

    listEl.innerHTML = "";
    entries.forEach(function(item, idx){
      var row = document.createElement("div");
      row.className = "footprint-item" + (vip ? "" : " locked");
      var displayName = vip ? item.name : ((item.name || "訪客").charAt(0) + "＊＊");
      var displaySub = vip ? ("來自 " + item.region + " · " + item.sub) : "開通 VIP 後可查看完整名稱與拜訪時間";
      row.innerHTML = ''
        + '<div style="display:flex; align-items:center; min-width:0; flex:1;">'
        + '  <div class="footprint-avatar"><img src="' + item.avatar + '" alt="' + displayName + '"/></div>'
        + '  <div class="footprint-main">'
        + '    <div class="footprint-name">' + displayName + '</div>'
        + '    <div class="footprint-sub">' + displaySub + '</div>'
        + (vip ? '' : '<div class="footprint-lock">VIP 解鎖完整足跡</div>')
        + '  </div>'
        + '</div>'
        + '<div class="footprint-actions">'
        + '  <button class="footprint-btn primary" type="button" data-footprint-view="' + (item.id || '') + '">' + (vip ? '查看' : 'VIP') + '</button>'
        + '  <button class="footprint-btn" type="button" data-footprint-add="' + (item.id || '') + '">' + (vip ? '加好友' : '解鎖') + '</button>'
        + '</div>';
      listEl.appendChild(row);
    });
  }

  function openVipFlow(){
    try {
      if (typeof hmVip60HandleSubscribeClick === "function") {
        hmVip60HandleSubscribeClick();
        return;
      }
    } catch(e){}
    alert("VIP 功能已準備好，但目前找不到開通流程。");
  }

  function showVipShopDetail(){
    var modal = document.getElementById("hm-shop-modal");
    var box = document.getElementById("hm-shop-detail");
    var title = document.getElementById("hm-shop-detail-title");
    var text = document.getElementById("hm-shop-detail-text");
    var primary = document.getElementById("hm-shop-primary-btn");
    var secondary = document.getElementById("hm-shop-secondary-btn");
    if (!modal || !box || !title || !text || !primary || !secondary) return;
    modal.style.display = "flex";
    box.classList.add("show");
    title.textContent = "開通VIP";
    text.textContent = "VIP 150TW。開通後可直接觀看他人完整相簿、不需先看廣告，並可查看誰來看過你、從足跡直接加好友，日記上限也會從 3 則提升到 30 則。";
    primary.textContent = "選擇 VIP";
    primary.onclick = function(){ openVipFlow(); };
    secondary.textContent = "稍後";
    secondary.onclick = function(){
      if (typeof hmCloseShopModal === "function") hmCloseShopModal();
      else modal.style.display = "none";
    };
  }

  function refreshVipMarketingTexts(){
    var desc = document.querySelector(".vip60-desc");
    if (desc) desc.textContent = "✅ 相簿免廣告全開　✅ 查看誰來看過我　✅ 從足跡直接加好友　✅ 日記上限 30 則";
    var note = document.getElementById("vip60NoteText");
    var price = 150;
    try { if (typeof hmVip60GetPriceTwd === "function") price = hmVip60GetPriceTwd(); } catch(e){}
    if (note) {
      var base = 'VIP（月費 NT$' + price + '）特權：相簿免廣告全開、查看誰來看過我、可從足跡直接加好友、我的日記上限提升到 30 則。';
      var devEnabled = false;
      try { devEnabled = typeof hmVip60IsDevGrantEnabled === "function" && hmVip60IsDevGrantEnabled(); } catch(e){}
      if (devEnabled) note.innerHTML = base + ' 目前為測試模式，可直接開通/取消 VIP。';
      else note.innerHTML = base + ' Web Demo 暫不支援實際付款；正式上架後可直接串接 Apple / Google 內購。';
    }
    var shopSub = document.querySelector('[data-shop-item="vip"] .hm-shop-sub');
    if (shopSub) shopSub.textContent = "相簿全開＋足跡解鎖";
    var shopNote = document.querySelector(".hm-shop-note");
    if (shopNote) shopNote.textContent = "其他商品之後開放。玫瑰來源保留：儲值、收禮、每日登入；VIP 含相簿全開、足跡查看與日記擴充。";
  }

  document.addEventListener("click", function(e){
    var vipCard = e.target && e.target.closest ? e.target.closest('[data-shop-item="vip"]') : null;
    if (vipCard) {
      e.preventDefault();
      e.stopImmediatePropagation();
      showVipShopDetail();
      return;
    }

    var viewBtn = e.target && e.target.closest ? e.target.closest("[data-footprint-view]") : null;
    if (viewBtn) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (!hasVipAccess()) {
        openVipFlow();
        return;
      }
      var id = viewBtn.getAttribute("data-footprint-view") || "";
      if (id && typeof openProfileDetail === "function" && typeof getPersonById === "function" && getPersonById(id)) {
        openProfileDetail(id);
      } else {
        alert("目前這筆足跡還沒有完整個人檔案可開啟。等你串上真人資料後，這裡就能直接進檔案。");
      }
      return;
    }

    var addBtn = e.target && e.target.closest ? e.target.closest("[data-footprint-add]") : null;
    if (addBtn) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (!hasVipAccess()) {
        openVipFlow();
        return;
      }
      var id2 = addBtn.getAttribute("data-footprint-add") || "";
      if (id2 && isUuidLike(id2) && typeof hmAddFriend === "function") {
        hmAddFriend(id2);
      } else {
        alert("目前這筆足跡尚未綁定真人帳號 ID；等你把真人訪客資料接進來後，這裡就能直接送好友申請。");
      }
      return;
    }
  }, true);

  function wrapVipUiRefresh(){
    if (window.__hmVipUiWrapped) return;
    window.__hmVipUiWrapped = true;
    var oldUpdate = (typeof hmUpdateVipUI === "function") ? hmUpdateVipUI : null;
    window.hmUpdateVipUI = function(){
      var r = oldUpdate ? oldUpdate.apply(this, arguments) : undefined;
      refreshVipMarketingTexts();
      renderFootprints();
      renderMyDiariesEnhanced();
      return r;
    };
    var oldLoadPeople = (typeof hmLoadPeopleFromSupabase === "function") ? hmLoadPeopleFromSupabase : null;
    if (oldLoadPeople) {
      window.hmLoadPeopleFromSupabase = async function(){
        var r = await oldLoadPeople.apply(this, arguments);
        try { renderFootprints(); } catch(e){}
        return r;
      };
    }
  }

  function initAll(){
    bindDiaryInputsEnhanced();
    wrapVipUiRefresh();
    refreshVipMarketingTexts();
    renderMyDiariesEnhanced();
    renderFootprints();
    updateDiaryPreviewEnhanced();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll);
  } else {
    initAll();
  }
  window.addEventListener("load", function(){
    setTimeout(function(){
      try { initAll(); } catch(e){}
    }, 0);
  });
})();
