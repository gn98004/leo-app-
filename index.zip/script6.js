
(function(){
  const KEY = "hmFakeBillingStateV2";
  const DAY = 24 * 60 * 60 * 1000;
  const PRODUCT_MAP = {
    rose_10: { type: "rose", roses: 10, label: "10 朵玫瑰" },
    rose_50: { type: "rose", roses: 50, label: "50 朵玫瑰" },
    rose_120: { type: "rose", roses: 120, label: "120 朵玫瑰" },
    vip_monthly: { type: "vip", days: 30, label: "VIP 30 天" },
    vip_yearly: { type: "vip", days: 365, label: "VIP 365 天" }
  };

  function loadState() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return {
            roses: Math.max(0, parseInt(parsed.roses || 0, 10) || 0),
            vip_until: Math.max(0, parseInt(parsed.vip_until || 0, 10) || 0),
            updated_at: parsed.updated_at || null,
            last_product_id: parsed.last_product_id || null,
            last_purchase_source: parsed.last_purchase_source || "fake"
          };
        }
      }
    } catch (e) {}
    return { roses: 20, vip_until: 0, updated_at: null, last_product_id: null, last_purchase_source: "fake" };
  }

  let state = loadState();

  function saveState() {
    state.updated_at = new Date().toISOString();
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  }

  function isVip() {
    return Number(state.vip_until || 0) > Date.now();
  }

  function formatTime(ms) {
    if (!ms) return "未開通";
    try {
      const d = new Date(ms);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return y + "-" + m + "-" + day;
    } catch (e) {
      return "未開通";
    }
  }

  function syncIntoApp() {
    try { localStorage.setItem("hmVipLevel", isVip() ? "1" : "0"); } catch (e) {}

    try {
      if (typeof window.hmMonetizationCache === "object" && window.hmMonetizationCache) {
        window.hmMonetizationCache.entitlements = window.hmMonetizationCache.entitlements || {};
        window.hmMonetizationCache.entitlements.vip_active = isVip();
        window.hmMonetizationCache.entitlements.vip_tier = isVip() ? "vip" : null;
        window.hmMonetizationCache.entitlements.vip_until = isVip() ? new Date(state.vip_until).toISOString() : null;
        if (typeof window.hmMonetizationSaveLocal === "function") window.hmMonetizationSaveLocal();
      }
    } catch (e) {}

    try {
      window.hmRewardCache = window.hmRewardCache || {};
      window.hmRewardCache.inventory = { roses: state.roses, gifts: 0 };
      window.hmRewardCache.lastFetchAt = Date.now();
    } catch (e) {}

    try {
      const statusEl = document.getElementById("vip60StatusText");
      if (statusEl) statusEl.textContent = isVip() ? ("VIP：已開通（到期日 " + formatTime(state.vip_until) + "）") : "VIP：未開通";
    } catch (e) {}

    try {
      const noteEl = document.getElementById("vip60NoteText");
      if (noteEl) noteEl.textContent = isVip()
        ? ("目前使用可切換購買橋接層測試中，到期日：" + formatTime(state.vip_until) + "。回家後可直接把 Google Play 回傳接進這層。")
        : "目前使用可切換購買橋接層測試流程；回家後可直接接 Google Play Billing。";
    } catch (e) {}

    try {
      const badge = document.getElementById("myVipBadge");
      if (badge) {
        badge.style.display = isVip() ? "" : "none";
        badge.textContent = isVip() ? "VIP1" : "";
      }
    } catch (e) {}

    try {
      document.querySelectorAll(".hm-fake-roses-count").forEach(function(el){ el.textContent = String(state.roses); });
      document.querySelectorAll(".hm-fake-vip-status").forEach(function(el){
        el.textContent = isVip() ? ("已開通，至 " + formatTime(state.vip_until)) : "未開通";
      });
    } catch (e) {}

    try {
      const btn = document.getElementById("vip60SubscribeBtn");
      if (btn) btn.textContent = isVip() ? "VIP 已開通" : "開通 VIP";
    } catch (e) {}

    try {
      const inv = document.getElementById("hm-gift-inventory");
      if (inv) inv.textContent = "🌹 玫瑰：" + state.roses;
      const mood = document.getElementById("moodRoseCount");
      if (mood) mood.textContent = String(state.roses);
    } catch (e) {}

    try {
      const bridgeModeEl = document.getElementById("hm-billing-bridge-mode");
      if (bridgeModeEl && window.LinkoPurchaseBridge) {
        bridgeModeEl.textContent = window.LinkoPurchaseBridge.mode === "google-play" ? "Google Play 橋接" : "本機測試橋接";
      }
    } catch (e) {}

    try { if (typeof window.hmUpdateVipUI === "function") window.hmUpdateVipUI(); } catch (e) {}
    try { if (typeof window.renderMyAlbum === "function") window.renderMyAlbum(); } catch (e) {}
    try { if (typeof window.renderMyDiaries === "function") window.renderMyDiaries(); } catch (e) {}
    try { if (typeof window.renderFootprints === "function") window.renderFootprints(); } catch (e) {}
    try { if (typeof window.initMoodSquare === "function") window.initMoodSquare(); } catch (e) {}
    try { if (typeof window.hmGiftRenderInventory === "function") window.hmGiftRenderInventory(); } catch (e) {}
  }

  function persistAndRefresh() {
    saveState();
    syncIntoApp();
  }

  function applyProduct(productId, source) {
    const product = PRODUCT_MAP[String(productId || "")];
    if (!product) throw new Error("未知商品：" + productId);

    if (product.type === "rose") {
      state.roses += product.roses;
    } else if (product.type === "vip") {
      const base = Math.max(Date.now(), Number(state.vip_until || 0));
      state.vip_until = base + product.days * DAY;
    }

    state.last_product_id = String(productId);
    state.last_purchase_source = source || "fake";
    persistAndRefresh();
    return {
      ok: true,
      productId: String(productId),
      source: state.last_purchase_source,
      state: Object.assign({}, state),
      entitlements: {
        roses: state.roses,
        vip_active: isVip(),
        vip_until: isVip() ? new Date(state.vip_until).toISOString() : null
      }
    };
  }

  function fakePurchase(productId) {
    const result = applyProduct(productId, "fake");
    const product = PRODUCT_MAP[String(productId || "")];
    if (product && product.type === "rose") {
      alert("測試版：已加入 " + product.roses + " 朵玫瑰。");
    } else if (product && product.type === "vip") {
      alert("測試版：VIP 已開通 " + product.days + " 天。");
    }
    return result;
  }

  function resetFakeBilling() {
    if (!confirm("要清空目前這台電腦上的測試玫瑰與 VIP 狀態嗎？")) return;
    state = { roses: 20, vip_until: 0, updated_at: null, last_product_id: null, last_purchase_source: "fake" };
    persistAndRefresh();
  }

  window.LinkoPurchaseBridge = {
    mode: "fake",
    products: PRODUCT_MAP,
    requestPurchase: async function(productId, meta) {
      const pid = String(productId || "");
      if (typeof window.AndroidBillingBridge !== "undefined"
          && window.AndroidBillingBridge
          && typeof window.AndroidBillingBridge.purchase === "function") {
        this.mode = "google-play";
        syncIntoApp();
        return window.AndroidBillingBridge.purchase(pid, JSON.stringify(meta || {}));
      }
      this.mode = "fake";
      return fakePurchase(pid);
    },
    applyPurchaseResult: function(productId, payload) {
      const pid = String(productId || (payload && (payload.productId || payload.product_id)) || "");
      return applyProduct(pid, "google-play");
    },
    grantLocalProduct: function(productId) {
      return fakePurchase(productId);
    },
    getState: function() {
      return Object.assign({}, state, { vip_active: isVip() });
    },
    sync: function() {
      syncIntoApp();
      return this.getState();
    },
    reset: resetFakeBilling
  };

  window.linkoOnGooglePlayPurchase = function(payload) {
    try {
      const data = typeof payload === "string" ? JSON.parse(payload) : (payload || {});
      if (!data || !(data.productId || data.product_id)) throw new Error("缺少 productId");
      return window.LinkoPurchaseBridge.applyPurchaseResult(data.productId || data.product_id, data);
    } catch (e) {
      alert("Google Play 回傳資料格式錯誤：" + (e && e.message ? e.message : e));
      return { ok: false, reason: e && e.message ? e.message : "bridge_error" };
    }
  };

  // 對接現有函式：先讓「送玫瑰 / VIP UI」能在公司電腦跑起來
  window.hmBackendGetInventory = async function() {
    return { roses: state.roses, gifts: 0 };
  };

  window.hmGiftRenderInventory = async function() {
    const invEl = document.getElementById("hm-gift-inventory");
    if (invEl) invEl.textContent = "🌹 玫瑰：" + state.roses;
  };

  window.hmOpenGiftModal = async function() {
    const modal = document.getElementById("hm-gift-modal");
    if (!modal) return;
    const subEl = document.getElementById("hm-gift-sub");
    const hintEl = document.getElementById("hm-gift-hint");
    const roseBtn = document.getElementById("hm-send-rose-btn");
    const name = (window.hmGiftTarget && window.hmGiftTarget.name) ? window.hmGiftTarget.name : "";
    if (subEl) subEl.textContent = name ? ("送給：" + name) : "選擇要送出的玫瑰";
    if (hintEl) hintEl.textContent = state.roses > 0 ? "點選下方按鈕即可送出玫瑰。" : "你的玫瑰不足，先到商店補貨。";
    if (roseBtn) roseBtn.disabled = state.roses <= 0;
    await window.hmGiftRenderInventory();
    modal.style.display = "flex";
  };

  window.hmSendGift = async function(kind) {
    const hintEl = document.getElementById("hm-gift-hint");
    if (state.roses <= 0) {
      if (hintEl) hintEl.textContent = "玫瑰不足，請先到商店補貨。";
      return;
    }
    state.roses -= 1;
    persistAndRefresh();
    try {
      const recv = document.getElementById("hm-recv-roses");
      if (recv) {
        const oldText = recv.textContent || "🌹 0";
        const oldNum = parseInt(String(oldText).replace(/[^\d]/g, "") || "0", 10) || 0;
        recv.textContent = "🌹 " + (oldNum + 1);
      }
    } catch (e) {}
    if (hintEl) hintEl.textContent = "已送出 🌹 玫瑰 x1";
    setTimeout(function(){
      const modal = document.getElementById("hm-gift-modal");
      if (modal) modal.style.display = "none";
    }, 350);
  };

  function bindUi() {
    document.querySelectorAll("[data-fake-pack]").forEach(function(btn){
      btn.addEventListener("click", function(){
        const roses = String(btn.getAttribute("data-fake-pack") || "");
        const pid = btn.getAttribute("data-product-id") || ("rose_" + roses);
        window.LinkoPurchaseBridge.requestPurchase(pid);
      });
    });
    document.querySelectorAll("[data-fake-vip]").forEach(function(btn){
      btn.addEventListener("click", function(){
        const days = String(btn.getAttribute("data-fake-vip") || "");
        const pid = btn.getAttribute("data-product-id") || (days === "365" ? "vip_yearly" : "vip_monthly");
        window.LinkoPurchaseBridge.requestPurchase(pid);
      });
    });
    document.querySelectorAll("[data-fake-reset]").forEach(function(btn){
      btn.addEventListener("click", function(){ resetFakeBilling(); });
    });

    const vipBtn = document.getElementById("vip60SubscribeBtn");
    if (vipBtn && !vipBtn.dataset.fakeBound) {
      vipBtn.dataset.fakeBound = "1";
      vipBtn.addEventListener("click", function(e){
        e.preventDefault();
        window.LinkoPurchaseBridge.requestPurchase("vip_monthly", { source: "vip60SubscribeBtn" });
      }, true);
    }
  }

  function initFakeBilling() {
    bindUi();
    persistAndRefresh();
    try {
      const stamp = document.getElementById("hm-build-stamp");
      if (stamp && stamp.textContent.indexOf("BILLING-BRIDGE") === -1) {
        stamp.textContent = (stamp.textContent || "BUILD") + " · BILLING-BRIDGE";
      }
    } catch (e) {}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initFakeBilling);
  } else {
    initFakeBilling();
  }
  window.addEventListener("load", function(){
    setTimeout(function(){
      try { initFakeBilling(); } catch (e) {}
    }, 50);
  });
})();
