-->

<div id="hm-sb-mini-panel" style="display:none; position:fixed; right:12px; bottom:86px; z-index:9999; font-family:inherit;">
  <button id="hm-sb-mini-toggle" class="hm-btn-outline" type="button" style="background:#fff; box-shadow:0 6px 18px rgba(0,0,0,0.12);">Supabase 設定</button>
  <div id="hm-sb-mini-body" style="display:none; margin-top:8px; width:320px; background:#ffffff; border:1px solid #e5e7eb; border-radius:14px; padding:12px; box-shadow:0 10px 22px rgba(0,0,0,0.14);">
    <div style="font-weight:700; margin-bottom:8px;">Supabase Test Panel</div>
    <div style="font-size:12px; color:#6b7280; margin-bottom:10px;">填入 SB_URL / SB_ANON_KEY 後按「儲存」。</div>
    <div style="display:flex; flex-direction:column; gap:8px;">
      <input id="hm-sb-url" type="text" placeholder="SUPABASE_URL (https://xxxx.supabase.co)" style="padding:10px; border:1px solid #e5e7eb; border-radius:10px;">
      <textarea id="hm-sb-key" placeholder="ANON_KEY（很長一串）" rows="3" style="padding:10px; border:1px solid #e5e7eb; border-radius:10px;"></textarea>
      <div style="display:flex; gap:8px;">
        <button id="hm-sb-save" class="btn btn-primary btn-sm" type="button" style="flex:1;">儲存</button>
        <button id="hm-sb-close" class="btn btn-sm" type="button" style="flex:1;">關閉</button>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  const isDev = new URLSearchParams(location.search).get("dev") === "1";
  const panel = document.getElementById("hm-sb-mini-panel");
  if (!isDev) { if (panel) panel.remove(); return; }
  if (panel) panel.style.display = "block";

  const t = document.getElementById("hm-sb-mini-toggle");
  const body = document.getElementById("hm-sb-mini-body");
  const urlEl = document.getElementById("hm-sb-url");
  const keyEl = document.getElementById("hm-sb-key");
  const save = document.getElementById("hm-sb-save");
  const close = document.getElementById("hm-sb-close");
  if (!t || !body) return;
  t.addEventListener("click", ()=>{
    body.style.display = (body.style.display==="none"||!body.style.display) ? "block" : "none";
    try { urlEl.value = localStorage.getItem("SB_URL") || ""; keyEl.value = localStorage.getItem("SB_ANON_KEY") || ""; } catch(e){}
  });
  if (close) close.addEventListener("click", ()=>{ body.style.display="none"; });
  if (save) save.addEventListener("click", ()=>{
    try { localStorage.setItem("SB_URL", (urlEl.value||"").trim()); localStorage.setItem("SB_ANON_KEY",(keyEl.value||"").trim()); } catch(e){}
    alert("已儲存 Supabase 連線設定。你可按「巧遇 → 換一批」或重新整理頁面。");
  });
})()

/* ================== Daily Reward / Sign-in System (Supabase Backend) ================== */
/*
  後端化重點：
  - inventories / reward_claims / monthly_bonuses 由 Supabase/Postgres 作為權威資料
  - 每日簽到：supabase.rpc('claim_daily_reward')
  - 道具消耗（送禮/發文扣玫瑰）：supabase.rpc('consume_item')
  - 本機 localStorage 僅用於「同一天自動彈窗只跳一次」與「一次性遷移」
*/

const HM_REWARD_TZ = "Asia/Taipei";
const HM_REWARD_LAST_SHOWN_PREFIX = "hmRewardLastShown::";
const HM_REWARD_MIGRATED_PREFIX = "hmRewardMigrated::";

let hmRewardCache = {
  uid: "",
  email: "",
  inventory: { roses: 0, gifts: 0 },
  month: {
    ym: "",
    daysInMonth: 0,
    claimedDays: {},    // { [day:number]: "rose"|"gift" }
    bonusGranted: false
  },
  lastFetchAt: 0
};

function hmRewardNowIso() {
  try { return new Date().toISOString(); } catch (e) { return ""; }
}

function hmRewardTzYmd() {
  // 以 Asia/Taipei 為切日基準
  const now = new Date();
  const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: HM_REWARD_TZ, year: "numeric", month: "2-digit", day: "2-digit" });
  const ymd = fmt.format(now); // YYYY-MM-DD
  const parts = ymd.split("-");
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  const d = parseInt(parts[2], 10);
  const ym = parts[0] + parts[1]; // YYYYMM
  const daysInMonth = (y && m) ? new Date(y, m, 0).getDate() : 30;
  return { ymd, ym, day: d, year: y, month: m, daysInMonth };
}

function hmRewardComputeForDay(dayNum) {
  const d = parseInt(dayNum || "0", 10);
  if (!Number.isFinite(d) || d <= 0) return { type: "rose", qty: 1, label: "🌹 玫瑰 x1" };
  if (d === 1 || (d % 2 === 1)) return { type: "rose", qty: 1, label: "🌹 玫瑰 x1" };
  return { type: "gift", qty: 2, label: "🎁 小禮物 x2" };
}

function hmRewardFmtInventory(inv) {
  const r = inv && typeof inv.roses === "number" ? inv.roses : 0;
  const g = inv && typeof inv.gifts === "number" ? inv.gifts : 0;
  return `🌹 玫瑰：${r} ｜ 🎁 小禮物：${g}`;
}

async function hmBackendGetClientAndUser() {
  const cli = await (typeof hmGetSupabaseClient === "function" ? hmGetSupabaseClient() : null);
  if (!cli) return { ok: false, reason: "尚未設定 Supabase 連線", cli: null, uid: "", email: "" };

  const s = await cli.auth.getSession();
  const user = s && s.data && s.data.session && s.data.session.user ? s.data.session.user : null;
  const uid = user && user.id ? user.id : "";
  const email = user && user.email ? (user.email + "").trim().toLowerCase() : "";
  if (!uid) return { ok: false, reason: "尚未綁定 Email / 登入", cli, uid: "", email: "" };
  return { ok: true, reason: "", cli, uid, email };
}


// ================== Monetization scaffold (Ads + VIP Entitlements) ==================
// 這些函式只負責：
//  - 登入後拉取後端權益/解鎖狀態（get_monetization_state）
//  - 相簿解鎖寫入後端（grant_album_unlock）
//  - VIP 每日加贈玫瑰（apply_vip_daily_roses，若沒有 VIP 會自動回 0）
// 若你尚未在 Supabase 執行 SUPABASE_MONETIZATION_SETUP.sql：
//  - 前端會自動降級，不影響既有功能。

async function hmBackendFetchMonetizationState(opts) {
  try {
    opts = opts || {};
    if (typeof hmMonetizationLoadLocal === 'function') hmMonetizationLoadLocal();

    const ctx = await hmBackendGetClientAndUser();
    if (!ctx || !ctx.ok) {
      return { ok: false, reason: (ctx && ctx.reason) ? ctx.reason : 'not_authenticated' };
    }

    const env = (hmMonetizationCache && hmMonetizationCache.env) ? hmMonetizationCache.env : 'prod';
    const platform = (hmMonetizationCache && hmMonetizationCache.platform) ? hmMonetizationCache.platform : 'web';

    const res = await ctx.cli.rpc('get_monetization_state', { p_env: env, p_platform: platform });
    if (res && res.error) {
      // SQL 尚未部署時會走這裡，直接降級即可
      return { ok: false, reason: res.error.message || 'rpc_error', error: res.error };
    }

    const data = res ? res.data : null;
    if (data && data.ok) {
      if (!hmMonetizationCache) {
        hmMonetizationCache = { env: env, platform: platform, config: {}, entitlements: null, unlocks: {} };
      }
      hmMonetizationCache.env = env;
      hmMonetizationCache.platform = platform;
      hmMonetizationCache.config = data.config || {};
      hmMonetizationCache.entitlements = data.entitlements || null;
      hmMonetizationCache.unlocks = data.unlocks || {};
      if (typeof hmMonetizationSaveLocal === 'function') hmMonetizationSaveLocal();

      // 讓 UI 立即反映（VIP/相簿解鎖）
      try { hmUpdateVipUI(); } catch (e) {}
      try { renderMyAlbum(); } catch (e) {}
    }

    return data || { ok: false, reason: 'empty' };
  } catch (e) {
    return { ok: false, reason: 'exception', error: e };
  }
}

async function hmMonetizationBootstrap() {
  try {
    // 1) 拉取後端狀態（若無 SQL 則降級）
    await hmBackendFetchMonetizationState({});

    // 2) 可選：VIP 每日加贈玫瑰（沒有 VIP 或 quota=0 時不會有任何變動）
    const ctx = await hmBackendGetClientAndUser();
    if (ctx && ctx.ok) {
      try { await ctx.cli.rpc('apply_vip_daily_roses'); } catch (e) {}

    // 2.5) 同步庫存（VIP 每日加贈玫瑰需要讀回 inventories）
    try { if (typeof hmSyncInventoryCache === 'function') await hmSyncInventoryCache(); } catch (e) {}
    try { if (typeof hmRewardRenderUI === 'function') await hmRewardRenderUI({ force: true }); } catch (e) {}

    }

    // 3) 重新拉取一次（確保今日加贈後 UI 同步）
    await hmBackendFetchMonetizationState({});
  } catch (e) {
    // no-op
  }
}

async function hmBackendGrantAlbumUnlock(minutes) {
  try {
    const ctx = await hmBackendGetClientAndUser();
    if (!ctx || !ctx.ok) return { ok: false, reason: (ctx && ctx.reason) ? ctx.reason : 'not_authenticated' };

    const env = (hmMonetizationCache && hmMonetizationCache.env) ? hmMonetizationCache.env : 'prod';
    const platform = (hmMonetizationCache && hmMonetizationCache.platform) ? hmMonetizationCache.platform : 'web';
    const mins = parseInt(minutes || '20', 10) || 20;

    const res = await ctx.cli.rpc('grant_album_unlock', {
      p_minutes: mins,
      p_source: 'ad',
      p_ad_unit_key: 'album_unlock_rewarded',
      p_env: env,
      p_platform: platform
    });

    if (res && res.error) {
      return { ok: false, reason: res.error.message || 'rpc_error', error: res.error };
    }

    const data = res ? res.data : null;
    if (data && data.ok) {
      // 更新本機快取（避免等待下一次 bootstrap）
      if (hmMonetizationCache) {
        if (!hmMonetizationCache.unlocks) hmMonetizationCache.unlocks = {};
        hmMonetizationCache.unlocks.album_unlock_until = data.album_unlock_until;
        if (typeof hmMonetizationSaveLocal === 'function') hmMonetizationSaveLocal();
      }

      // 同步 localStorage unlockUntil（兼容舊版 UI 判斷）
      try {
        const ms = Date.parse(String(data.album_unlock_until || ''));
        if (!isNaN(ms) && ms > 0) {
          const localRaw = localStorage.getItem('hmAlbumUnlockUntil');
          const localMs = parseInt(localRaw || '0', 10) || 0;
          if (ms > localMs) localStorage.setItem('hmAlbumUnlockUntil', String(ms));
        }
      } catch (e) {}

      try { renderMyAlbum(); } catch (e) {}
    }

    return data || { ok: false, reason: 'empty' };
  } catch (e) {
    return { ok: false, reason: 'exception', error: e };
  }
}


async function hmBackendEnsureInventoryRow(cli, uid) {
  try {
    // 只做 insert，若已存在就忽略（避免 upsert 觸發 update policy）
    const ins = await cli.from("inventories").insert({ user_id: uid, roses: 0, gifts: 0 });
    if (ins && ins.error) {
      const msg = String(ins.error.message || "");
      if (!msg.toLowerCase().includes("duplicate") && !msg.toLowerCase().includes("already")) {
        // 其他錯誤忽略即可（RLS / 欄位不存在會由下游顯示）
      }
    }
  } catch (e) {}
}

async function hmBackendGetInventory(opts) {
  opts = opts || {};
  const res = await hmBackendGetClientAndUser();
  if (!res.ok) throw new Error(res.reason || "not_authenticated");

  const { cli, uid, email } = res;
  const shouldRefetch = !!opts.force || !hmRewardCache.uid || hmRewardCache.uid !== uid || !hmRewardCache.lastFetchAt || (Date.now() - hmRewardCache.lastFetchAt > 30_000);
  if (!shouldRefetch) return hmRewardCache.inventory;

  hmRewardCache.uid = uid;
  hmRewardCache.email = email;

  await hmBackendEnsureInventoryRow(cli, uid);

  const q = await cli.from("inventories").select("roses,gifts").eq("user_id", uid).maybeSingle();
  if (q && q.error) throw new Error("inventories 讀取失敗：" + (q.error.message || "unknown"));

  const inv = q && q.data ? q.data : { roses: 0, gifts: 0 };
  hmRewardCache.inventory = {
    roses: Math.max(0, parseInt(inv.roses || 0, 10) || 0),
    gifts: Math.max(0, parseInt(inv.gifts || 0, 10) || 0)
  };
  hmRewardCache.lastFetchAt = Date.now();
  return hmRewardCache.inventory;
}

async function hmBackendClaimLoginGift(opts) {
  opts = opts || {};
  const res = await hmBackendGetClientAndUser();
  if (!res.ok) return { ok: false, reason: res.reason || "尚未登入" };
  const { cli } = res;

  const rpc = await cli.rpc("claim_login_gift", {});
  if (rpc && rpc.error) {
    // 後端尚未更新：相容舊版（不阻斷功能）
    const msg = String(rpc.error.message || "");
    if (!msg.includes("claim_login_gift")) console.warn("claim_login_gift error:", rpc.error);
    return { ok: false, reason: msg || "claim_login_gift 失敗" };
  }
  const data = rpc && rpc.data ? rpc.data : null;
  if (!data) return { ok: false, reason: "claim_login_gift 無回傳" };
  return data;
}

async function hmBackendTryClaimLoginGiftOnce(opts) {
  opts = opts || {};
  const ctx = hmRewardTzYmd();
  const k = "hmLoginGiftClaimedYmd";
  if (!opts.force) {
    try {
      if (localStorage.getItem(k) === ctx.ymd) return { ok: true, skipped: true };
    } catch (e) {}
  }

  const res = await hmBackendClaimLoginGift();
  if (res && res.ok) {
    try { localStorage.setItem(k, ctx.ymd); } catch (e) {}
    // 刷新庫存 cache（讓 UI 立即顯示）
    try { await hmBackendGetInventory({ force: true }); } catch (e) {}
    try { await hmGiftRenderInventory(); } catch (e) {}
    try { await hmRewardRenderUI({ force: true }); } catch (e) {}
  }
  return res;
}


async function hmBackendFetchMonthClaims(ym, opts) {
  opts = opts || {};
  const res = await hmBackendGetClientAndUser();
  if (!res.ok) throw new Error(res.reason || "not_authenticated");
  const { cli, uid } = res;

  if (!ym) ym = hmRewardTzYmd().ym;
  if (!opts.force && hmRewardCache.uid === uid && hmRewardCache.month.ym === ym && hmRewardCache.month.claimedDays) {
    return hmRewardCache.month;
  }

  // daysInMonth
  const y = parseInt(ym.slice(0, 4), 10);
  const m = parseInt(ym.slice(4, 6), 10);
  const dim = (y && m) ? new Date(y, m, 0).getDate() : 30;

  // claims
  const claimedDays = {};
  const claims = await cli.from("reward_claims").select("day,reward_type").eq("yyyymm", ym).order("day", { ascending: true }).limit(40);
  if (claims && claims.error) throw new Error("reward_claims 讀取失敗：" + (claims.error.message || "unknown"));

  (claims && claims.data ? claims.data : []).forEach((row) => {
    const d = parseInt(row.day || "0", 10);
    if (!Number.isFinite(d) || d <= 0) return;
    const t = String(row.reward_type || "");
    claimedDays[d] = (t === "gift") ? "gift" : "rose";
  });

  // monthly bonus
  let bonusGranted = false;
  const bonus = await cli.from("monthly_bonuses").select("yyyymm").eq("yyyymm", ym).limit(1);
  if (bonus && bonus.error) {
    bonusGranted = false;
  } else {
    bonusGranted = Array.isArray(bonus.data) && bonus.data.length > 0;
  }

  hmRewardCache.month = { ym, daysInMonth: dim, claimedDays, bonusGranted };
  return hmRewardCache.month;
}

async function hmBackendTryMigrateLocalOnce() {
  // 一次性把 localStorage 內舊的 inventory（若存在）遷移到 Supabase inventories
  try {
    const res = await hmBackendGetClientAndUser();
    if (!res.ok) return;

    const { cli, uid, email } = res;
    const flagKey = HM_REWARD_MIGRATED_PREFIX + uid;
    let flagged = "";
    try { flagged = localStorage.getItem(flagKey) || ""; } catch (e) {}
    if (flagged === "1") return;

    // 只嘗試搬移「同 Email identity」那一把
    const oldIdentity = "email:" + (email || "");
    const oldKey = "hmRewardState::" + oldIdentity;
    const raw = localStorage.getItem(oldKey);
    if (!raw) { try { localStorage.setItem(flagKey, "1"); } catch (e) {} ; return; }

    let parsed = null;
    try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
    const roses = parsed && parsed.inventory && typeof parsed.inventory.roses === "number" ? Math.max(0, Math.floor(parsed.inventory.roses)) : 0;
    const gifts = parsed && parsed.inventory && typeof parsed.inventory.gifts === "number" ? Math.max(0, Math.floor(parsed.inventory.gifts)) : 0;

    if (roses <= 0 && gifts <= 0) { try { localStorage.setItem(flagKey, "1"); } catch (e) {} ; return; }

    const mig = await cli.rpc("migrate_inventory", { p_roses: roses, p_gifts: gifts });
    if (mig && mig.error) {
      console.warn("migrate_inventory 失敗（可能尚未建後端表/函式）：", mig.error);
      return;
    }

    try { localStorage.setItem(flagKey, "1"); } catch (e) {}
    try { localStorage.removeItem(oldKey); } catch (e) {}

    // 立即刷新 cache
    try { await hmBackendGetInventory({ force: true }); } catch (e) {}
  } catch (e) {}
}

async function hmBackendConsumeItem(kind, amount, opts) {
  opts = opts || {};
  const qty = parseInt(amount || "0", 10);
  if (!Number.isFinite(qty) || qty <= 0) return { ok: false, reason: "數量錯誤" };

  const res = await hmBackendGetClientAndUser();
  if (!res.ok) return { ok: false, reason: res.reason || "尚未綁定 Email / 登入" };
  const { cli } = res;

  const item = (kind === "roses") ? "rose" : (kind === "gifts" ? "gift" : String(kind || ""));
  const reason = (opts && opts.reason) ? String(opts.reason) : "";

  const rpc = await cli.rpc("consume_item", { p_item: item, p_qty: qty, p_reason: reason });
  if (rpc && rpc.error) {
    const msg = String(rpc.error.message || "");
    return { ok: false, reason: "扣款失敗（請先完成 Supabase 後端 SQL 建置）：" + msg };
  }

  const data = rpc && rpc.data ? rpc.data : null;
  if (!data || data.ok === false) {
    const r = data && data.reason ? data.reason : "扣款失敗";
    return { ok: false, reason: r };
  }

  // 回寫 cache（避免每次都打 DB）
  if (typeof data.roses === "number") hmRewardCache.inventory.roses = Math.max(0, Math.floor(data.roses));
  if (typeof data.gifts === "number") hmRewardCache.inventory.gifts = Math.max(0, Math.floor(data.gifts));
  hmRewardCache.lastFetchAt = Date.now();

  const left = (item === "rose") ? hmRewardCache.inventory.roses : hmRewardCache.inventory.gifts;
  return { ok: true, left, inventory: hmRewardCache.inventory };
}


async function hmBackendSendGift(toUserId, kind, amount, opts) {
  opts = opts || {};
  const qty = parseInt(amount || "0", 10);
  if (!Number.isFinite(qty) || qty <= 0) return { ok: false, reason: "數量錯誤" };

  const elig = await hmRewardGetEligibility();
  if (!elig.ok) return { ok: false, reason: elig.reason || "尚未符合資格" };

  const res = await hmBackendGetClientAndUser();
  if (!res.ok) return { ok: false, reason: res.reason || "尚未綁定 Email / 登入" };

  const { cli } = res;
  const toId = String(toUserId || "");
  if (!toId) return { ok: false, reason: "尚未選擇送禮對象" };

  const reason = (opts && opts.reason) ? String(opts.reason) : "";
  const rpc = await cli.rpc("send_gift", { p_to: toId, p_kind: kind, p_qty: qty, p_reason: reason });
  if (rpc && rpc.error) {
    const msg = String(rpc.error.message || "");
    return { ok: false, reason: "送出失敗（請先完成 Supabase 後端 SQL 建置）：" + msg };
  }

  const data = rpc && rpc.data ? rpc.data : null;
  if (!data || data.ok === false) {
    const r = data && data.reason ? data.reason : "送出失敗";
    return { ok: false, reason: r };
  }

  // 回寫 cache（扣款後的 sender inventory）
  if (typeof data.roses === "number") hmRewardCache.inventory.roses = Math.max(0, Math.floor(data.roses));
  if (typeof data.gifts === "number") hmRewardCache.inventory.gifts = Math.max(0, Math.floor(data.gifts));
  hmRewardCache.lastFetchAt = Date.now();

  return { ok: true, inventory: hmRewardCache.inventory, tx: data.tx || null };
}

async function hmRewardGetEligibility() {
  const completed = (typeof hmHasCompletedProfile === "function") ? hmHasCompletedProfile() : false;
  if (!completed) return { ok: false, reason: "尚未完成基本資料", completed: false };

  const au = await hmBackendGetClientAndUser();
  if (!au.ok) return { ok: false, reason: "請先使用 Email/Password 登入（Supabase）", completed: true };

  return { ok: true, reason: "", completed: true, identity: "uid:" + au.uid, hasEmail: true, email: au.email, uid: au.uid };
}

function hmRewardOpenModal() {
  const modal = document.getElementById("hm-reward-modal");
  if (!modal) return;
  modal.style.display = "flex";
}

function hmRewardCloseModal() {
  const modal = document.getElementById("hm-reward-modal");
  if (!modal) return;
  modal.style.display = "none";
}

function hmRewardGetLastShownKey(uid) {
  return HM_REWARD_LAST_SHOWN_PREFIX + (uid || "guest");
}

async function hmRewardRenderUI(opts) {
  opts = opts || {};
  const ctx = hmRewardTzYmd();
  const elig = await hmRewardGetEligibility();

  // footer summary（我的頁面）
  try {
    const summary = document.getElementById("hm-daily-reward-summary");
    if (summary) {
      if (!elig.ok) {
        summary.textContent = `簽到狀態：${elig.reason}`;
      } else {
        await hmBackendTryMigrateLocalOnce();
        const inv = await hmBackendGetInventory({ force: !!opts.force });
        const month = await hmBackendFetchMonthClaims(ctx.ym, { force: !!opts.force });
        const claimedToday = !!month.claimedDays[ctx.day];
        const todayReward = hmRewardComputeForDay(ctx.day);
        const count = Object.keys(month.claimedDays || {}).length;
        summary.textContent = `簽到：${claimedToday ? "今日已領" : "今日未領"}｜今日：${todayReward.label}｜本月：${count}/${month.daysInMonth}｜${hmRewardFmtInventory(inv)}`;
      }
    }
  } catch (e) {}

  // modal 內容
  try {
    const titleEl = document.getElementById("hm-reward-title");
    const subEl = document.getElementById("hm-reward-sub");
    const todayEl = document.getElementById("hm-reward-today");
    const invEl = document.getElementById("hm-reward-inventory");
    const progEl = document.getElementById("hm-reward-month-progress");
    const barEl = document.getElementById("hm-reward-progressbar");
    const bonusEl = document.getElementById("hm-reward-bonus-hint");
    const hintEl = document.getElementById("hm-reward-hint");
    const claimBtn = document.getElementById("hm-reward-claim-btn");

    if (titleEl) titleEl.textContent = "每日簽到";
    if (!elig.ok) {
      if (subEl) subEl.textContent = elig.reason || "尚未符合簽到資格";
      if (todayEl) todayEl.textContent = "—";
      if (invEl) invEl.textContent = "—";
      if (progEl) progEl.textContent = "—";
      if (barEl) barEl.style.width = "0%";
      if (bonusEl) bonusEl.textContent = "月滿額：需先登入並完成基本資料";
      if (hintEl) hintEl.textContent = "完成 Email 登入 + 基本資料後，即可開始簽到。";
      if (claimBtn) { claimBtn.disabled = true; claimBtn.textContent = "不可領取"; }
      return;
    }

    await hmBackendTryMigrateLocalOnce();

    const inv = await hmBackendGetInventory({ force: !!opts.force });
    const month = await hmBackendFetchMonthClaims(ctx.ym, { force: !!opts.force });
    const claimedToday = !!month.claimedDays[ctx.day];
    const todayReward = hmRewardComputeForDay(ctx.day);
    const count = Object.keys(month.claimedDays || {}).length;

    if (subEl) subEl.textContent = `今天（${ctx.ymd}）`;
    if (todayEl) todayEl.textContent = todayReward.label;
    if (invEl) invEl.textContent = hmRewardFmtInventory(inv);

    if (progEl) progEl.textContent = `本月進度：${count}/${month.daysInMonth}`;
    if (barEl) {
      const pct = month.daysInMonth ? Math.min(100, Math.max(0, Math.round((count / month.daysInMonth) * 100))) : 0;
      barEl.style.width = pct + "%";
    }

    const needAll = month.daysInMonth;
    const bonusText = month.bonusGranted ? "✅ 本月已領過月滿額（🌹 玫瑰 x3）" : `月滿額：全勤 ${needAll} 天送 🌹 玫瑰 x3`;
    if (bonusEl) bonusEl.textContent = bonusText;

    if (claimedToday) {
      if (hintEl) hintEl.textContent = "你今天已領取。";
      if (claimBtn) { claimBtn.disabled = true; claimBtn.textContent = "今日已領"; }
    } else {
      if (hintEl) hintEl.textContent = "點下方按鈕即可領取今日獎勵。";
      if (claimBtn) { claimBtn.disabled = false; claimBtn.textContent = "領取今日獎勵"; }
    }
  } catch (e) {}
}

async function hmRewardClaimToday() {
  const hintEl = document.getElementById("hm-reward-hint");
  const claimBtn = document.getElementById("hm-reward-claim-btn");
  try {
    const elig = await hmRewardGetEligibility();
    if (!elig.ok) {
      if (hintEl) hintEl.textContent = elig.reason || "尚未符合資格";
      return;
    }

    if (claimBtn) { claimBtn.disabled = true; claimBtn.textContent = "領取中…"; }
    if (hintEl) hintEl.textContent = "領取中…";

    const au = await hmBackendGetClientAndUser();
    const cli = au.cli;

    let rpc = await cli.rpc("claim_daily_reward");
    // 若後端曾建立過同名（含 default 參數）的 overload，PostgREST 可能會回傳 ambiguous error
    // 看到此錯誤時，改用帶參數呼叫，先讓流程可用（建議仍以 SQL patch 移除重複函式）
    if (rpc && rpc.error) {
      const msg = String(rpc.error.message || "");
      if (msg.includes("Could not choose the best candidate") || msg.toLowerCase().includes("best candidate function")) {
        const ctx2 = hmRewardTzYmd();
        rpc = await cli.rpc("claim_daily_reward", { p_date: ctx2.ymd });
      }
    }
    if (rpc && rpc.error) {
      const msg = String(rpc.error.message || "");
      if (hintEl) hintEl.textContent = "領取失敗（請先完成 Supabase 後端 SQL 建置）：" + msg;
      if (claimBtn) { claimBtn.disabled = false; claimBtn.textContent = "重新嘗試"; }
      return;
    }

    const data = rpc && rpc.data ? rpc.data : null;
    if (!data || data.ok === false) {
      const reason = data && data.reason ? data.reason : "領取失敗";
      if (hintEl) hintEl.textContent = reason;
      if (claimBtn) { claimBtn.disabled = false; claimBtn.textContent = "重新嘗試"; }
      return;
    }

    const qty = (data.reward_qty && parseInt(data.reward_qty, 10) > 0) ? parseInt(data.reward_qty, 10) : (data.reward === "gift" ? 2 : 1);
    const rType = data.reward === "gift" ? `🎁 小禮物 x${qty}` : `🌹 玫瑰 x${qty}`;
    const bonus = (data.monthly_bonus && parseInt(data.monthly_bonus, 10) > 0) ? `，月滿額加送 🌹 玫瑰 x${data.monthly_bonus}` : "";
    if (hintEl) hintEl.textContent = `已領取：${rType}${bonus}`;

    // 強制刷新 UI/cache
    try { await hmBackendGetInventory({ force: true }); } catch (e) {}
    try { await hmBackendFetchMonthClaims(hmRewardTzYmd().ym, { force: true }); } catch (e) {}
    try { await hmRewardRenderUI({ force: true }); } catch (e) {}
    try { await hmUpdateMoodRoseUI(); } catch (e) {}
    try { await hmGiftRenderInventory(); } catch (e) {}

    if (claimBtn) { claimBtn.disabled = true; claimBtn.textContent = "今日已領"; }
  } catch (e) {
    if (hintEl) hintEl.textContent = "領取失敗";
    if (claimBtn) { claimBtn.disabled = false; claimBtn.textContent = "重新嘗試"; }
  }
}

async function hmMaybeShowRewardModal(opts) {
  opts = opts || {};
  const ctx = hmRewardTzYmd();
  const elig = await hmRewardGetEligibility();
  if (!elig.ok) return;

  await hmBackendTryMigrateLocalOnce();

  const month = await hmBackendFetchMonthClaims(ctx.ym, { force: false });
  const claimedToday = !!month.claimedDays[ctx.day];
  if (claimedToday) { try { await hmRewardRenderUI(); } catch (e) {} ; return; }

  // 同一天自動彈一次
  const uid = elig.uid || (elig.identity || "").replace(/^uid:/, "");
  let lastShown = "";
  try { lastShown = localStorage.getItem(hmRewardGetLastShownKey(uid)) || ""; } catch (e) {}
  const shouldAutoShow = (lastShown !== ctx.ymd);

  if (!opts.force && !shouldAutoShow) return;

  try { localStorage.setItem(hmRewardGetLastShownKey(uid), ctx.ymd); } catch (e) {}
  hmRewardOpenModal();
  await hmRewardRenderUI();
}

(function bindDailyRewardUi() {
  try {
    // open button（我的頁面）
    const openBtn = document.getElementById("hm-daily-reward-btn");
    if (openBtn) openBtn.addEventListener("click", async function () {
      try { hmRewardOpenModal(); } catch (e) {}
      try { await hmRewardRenderUI({ force: true }); } catch (e) {}
    });

    // close
    const closeBtn = document.getElementById("hm-reward-close-btn");
    if (closeBtn) closeBtn.addEventListener("click", hmRewardCloseModal);

    const modal = document.getElementById("hm-reward-modal");
    if (modal) {
      modal.addEventListener("click", function (e) {
        if (e.target === modal) hmRewardCloseModal();
      });
    }

    // claim
    const claimBtn = document.getElementById("hm-reward-claim-btn");
    if (claimBtn) claimBtn.addEventListener("click", hmRewardClaimToday);

    // 首次載入：渲染 footer + 自動彈窗（若符合資格且今日未領）
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        hmRewardRenderUI();
        try { hmMaybeShowRewardModal({ reason: "appLaunch" }); } catch (e) {}
      });
    } else {
      hmRewardRenderUI();
      try { hmMaybeShowRewardModal({ reason: "appLaunch" }); } catch (e) {}
    }
  } catch (e) {
    console.warn("bindDailyRewardUi failed:", e);
  }
})()

;


(function bindDailyRewardUiDelegated() {
  try {
    if (window.__hmRewardDelegatedBound) return;
    window.__hmRewardDelegatedBound = true;

    document.addEventListener(
      "click",
      async function (e) {
        const t = e && e.target ? e.target : null;

        const open = t && t.closest ? t.closest("#hm-daily-reward-btn") : null;
        if (open) {
          try { hmRewardOpenModal(); } catch (_e) {}
          try { await hmRewardRenderUI({ force: true }); } catch (_e) {}
          return;
        }

        const claim = t && t.closest ? t.closest("#hm-reward-claim-btn") : null;
        if (claim) {
          try { await hmRewardClaimToday(); } catch (_e) {}
          return;
        }

        const close = t && t.closest ? t.closest("#hm-reward-close-btn") : null;
        if (close) {
          try { hmRewardCloseModal(); } catch (_e) {}
          return;
        }
      },
      true
    );
  } catch (e) {}
})();
  // BUILD STAMP
  window.HM_BUILD = "v11-meet-fullscreen-swipe-2026-01-04";
  try { console.log("HM BUILD:", window.HM_BUILD); } catch(e) {}
