
(function(){
  function q(id){ return document.getElementById(id); }
  var lastRealNavPage = "people";

  function markNavActive(page){
    document.querySelectorAll(".bottom-nav .nav-item").forEach(function(item){
      item.classList.toggle("active", item.getAttribute("data-page") === page);
    });
  }

  function restoreNavAfterShop(){
    markNavActive(lastRealNavPage);
  }

  window.hmOpenShopModal = function(){
    var modal = q("hm-shop-modal");
    if (!modal) return;
    modal.style.display = "flex";
    var detail = q("hm-shop-detail");
    if (detail) detail.classList.remove("show");
  };

  window.hmCloseShopModal = function(){
    var modal = q("hm-shop-modal");
    if (!modal) return;
    modal.style.display = "none";
    restoreNavAfterShop();
  };

  function showShopDetail(item){
    var title = q("hm-shop-detail-title");
    var text = q("hm-shop-detail-text");
    var box = q("hm-shop-detail");
    var primary = q("hm-shop-primary-btn");
    var secondary = q("hm-shop-secondary-btn");
    if (!title || !text || !box || !primary || !secondary) return;
    box.classList.add("show");
    secondary.textContent = "稍後";

    if (item === "rose10"){
      title.textContent = "10朵玫瑰";
      text.textContent = "10朵玫瑰 60TW。確認後會進入儲值流程。";
      primary.textContent = "選擇 10朵玫瑰";
      primary.onclick = function(){ alert("儲值選項：10朵玫瑰 60TW"); };
    } else if (item === "rose50"){
      title.textContent = "50朵玫瑰";
      text.textContent = "50朵玫瑰 250TW。確認後會進入儲值流程。";
      primary.textContent = "選擇 50朵玫瑰";
      primary.onclick = function(){ alert("儲值選項：50朵玫瑰 250TW"); };
    } else if (item === "vip"){
      title.textContent = "開通VIP";
      text.textContent = "VIP 150TW。開通後可直接觀看他人完整相簿，不需先看廣告，並同步套用我的日記 30 則上限。";
      primary.textContent = "選擇 VIP";
      primary.onclick = async function(){
        try{
          if (typeof hmVip60HandleSubscribeClick === "function") {
            await hmVip60HandleSubscribeClick();
          } else {
            alert("VIP 功能已準備好，但目前找不到開通流程。");
          }
        }catch(e){
          alert("VIP 開通失敗");
        }
      };
    }
    secondary.onclick = function(){ window.hmCloseShopModal(); };
  }

  document.addEventListener("click", function(e){
    var shopCard = e.target && e.target.closest ? e.target.closest("[data-shop-item]") : null;
    if (shopCard){
      e.preventDefault();
      showShopDetail(shopCard.getAttribute("data-shop-item"));
      return;
    }
    var closeBtn = e.target && e.target.closest ? e.target.closest("#hm-shop-close-btn") : null;
    if (closeBtn){
      e.preventDefault();
      window.hmCloseShopModal();
      return;
    }
    var modal = q("hm-shop-modal");
    if (modal && e.target === modal){
      window.hmCloseShopModal();
      return;
    }
    var nav = e.target && e.target.closest ? e.target.closest(".bottom-nav .nav-item") : null;
    if (nav){
      var page = nav.getAttribute("data-page");
      if (page && page !== "shop") lastRealNavPage = page;
    }
  }, true);

  function patchDailyRewardSummary(){
    var summary = q("hm-daily-reward-summary");
    if (summary){
      summary.innerHTML = '每日登入獎勵：<b>🌹 1朵</b><br>連續 7 天：<b>💐 1束＝5朵</b>';
    }
    var note = document.querySelector(".my-album-note");
    if (note){
      note.innerHTML = '前 2 張為免費預覽，後 4 張需觀看一次廣告暫時解鎖 20 分鐘；開通 <b>VIP（月費 NT$60）</b> 後，在有效期間可免廣告查看全部相簿。';
    }
    var vipDesc = document.querySelector(".vip60-desc");
    if (vipDesc){
      vipDesc.textContent = "✅ 相簿免廣告全開";
    }
  }

  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", patchDailyRewardSummary);
  } else {
    patchDailyRewardSummary();
  }
})();
