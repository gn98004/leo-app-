
(function(){
  const KEY = "hmFakeBillingStateV2";
  const DAY_MS = 24 * 60 * 60 * 1000;

  function loadState() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return {
            roses: Math.max(0, parseInt(parsed.roses || 0, 10) || 0),
            vip_until: Math.max(0, parseInt(parsed.vip_until || 0, 10) || 0),
            updated_at: parsed.updated_at || null
          };
        }
      }
    } catch (e) {}
    return { roses: 20, vip_until: 0, updated_at: null };
  }

  function saveState(s) {
    try {
      s.updated_at = new Date().toISOString();
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch (e) {}
  }

  function getState() {
    const s = loadState();
    if (!Number.isFinite(s.roses) || s.roses < 0) s.roses = 0;
    if (!Number.isFinite(s.vip_until) || s.vip_until < 0) s.vip_until = 0;
    return s;
  }

  function setState(mutator) {
    const s = getState();
    mutator(s);
    if (s.roses < 0) s.roses = 0;
    saveState(s);
    reflectAll();
    return s;
  }

  function isVipActive(s) {
    const st = s || getState();
    return Number(st.vip_until || 0) > Date.now();
  }

  function fmtDate(ms) {
    if (!ms) return "未開通";
    try {
      const d = new Date(ms);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return y + "-" + m + "-" + day;
    } catch (e) {
      return "未開通";
    }
  }

  function syncCaches(s) {
    const st = s || getState();
    try { localStorage.setItem("hmVipLevel", isVipActive(st) ? "1" : "0"); } catch (e) {}

    try {
      window.hmRewardCache = window.hmRewardCache || {};
      window.hmRewardCache.inventory = { roses: st.roses, gifts: 0 };
      window.hmRewardCache.lastFetchAt = Date.now();
    } catch (e) {}

    try {
      window.hmMoodRosesCache = st.roses;
    } catch (e) {}

    try {
      window.hmMonetizationCache = window.hmMonetizationCache || { env: "dev", platform: "web", config: {}, entitlements: {}, unlocks: {} };
      window.hmMonetizationCache.entitlements = window.hmMonetizationCache.entitlements || {};
      window.hmMonetizationCache.entitlements.vip_active = isVipActive(st);
      window.hmMonetizationCache.entitlements.vip_tier = isVipActive(st) ? "vip" : null;
      window.hmMonetizationCache.entitlements.vip_until = isVipActive(st) ? new Date(st.vip_until).toISOString() : null;
      if (typeof window.hmMonetizationSaveLocal === "function") {
        try { window.hmMonetizationSaveLocal(); } catch (e) {}
      }
    } catch (e) {}
  }

  function reflectAll() {
    const st = getState();
    syncCaches(st);

    try {
      document.querySelectorAll(".hm-fake-roses-count").forEach(el => el.textContent = String(st.roses));
      document.querySelectorAll(".hm-fake-vip-status").forEach(el => {
        el.textContent = isVipActive(st) ? ("已開通，至 " + fmtDate(st.vip_until)) : "未開通";
      });
    } catch (e) {}

    try {
      const inv = document.getElementById("hm-gift-inventory");
      if (inv) inv.textContent = "🌹 玫瑰：" + st.roses;
    } catch (e) {}

    try {
      const mood = document.getElementById("moodRoseCount");
      if (mood) mood.textContent = String(st.roses);
    } catch (e) {}

    try {
      const badge = document.getElementById("myVipBadge");
      if (badge) {
        badge.style.display = isVipActive(st) ? "" : "none";
        badge.textContent = isVipActive(st) ? "VIP" : "";
      }
    } catch (e) {}

    try {
      const status = document.getElementById("vip60StatusText");
      if (status) status.textContent = isVipActive(st) ? ("VIP：已開通（到期日 " + fmtDate(st.vip_until) + "）") : "VIP：未開通";
    } catch (e) {}

    try {
      const note = document.getElementById("vip60NoteText");
      if (note) note.textContent = isVipActive(st)
        ? ("目前使用本機寫死版 VIP 測試中，到期日：" + fmtDate(st.vip_until) + "。回家後再接 Google Play 訂閱。")
        : "目前使用本機寫死版測試購買流程；回家後再接 Google Play 訂閱。";
    } catch (e) {}

    try {
      const btn = document.getElementById("vip60SubscribeBtn");
      if (btn) btn.textContent = isVipActive(st) ? "VIP 已開通" : "開通 VIP（測試版）";
    } catch (e) {}

    try {
      const summary = document.getElementById("hm-daily-reward-summary");
      if (summary) summary.textContent = "測試版寫死流程｜🌹 玫瑰：" + st.roses + "｜VIP：" + (isVipActive(st) ? ("已開通至 " + fmtDate(st.vip_until)) : "未開通");
    } catch (e) {}

    try {
      const invEl = document.getElementById("hm-reward-inventory");
      if (invEl) invEl.textContent = "🌹 玫瑰：" + st.roses + " ｜ 🎁 小禮物：0";
    } catch (e) {}

    try {
      if (typeof window.hmUpdateVipUI === "function") window.hmUpdateVipUI();
    } catch (e) {}
  }

  window.hmRewardGetEligibility = async function() {
    return { ok: true, reason: "", completed: true, identity: "fake-local-user", hasEmail: true, email: "fake@local", uid: "fake-local-user" };
  };

  window.hmBackendGetInventory = async function() {
    const st = getState();
    syncCaches(st);
    return { roses: st.roses, gifts: 0 };
  };

  window.hmBackendConsumeItem = async function(kind, amount, opts) {
    const qty = Math.max(0, parseInt(amount || 0, 10) || 0);
    const item = String(kind || "");
    if (!qty) return { ok: false, reason: "數量錯誤" };
    const st = setState(function(s) {
      if (item === "roses" || item === "rose") {
        if (s.roses < qty) throw new Error("玫瑰不足");
        s.roses -= qty;
      }
    });
    return { ok: true, left: st.roses, inventory: { roses: st.roses, gifts: 0 } };
  };

  window.hmBackendSendGift = async function(toUserId, kind, amount, opts) {
    const qty = Math.max(0, parseInt(amount || 0, 10) || 0);
    if (!qty) return { ok: false, reason: "數量錯誤" };
    let after = null;
    try {
      after = setState(function(s) {
        if (s.roses < qty) throw new Error("玫瑰不足");
        s.roses -= qty;
      });
    } catch (e) {
      return { ok: false, reason: e && e.message ? e.message : "送出失敗" };
    }

    try {
      const recv = document.getElementById("hm-recv-roses");
      if (recv) {
        const oldNum = parseInt(String(recv.textContent || "").replace(/[^\d]/g, "") || "0", 10) || 0;
        recv.textContent = "🌹 " + (oldNum + qty);
      }
    } catch (e) {}

    return { ok: true, inventory: { roses: after.roses, gifts: 0 }, tx: { ok: true, to: String(toUserId || ""), qty: qty, kind: kind || "roses" } };
  };

  window.hmGiftRenderInventory = async function() {
    const st = getState();
    const invEl = document.getElementById("hm-gift-inventory");
    if (invEl) invEl.textContent = "🌹 玫瑰：" + st.roses;
    return { roses: st.roses, gifts: 0 };
  };

  window.hmOpenGiftModal = async function() {
    const st = getState();
    const modal = document.getElementById("hm-gift-modal");
    if (!modal) return;
    const subEl = document.getElementById("hm-gift-sub");
    const hintEl = document.getElementById("hm-gift-hint");
    const roseBtn = document.getElementById("hm-send-rose-btn");
    const name = (window.hmGiftTarget && window.hmGiftTarget.name) ? window.hmGiftTarget.name : "";
    if (subEl) subEl.textContent = name ? ("送給：" + name) : "選擇要送出的玫瑰";
    if (hintEl) hintEl.textContent = st.roses > 0 ? "點選下方按鈕即可送出玫瑰。" : "你的玫瑰不足，先到測試商店補貨。";
    if (roseBtn) roseBtn.disabled = st.roses <= 0;
    await window.hmGiftRenderInventory();
    modal.style.display = "flex";
  };

  window.hmSendGift = async function(kind) {
    const hintEl = document.getElementById("hm-gift-hint");
    if (hintEl) hintEl.textContent = "送出中…";
    const toId = (window.hmGiftTarget && window.hmGiftTarget.id) ? String(window.hmGiftTarget.id) : "fake-receiver";
    const res = await window.hmBackendSendGift(toId, kind || "roses", 1, {});
    if (!res.ok) {
      if (hintEl) hintEl.textContent = res.reason || "送出失敗";
      await window.hmGiftRenderInventory();
      return;
    }
    if (hintEl) hintEl.textContent = "已送出 🌹 玫瑰 x1";
    reflectAll();
    setTimeout(function(){
      const modal = document.getElementById("hm-gift-modal");
      if (modal) modal.style.display = "none";
    }, 450);
  };

  window.hmSyncInventoryCache = async function() {
    const st = getState();
    syncCaches(st);
    return { ok: true, inventory: { roses: st.roses, gifts: 0 } };
  };

  window.hmLoadMoodRoses = function() {
    return getState().roses;
  };

  window.hmUpdateMoodRoseUI = async function() {
    const st = getState();
    syncCaches(st);
    const roseEl = document.getElementById("moodRoseCount");
    if (roseEl) roseEl.textContent = String(st.roses);
  };

  window.hmRewardRenderUI = async function(opts) {
    reflectAll();
    return { ok: true, fake: true };
  };

  function bindOnce() {
    document.querySelectorAll("[data-fake-pack]").forEach(function(btn){
      if (btn.dataset.syncBound) return;
      btn.dataset.syncBound = "1";
      btn.addEventListener("click", function(){
        const n = Math.max(0, parseInt(btn.getAttribute("data-fake-pack") || "0", 10) || 0);
        if (!n) return;
        setState(function(s){ s.roses += n; });
        alert("測試版：已加入 " + n + " 朵玫瑰。");
      });
    });

    document.querySelectorAll("[data-fake-vip]").forEach(function(btn){
      if (btn.dataset.syncBound) return;
      btn.dataset.syncBound = "1";
      btn.addEventListener("click", function(){
        const d = Math.max(1, parseInt(btn.getAttribute("data-fake-vip") || "30", 10) || 30);
        setState(function(s){
          const base = Math.max(Date.now(), Number(s.vip_until || 0));
          s.vip_until = base + d * DAY_MS;
        });
        alert("測試版：VIP 已開通 " + d + " 天。");
      });
    });

    document.querySelectorAll("[data-fake-reset]").forEach(function(btn){
      if (btn.dataset.syncBound) return;
      btn.dataset.syncBound = "1";
      btn.addEventListener("click", function(){
        if (!confirm("要清空目前這台電腦上的測試玫瑰與 VIP 狀態嗎？")) return;
        saveState({ roses: 20, vip_until: 0, updated_at: null });
        reflectAll();
      });
    });

    const vipBtn = document.getElementById("vip60SubscribeBtn");
    if (vipBtn && !vipBtn.dataset.syncBound) {
      vipBtn.dataset.syncBound = "1";
      vipBtn.addEventListener("click", function(e){
        e.preventDefault();
        setState(function(s){
          const base = Math.max(Date.now(), Number(s.vip_until || 0));
          s.vip_until = base + 30 * DAY_MS;
        });
        alert("測試版：VIP 已開通 30 天。");
      }, true);
    }
  }

  function init() {
    bindOnce();
    reflectAll();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
  window.addEventListener("load", function(){
    setTimeout(init, 50);
    setTimeout(reflectAll, 250);
    setTimeout(reflectAll, 800);
  });
})();
