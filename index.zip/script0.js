
  // === Supabase defaults (prefill localStorage if missing) ===
  // NOTE: anon key is designed to be public. Do NOT use service_role key on client.
  try {
    if (!localStorage.getItem("SB_URL")) localStorage.setItem("SB_URL", "https://eqtvoxcavjgronfmalfw.supabase.co");
    if (!localStorage.getItem("SB_ANON_KEY")) localStorage.setItem("SB_ANON_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVxdHZveGNhdmpncm9uZm1hbGZ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU1OTMzMzQsImV4cCI6MjA4MTE2OTMzNH0.974KqoueFlUJ9V2F-hzFznxGhxvr0mK6ujlT1yauxGk");
  } catch (e) {
    console.warn("localStorage not available", e);
  }

  // ==== 人們（Supabase profiles 動態載入） ====
  // 注意：此區域已移除 Demo 假資料，改為從 public.profiles 讀取真實使用者（排除自己）。
  // 若尚未登入或 RLS/政策未放行，列表會顯示空狀態但不會爆。
  const people = [];
  const peopleById = new Map();
  let peopleLoadedOnce = false;

  function hmNormalizeProfileRow(row) {
    if (!row) return null;
    const id = row.id;
    if (!id) return null;
    const name = (row.name || "").trim() || "未命名";
    const region = (row.region || "").trim() || "未設定";
    const height = (row.height == null ? "" : String(row.height));
    const weight = (row.weight == null ? "" : String(row.weight));
    const avatar = row.avatar_url || "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22300%22%20height%3D%22400%22%20viewBox%3D%220%200%20300%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22150%22%20cy%3D%22152%22%20r%3D%2242%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2266%22%20y%3D%22232%22%20width%3D%22168%22%20height%3D%2264%22%20rx%3D%2215%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2225%22%20fill%3D%22%237c3aed%22%3ELinko%20300%C3%97400%3C/text%3E%0A%3C/svg%3E" + Math.floor(Math.random()*5000+1);

    // 狀態：優先用資料表 status；沒有就用 last_seen_at 粗略判斷
    let status = (row.status || "").trim() || "offline";
    let statusText = "離線";
    try {
      if (status === "online") statusText = "已上線";
      else if (status === "busy") statusText = "忙碌中";
      else if (status === "away") statusText = "暫離";
      else if (status === "eating") statusText = "用餐中";
      else if (status === "shower") statusText = "洗澡中";
      else if (row.last_seen_at) {
        const t = new Date(row.last_seen_at).getTime();
        if (!isNaN(t)) {
          const diffMin = Math.floor((Date.now() - t) / 60000);
          if (diffMin <= 3) { status = "online"; statusText = "剛剛在線"; }
          else if (diffMin <= 30) { status = "away"; statusText = "剛剛在線"; }
        }
      }
    } catch (e) { /* ignore */ }

    const age_range = (row.age_range == null ? "" : String(row.age_range));
    const age = row.age == null ? "" : String(row.age);
    const ageText = age_range ? (age_range.replace(/-/g, "～")) : (age ? (age + "歲") : "—");
    const gender = (row.gender == null ? "" : String(row.gender));
    const genderText = gender === "male" ? "男" : (gender === "female" ? "女" : "未設定");
    const desc = "居住：" + region;

    return {
      id: String(id),
      name,
      gender,
      genderText,
      age_range,
      ageText,
      region,
      desc,
      avatar,
      avatar_url: (row.avatar_url == null ? "" : String(row.avatar_url)),
      last_seen_at: row.last_seen_at || null,
      status,
      statusText,
      vipLevel: 0,
      album: [] // 之後可以接相簿表/Storage；目前先留空
    };
  }

  async function hmLoadPeopleFromSupabase(force) {
    if (!force && peopleLoadedOnce) return { ok: true, skipped: true };
    const cli = await hmGetSupabaseClient();
    if (!cli) return { ok: false, reason: "no_sb_url_key" };

    // 需要登入，才有 auth.uid() 供 RLS 判斷（避免 403 / missing sub）
    const sessRes = await cli.auth.getSession();
    const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
    if (!session || !session.user) return { ok: false, reason: "not_signed_in" };

    const uid = session.user.id;

    // 先載入封鎖名單（blocks），讓巧遇可排除你封鎖的對象
    try { await hmRefreshBlockedIdsFromSupabase(cli, uid); } catch (e) {}

    // 讀 profiles：排除自己
    const q = await cli
      .from("profiles")
      .select("id,name,region,height,weight,avatar_url,status,age,last_seen_at,created_at")
      .neq("id", uid)
      .order("created_at", { ascending: false })
      .limit(60);

    if (q.error) return { ok: false, reason: "select_error", error: q.error };

    people.length = 0;
    peopleById.clear();
    (q.data || []).forEach(function (row) {
      const p = hmNormalizeProfileRow(row);
      if (!p) return;
      people.push(p);
      peopleById.set(p.id, p);
    });

    try { await hmAttachPhotosToPeople(cli, people); } catch(e) { /* ignore */ }

    peopleLoadedOnce = true;

    // 重新挑一批給巧遇顯示
    try {
      pickRandomBatch();
      renderPeopleGrid();
    } catch (e) { /* ignore */ }

    return { ok: true, count: people.length };
  }


  // 預設相簿照片（當使用者尚未自己上傳時，當作底圖）
  const albumPhotos = [
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E",
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E",
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E",
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E",
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E",
    "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E"
  ];

  const peopleGridEl = document.getElementById("peopleGrid");
  const pagePeopleEl = document.getElementById("page-people");
  const nextBatchBtn = document.getElementById("nextBatchBtn");
  const peoplePagerEl = document.getElementById("peoplePager");
  const meetLayoutBar = document.getElementById("meetLayoutBar");
  const profileDetailContent = document.getElementById("profileDetailContent");
  const topTitleEl = document.getElementById("topTitle");
  const topRightSlot = document.getElementById("topRightSlot");

  let currentBatch = [];
  // 巧遇顯示模式：1（單人全螢幕滑動）、2、4
  let hmMeetLayout = parseInt(localStorage.getItem("hmMeetLayout") || "1", 10);
  if (![1, 2, 4].includes(hmMeetLayout)) hmMeetLayout = 1;
  let hmMeetSingleIndex = 0;
  let hmMeetSwipeBusy = false;
  let currentProfileId = null; // 目前正在查看的檔案 id（給相簿解鎖後重刷用）

  // 封鎖名單（示意，僅儲存在前端）
  let blockedIds = [];
  // Supabase blocks / reports 欄位偵測快取（避免欄位命名差異導致功能失效）
  let hmBlocksCols = null;   // { blockerCol, blockedCol }
  let hmReportsCols = null;  // { reporterCol, reportedCol, reasonCol }


  function hmIsBlocked(id) {
    return blockedIds.includes(String(id));
  }

  function hmUniqueStrings(arr) {
    const s = new Set();
    (arr || []).forEach(v => { if (v != null) s.add(String(v)); });
    return Array.from(s);
  }

  async function hmRefreshBlockedIdsFromSupabase(cli, uid) {
    try {
      cli = cli || await hmGetSupabaseClient();
      if (!cli) return { ok: false, skipped: true, reason: "no_sb_url_key" };
      uid = uid || await hmGetAuthedUid(cli);
      if (!uid) return { ok: false, skipped: true, reason: "not_signed_in" };

      const candidates = [];
      if (hmBlocksCols) candidates.push(hmBlocksCols);
      candidates.push(
        { blockerCol: "blocker_id", blockedCol: "blocked_id" },
        { blockerCol: "user_id", blockedCol: "blocked_id" },
        { blockerCol: "user_id", blockedCol: "blocked_user_id" },
        { blockerCol: "blocker", blockedCol: "blocked" },
        { blockerCol: "from_user", blockedCol: "to_user" }
      );

      let lastErr = null;

      for (const c of candidates) {
        const res = await cli.from("blocks").select(c.blockedCol).eq(c.blockerCol, uid).limit(500);
        if (!res || !res.error) {
          hmBlocksCols = c;
          const rows = (res && res.data) ? res.data : [];
          blockedIds = hmUniqueStrings(rows.map(r => r && r[c.blockedCol]));
          return { ok: true, count: blockedIds.length, cols: c };
        }

        lastErr = res.error;
        const msg = String((lastErr && (lastErr.message || lastErr.details || lastErr.hint)) || "");
        if (/column .* does not exist|does not exist/i.test(msg)) continue;
        break;
      }

      if (lastErr) console.warn("[blocks] select failed", lastErr);
      return { ok: false, error: lastErr };
    } catch (e) {
      console.warn("[blocks] refresh failed", e);
      return { ok: false, error: e };
    }
  }

  async function hmDetectReportsCols(cli, uid) {
    if (hmReportsCols) return hmReportsCols;
    try {
      cli = cli || await hmGetSupabaseClient();
      if (!cli) return null;
      uid = uid || await hmGetAuthedUid(cli);
      if (!uid) return null;

      const candidates = [
        { reporterCol: "reporter_id", reportedCol: "reported_id", reasonCol: "reason" },
        { reporterCol: "user_id",     reportedCol: "target_id",   reasonCol: "reason" },
        { reporterCol: "reporter",    reportedCol: "reported",    reasonCol: "reason" },
        { reporterCol: "from_user",   reportedCol: "to_user",     reasonCol: "reason" },
        { reporterCol: "reporter_id", reportedCol: "reported_id", reasonCol: "content" }
      ];

      let lastErr = null;
      for (const c of candidates) {
        const res = await cli.from("reports").select(c.reporterCol).limit(1);
        if (!res || !res.error) { hmReportsCols = c; return hmReportsCols; }
        lastErr = res.error;
        const msg = String((lastErr && (lastErr.message || lastErr.details || lastErr.hint)) || "");
        if (/column .* does not exist|does not exist/i.test(msg)) continue;
        break;
      }

      if (lastErr) console.warn("[reports] detect cols failed", lastErr);
      hmReportsCols = candidates[0];
      return hmReportsCols;
    } catch (e) {
      hmReportsCols = { reporterCol: "reporter_id", reportedCol: "reported_id", reasonCol: "reason" };
      return hmReportsCols;
    }
  }

  function shuffleArray(arr) {
    const copy = arr.slice();
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }



  // 1人全螢幕：鎖定 body 捲動（避免手機上下滑動干擾左右滑動）
  let hmBodyScrollLocked = false;
  let hmBodyScrollY = 0;

  function hmUpdateViewportVars() {
    try {
      const tb = document.querySelector('.top-bar');
      const bn = document.querySelector('.bottom-nav');
      if (tb) document.documentElement.style.setProperty('--hmTopBarH', tb.offsetHeight + 'px');
      if (bn) document.documentElement.style.setProperty('--hmBottomNavH', bn.offsetHeight + 'px');
    } catch (e) {}
  }

  function hmLockBodyScroll(lock) {
    try {
      const body = document.body;
      if (lock && !hmBodyScrollLocked) {
        hmBodyScrollLocked = true;
        hmBodyScrollY = window.scrollY || document.documentElement.scrollTop || 0;
        body.style.position = 'fixed';
        body.style.top = (-hmBodyScrollY) + 'px';
        body.style.left = '0';
        body.style.right = '0';
        body.style.width = '100%';
      }
      if (!lock && hmBodyScrollLocked) {
        hmBodyScrollLocked = false;
        const top = body.style.top;
        body.style.position = '';
        body.style.top = '';
        body.style.left = '';
        body.style.right = '';
        body.style.width = '';
        const y = top ? -parseInt(String(top).replace('px',''), 10) : hmBodyScrollY;
        try { window.scrollTo(0, y || 0); } catch (e) {}
      }
    } catch (e) {}
  }

  function hmSetMeetFullscreenMode(enabled) {
    document.documentElement.classList.toggle('hm-meet-fullscreen', !!enabled);
    hmUpdateViewportVars();
    hmLockBodyScroll(!!enabled);
  }

  function hmUpdateMeetFullscreenState() {
    const isPeople = pagePeopleEl ? pagePeopleEl.classList.contains('active') : false;
    hmSetMeetFullscreenMode(isPeople && hmMeetLayout === 1);
  }

  try {
    window.addEventListener('resize', () => {
      if (document.documentElement.classList.contains('hm-meet-fullscreen')) {
        hmUpdateViewportVars();
      }
    });
  } catch (e) {}

  function hmGetMeetBatchSize() {
    // 1人模式：一次抓多一點，讓左右滑動有連續感
    if (hmMeetLayout === 1) return 8;
    if (hmMeetLayout === 2) return 2;
    return 4;
  }

  function hmApplyMeetLayoutUI() {
    try {
      if (peopleGridEl) {
        peopleGridEl.classList.remove("layout-1", "layout-2", "layout-4");
        peopleGridEl.classList.add("layout-" + hmMeetLayout);
      }
      if (peoplePagerEl) peoplePagerEl.style.display = (hmMeetLayout === 1 ? "none" : "");
      if (nextBatchBtn) nextBatchBtn.style.display = (hmMeetLayout === 1 ? "none" : "");
      const btns = document.querySelectorAll('.meet-layout-btn[data-meetlayout]');
      btns.forEach(b => {
        const v = parseInt(b.getAttribute("data-meetlayout"), 10);
        b.classList.toggle("active", v === hmMeetLayout);
      });
    } catch (e) {}

    // 1人全螢幕模式：進入巧遇頁且 layout=1 時鎖定垂直捲動
    try { hmUpdateMeetFullscreenState(); } catch (e) {}
  }

  function hmSetMeetLayout(n) {
    if (![1, 2, 4].includes(n)) return;
    hmMeetLayout = n;
    try { localStorage.setItem("hmMeetLayout", String(n)); } catch (e) {}
    pickRandomBatch();
    renderPeopleGrid();
  }

  function pickRandomBatch() {
    const available = people.filter(p => !hmIsBlocked(p.id));
    const shuffled = shuffleArray(available);
    currentBatch = shuffled.slice(0, hmGetMeetBatchSize());
    hmMeetSingleIndex = 0;
  }

  function hmMeetSingleAdvance() {
    hmMeetSingleIndex += 1;
    if (hmMeetSingleIndex >= currentBatch.length) {
      pickRandomBatch();
    }
    renderPeopleGrid();
  }

  function hmMeetSwipeAway(card, dir) {
    if (hmMeetSwipeBusy) return;
    hmMeetSwipeBusy = true;
    try { card.dataset.hmSwiped = "1"; } catch (e) {}
    card.classList.add(dir === "right" ? "swipe-right" : "swipe-left");
    setTimeout(() => {
      hmMeetSwipeBusy = false;
      hmMeetSingleAdvance();
    }, 190);
  }

  function hmBindMeetSwipe(card) {
    let startX = 0, startY = 0, active = false;
    const threshold = 55;

    // 保險：單人模式強制限制觸控行為，避免頁面跟著上下捲
    try { card.style.touchAction = 'pan-x'; } catch (e) {}

    function onStart(x, y) {
      startX = x;
      startY = y;
      active = true;
      try { card.dataset.hmSwiped = "0"; } catch (e) {}
    }
    function onEnd(x, y) {
      if (!active) return;
      active = false;
      const dx = x - startX;
      const dy = y - startY;
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy)) {
        hmMeetSwipeAway(card, dx > 0 ? "right" : "left");
      }
    }

    if (window.PointerEvent) {
      card.addEventListener("pointerdown", (e) => {
        onStart(e.clientX, e.clientY);
        try { card.setPointerCapture(e.pointerId); } catch (_e) {}
      });
      card.addEventListener("pointermove", (e) => {
        if (!active) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        // 水平滑動為主時，避免瀏覽器判斷成垂直滾動
        if (Math.abs(dx) > Math.abs(dy) + 8) {
          try { e.preventDefault(); } catch (_e) {}
        }
      });
      card.addEventListener("pointerup", (e) => onEnd(e.clientX, e.clientY));
      card.addEventListener("pointercancel", () => { active = false; });
    } else {
      card.addEventListener("touchstart", (e) => {
        const t = (e.touches && e.touches[0]) ? e.touches[0] : null;
        if (!t) return;
        onStart(t.clientX, t.clientY);
      }, { passive: false });
      card.addEventListener("touchmove", (e) => {
        if (!active) return;
        const t = (e.touches && e.touches[0]) ? e.touches[0] : null;
        if (!t) return;
        const dx = t.clientX - startX;
        const dy = t.clientY - startY;
        if (Math.abs(dx) > Math.abs(dy) + 8) {
          try { e.preventDefault(); } catch (_e) {}
        }
      }, { passive: false });
      card.addEventListener("touchend", (e) => {
        const t = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0] : null;
        if (!t) return;
        onEnd(t.clientX, t.clientY);
      });
      card.addEventListener("touchcancel", () => { active = false; });

      let md = false;
      card.addEventListener("mousedown", (e) => { md = true; onStart(e.clientX, e.clientY); });
      window.addEventListener("mouseup", (e) => { if (!md) return; md = false; onEnd(e.clientX, e.clientY); });
    }
  }

  function buildPeopleCard(p, isSingle) {
    const card = document.createElement("div");
    card.className = "people-card";
    card.addEventListener("click", () => {
      if (card.dataset.hmSwiped === "1") return;
      openProfileDetail(p.id);
    });

    const photo = document.createElement("div");
    photo.className = "people-photo";
    photo.innerHTML = '<img src="' + p.avatar + '" alt="' + p.name + '" />';

    if (isSingle) {
      const hint = document.createElement("div");
      hint.className = "meet-swipe-hint";
      hint.textContent = "⇦ 左右滑動換下一位 ⇨";
      photo.appendChild(hint);
      hmBindMeetSwipe(card);
    }

    const info = document.createElement("div");
    info.className = "people-info";

    const row1 = document.createElement("div");
    row1.className = "people-name-row";

    const nameEl = document.createElement("div");
    nameEl.className = "people-name";
    nameEl.textContent = p.name;

    const ageEl = document.createElement("div");
    ageEl.className = "people-age";
    ageEl.textContent = p.ageText;

    row1.appendChild(nameEl);
    row1.appendChild(ageEl);

    let statusClass = "status-badge";
    if (p.status === "busy") statusClass += " status-busy";
    if (p.status === "away" || p.status === "offline") statusClass += " status-away";
    if (p.status === "eating") statusClass += " status-eating";
    if (p.status === "shower") statusClass += " status-shower";

    const statusDiv = document.createElement("span");
    statusDiv.className = statusClass;
    statusDiv.innerHTML = '<span class="status-dot"></span><span>' + (p.statusText || "已上線") + '</span>';

    const desc = document.createElement("div");
    desc.className = "people-desc";
    desc.textContent = p.desc;

    info.appendChild(row1);
    info.appendChild(statusDiv);
    info.appendChild(desc);

    card.appendChild(photo);
    card.appendChild(info);

    return card;
  }

  function renderPeopleGrid() {
    hmApplyMeetLayoutUI();
    try { hmUpdateMeetFullscreenState(); } catch (e) {}

    if (currentBatch.length === 0 || currentBatch.every(p => hmIsBlocked(p.id))) {
      pickRandomBatch();
    }

    peopleGridEl.innerHTML = "";
    const visibleBatch = currentBatch.filter(p => !hmIsBlocked(p.id));
    currentBatch = visibleBatch;

    if (hmMeetLayout === 1) {
      if (currentBatch.length === 0) return;
      if (hmMeetSingleIndex < 0) hmMeetSingleIndex = 0;
      if (hmMeetSingleIndex >= currentBatch.length) hmMeetSingleIndex = 0;

      const p = currentBatch[hmMeetSingleIndex];
      const card = buildPeopleCard(p, true);
      peopleGridEl.appendChild(card);
      return;
    }

    currentBatch.forEach(p => {
      const card = buildPeopleCard(p, false);
      peopleGridEl.appendChild(card);
    });
  }

  nextBatchBtn.addEventListener("click", () => {
    pickRandomBatch();
    renderPeopleGrid();

    // 送禮面板初始化
    try { hmInitGiftModal(); } catch (e) {}
  });

  // 巧遇顯示模式切換（1 / 2 / 4）
  try {
    if (meetLayoutBar) {
      meetLayoutBar.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-meetlayout]");
        if (!btn) return;
        const n = parseInt(btn.getAttribute("data-meetlayout"), 10);
        hmSetMeetLayout(n);
      });
    }
  } catch (e) {}
  try { hmApplyMeetLayoutUI(); } catch (e) {}

  // ===== 好友（Supabase 實裝，已移除 Demo 假資料） =====
  const friendsListEl = document.getElementById("friendsList");

  // 這三個陣列存的是「對方的 user_id（UUID）」
  let friendIds = [];
  let sentRequestIds = [];
  let receivedRequestIds = [];
  let rejectedSentRequestIds = [];
  let friendLastError = ""; // 讀取好友/邀請失敗時提示（避免看起來像沒反應）
  let hmFriendRefreshSeq = 0; // 防止多次背景刷新回來順序不同造成清單一閃而逝
  let hmFriendRefreshTimer = null;

  // 以 id 為 key 的 profiles 快取（只放好友/邀請相關的對象）
  let friendProfilesById = Object.create(null);

  function isUuid(v) {
    return typeof v === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
  }

  function onlineStatusFromLastSeen(lastSeenAt) {
    try {
      if (!lastSeenAt) return { status: "offline", text: "離線" };
      const t = new Date(lastSeenAt).getTime();
      if (!isFinite(t)) return { status: "offline", text: "離線" };
      const diffSec = (Date.now() - t) / 1000;
      if (diffSec <= 120) return { status: "online", text: "在線" };      // 2 分鐘內視為在線
      if (diffSec <= 3600) return { status: "away", text: "剛剛在線" };   // 1 小時內
      return { status: "offline", text: "離線" };
    } catch (_e) {
      return { status: "offline", text: "離線" };
    }
  }

  async function hmGetAuthedUid(cli) {
    const sessRes = await cli.auth.getSession();
    const session = sessRes && sessRes.data ? sessRes.data.session : null;
    return session && session.user ? session.user.id : null;
  }

  async function hmTouchLastSeen(cli, uid) {
    try {
      if (!cli || !uid) return;
      // 只更新 last_seen_at，不動其他欄位
      await cli.from("profiles").upsert({ id: uid, last_seen_at: new Date().toISOString() }, { onConflict: "id" });
    } catch (_e) {}
  }

  function hmScheduleFriendRefresh(delay) {
    try {
      if (hmFriendRefreshTimer) clearTimeout(hmFriendRefreshTimer);
      hmFriendRefreshTimer = setTimeout(function () {
        hmFriendRefreshTimer = null;
        try { hmRefreshFriendsFromSupabase(); } catch (_e) {}
      }, typeof delay === "number" ? delay : 120);
    } catch (_e) {}
  }

  async function hmRefreshFriendsFromSupabase() {
    const __refreshSeq = ++hmFriendRefreshSeq;
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) {
        friendLastError = "";
        hmLocalFriendRefresh();
        return;
      }
      const uid = await hmGetAuthedUid(cli);
      if (!uid) {
        friendLastError = "";
        hmLocalFriendRefresh();
        return;
      }

      friendLastError = "";

      // 更新在線時間（你選 B：顯示線上狀態）
      hmTouchLastSeen(cli, uid);

      // 同步封鎖名單（blocks），好友清單/邀請會排除封鎖對象
      try { await hmRefreshBlockedIdsFromSupabase(cli, uid); } catch (e) {}

      // 1) 讀取好友關係（friends）
      // 1) 讀取好友（由 friend_requests.status = accepted 推導，避免依賴 friends 表欄位）
      const accRes = await cli
        .from("friend_requests")
        .select("from_user,to_user,status")
        .eq("status", "accepted")
        .or(`from_user.eq.${uid},to_user.eq.${uid}`);

      if (accRes.error) throw accRes.error;

      const fIds = [];
      (accRes.data || []).forEach(r => {
        const other = (r.from_user === uid) ? r.to_user : r.from_user;
        if (other && other !== uid) fIds.push(other);
      });
      friendIds = Array.from(new Set(fIds));
      // 排除你已封鎖的對象
      if (blockedIds && blockedIds.length) friendIds = friendIds.filter(x => !hmIsBlocked(x));

      // 2) 讀取送出申請（friend_requests: pending）
      const sentRes = await cli
        .from("friend_requests")
        .select("to_user, status")
        .eq("from_user", uid)
        .eq("status", "pending");

      if (sentRes.error) throw sentRes.error;
      sentRequestIds = Array.from(new Set((sentRes.data || []).map(x => x.to_user).filter(Boolean)));
      if (blockedIds && blockedIds.length) sentRequestIds = sentRequestIds.filter(x => !hmIsBlocked(x));

      // 3) 讀取收到申請（friend_requests: pending）
      const recvRes = await cli
        .from("friend_requests")
        .select("from_user, status")
        .eq("to_user", uid)
        .eq("status", "pending");

      if (recvRes.error) throw recvRes.error;
      receivedRequestIds = Array.from(new Set((recvRes.data || []).map(x => x.from_user).filter(Boolean)));
      if (blockedIds && blockedIds.length) receivedRequestIds = receivedRequestIds.filter(x => !hmIsBlocked(x));

      // 4) 讀取被拒絕的送出申請（讓送出申請頁可看到「已拒絕」狀態）
      const rejectedRes = await cli
        .from("friend_requests")
        .select("to_user, status")
        .eq("from_user", uid)
        .eq("status", "rejected");

      if (rejectedRes.error) throw rejectedRes.error;
      rejectedSentRequestIds = Array.from(new Set((rejectedRes.data || []).map(x => x.to_user).filter(Boolean)));
      if (blockedIds && blockedIds.length) rejectedSentRequestIds = rejectedSentRequestIds.filter(x => !hmIsBlocked(x));

      // 合併本機送出快取：避免「已申請但送出申請分頁沒顯示」
      hmMergeLocalSentRequestsIntoRuntime();

      // 5) 拉取相關 profiles（好友 + 邀請相關）
      const allIds = Array.from(new Set([ ...friendIds, ...sentRequestIds, ...receivedRequestIds, ...rejectedSentRequestIds ].filter(Boolean)));
      friendProfilesById = Object.create(null);
      if (allIds.length) {
        let pRes = await cli

          .from("profiles")

          .select("id,name,region,avatar_url,status,age,gender,age_range,last_seen_at,created_at")

          .in("id", allIds);

        

        // 若 profiles 尚未補齊某些欄位（例如 gender / age_range），自動退回到最小欄位避免整個好友功能掛掉

        try {

          if (pRes && pRes.error) {

            const msg = String(pRes.error.message || pRes.error.details || "");

            if (/column .* does not exist/i.test(msg)) {

              pRes = await cli

                .from("profiles")

                .select("id,name,region,avatar_url,status,age,last_seen_at,created_at")

                .in("id", allIds);

            }

          }

        } catch (_e) {}

        

        if (pRes.error) throw pRes.error;

        

        const list = [];

        (pRes.data || []).forEach(row => {

          const np = hmNormalizeProfileRow(row) || {

            id: String((row && row.id) || ""),

            name: (row && row.name) ? String(row.name) : "（未設定）",

            region: (row && row.region) ? String(row.region) : "",

            desc: (row && row.region) ? ("居住：" + String(row.region)) : "居住：—",

            avatar: (row && row.avatar_url) ? String(row.avatar_url) : "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22160%22%20height%3D%22160%22%20viewBox%3D%220%200%20160%20160%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%2280%22%20cy%3D%2261%22%20r%3D%2222%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2235%22%20y%3D%2293%22%20width%3D%2290%22%20height%3D%2226%22%20rx%3D%228%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2213%22%20fill%3D%22%237c3aed%22%3ELinko%20160%C3%97160%3C/text%3E%0A%3C/svg%3E",

            avatar_url: (row && row.avatar_url) ? String(row.avatar_url) : "",

            last_seen_at: (row && row.last_seen_at) ? row.last_seen_at : null,

            gender: (row && row.gender) ? String(row.gender) : "",

            genderText: (row && row.gender === "male") ? "男" : ((row && row.gender === "female") ? "女" : "未設定"),

            age_range: (row && row.age_range) ? String(row.age_range) : "",

            ageText: (row && row.age_range) ? String(row.age_range).replace(/-/g, "～") : ((row && row.age) ? (String(row.age) + "歲") : "—"),

            status: (row && row.status) ? String(row.status) : "offline",

            statusText: "離線",

            vipLevel: 0,

            album: []

          };

          // 確保 region / last_seen_at 有值（避免 UI 出現「—」與狀態不準）

          if (np && (np.region == null || np.region === "") && row && row.region != null) np.region = String(row.region);

          if (np && np.last_seen_at == null && row && row.last_seen_at != null) np.last_seen_at = row.last_seen_at;

          list.push(np);

        });

        

        try { await hmAttachPhotosToPeople(cli, list); } catch (e) {}

        

        list.forEach(p => {

          if (!p || !p.id) return;

          friendProfilesById[p.id] = p;

          try { if (peopleById) peopleById.set(p.id, p); } catch (_e) {}

        });
}

      if (__refreshSeq !== hmFriendRefreshSeq) return;
      updateFriendTabCounts();
      renderFriendsList(currentFriendTab || "friends");
    } catch (e) {
      if (__refreshSeq !== hmFriendRefreshSeq) return;
      console.warn("[friends] refresh failed", e);
      friendLastError = (e && e.message) ? e.message : String(e);
      updateFriendTabCounts();
      renderFriendsList(currentFriendTab || "friends");
    }
  }

  // 對你送出的好友申請

    // 封鎖 / 檢舉（Supabase 實裝）
  // blocks：寫入封鎖關係，巧遇/好友會自動排除
  // reports：寫入檢舉（原因可空白）
  async function hmBlockUser(id) {
    try {
      const targetId = String(id || "");
      if (!isUuid(targetId)) {
        alert("目前封鎖功能只支援 Supabase 真人帳號（UUID）。");
        return;
      }

      const cli = await hmGetSupabaseClient();
      if (!cli) { alert("尚未設定 Supabase 連線。"); return; }

      const uid = await hmGetAuthedUid(cli);
      if (!uid) { alert("請先登入 Email，才能封鎖。"); return; }

      // 同步封鎖名單（避免重複 insert）
      await hmRefreshBlockedIdsFromSupabase(cli, uid);
      if (blockedIds.includes(targetId)) {
        alert("你已封鎖過此用戶。");
        return;
      }

      const candidates = [];
      if (hmBlocksCols) candidates.push(hmBlocksCols);
      candidates.push(
        { blockerCol: "blocker_id", blockedCol: "blocked_id" },
        { blockerCol: "user_id", blockedCol: "blocked_id" },
        { blockerCol: "user_id", blockedCol: "blocked_user_id" },
        { blockerCol: "blocker", blockedCol: "blocked" },
        { blockerCol: "from_user", blockedCol: "to_user" }
      );

      let lastErr = null;
      let ok = false;

      for (const c of candidates) {
        const payload = {};
        payload[c.blockerCol] = uid;
        payload[c.blockedCol] = targetId;

        const res = await cli.from("blocks").insert(payload);
        if (!res || !res.error) { hmBlocksCols = c; ok = true; break; }

        lastErr = res.error;
        const code = String(lastErr.code || "");
        const msg = String(lastErr.message || lastErr.details || "");
        if (code === "23505" || /duplicate key/i.test(msg)) { hmBlocksCols = c; ok = true; break; }
        if (/column .* does not exist|does not exist/i.test(msg)) continue;
        break;
      }

      if (!ok) {
        console.warn("[blocks] insert failed", lastErr);
        alert("封鎖失敗：請確認 blocks 表欄位與 RLS policy。");
        return;
      }

      blockedIds.push(targetId);

      // 被封鎖時，從好友與申請清單中移除（前端快取）
      friendIds = friendIds.filter(x => x !== targetId);
      sentRequestIds = sentRequestIds.filter(x => x !== targetId);
      receivedRequestIds = receivedRequestIds.filter(x => x !== targetId);

      // Best-effort：清掉雙向好友邀請 / 好友關係（不成功也不影響 UI）
      try {
        await cli.from("friend_requests")
          .delete()
          .or(`and(from_user.eq.${uid},to_user.eq.${targetId}),and(from_user.eq.${targetId},to_user.eq.${uid})`);
      } catch (_e) {}

      // Demo 版不直接操作 friends 表（欄位命名可能不同）；以 friend_requests 狀態為準


      // 刷新畫面
      try { currentBatch = []; renderPeopleGrid(); } catch (_e) {}
      try { renderFriendsList(currentFriendTab || "friends"); } catch (_e) {}

      alert("已封鎖此用戶（已寫入 Supabase）。");
    } catch (e) {
      console.warn("[block] failed", e);
      alert("封鎖失敗（請確認 blocks 表與 RLS）。");
    }
  }

  async function hmReportUser(id) {
    try {
      const targetId = String(id || "");
      if (!isUuid(targetId)) {
        alert("目前檢舉功能只支援 Supabase 真人帳號（UUID）。");
        return;
      }

      const cli = await hmGetSupabaseClient();
      if (!cli) { alert("尚未設定 Supabase 連線。"); return; }

      const uid = await hmGetAuthedUid(cli);
      if (!uid) { alert("請先登入 Email，才能檢舉。"); return; }

      const p = getPersonById(targetId);
      const reason = window.prompt("請輸入檢舉原因（可留空）：", "") || "";
      const cols = await hmDetectReportsCols(cli, uid) || { reporterCol: "reporter_id", reportedCol: "reported_id", reasonCol: "reason" };

      const payload = {};
      payload[cols.reporterCol] = uid;
      payload[cols.reportedCol] = targetId;
      payload[cols.reasonCol] = reason.trim() || "unspecified";

      const res = await cli.from("reports").insert(payload);
      if (res && res.error) throw res.error;

      alert("已送出對「" + (p ? p.name : "此用戶") + "」的檢舉（已寫入 Supabase）。");
    } catch (e) {
      console.warn("[report] failed", e);
      alert("檢舉失敗（請確認 reports 表與 RLS）。");
    }
  }

  async function hmBlockOrReport(id) {
    const p = getPersonById(String(id));
    if (!p) return;

    const choice = window.prompt(
      "請選擇動作：\n1：封鎖此用戶\n2：僅舉報檢舉\n3：封鎖 + 舉報\n（輸入 1 / 2 / 3）",
      "1"
    );
    if (!choice) return;

    if (choice === "1") {
      await hmBlockUser(p.id);
    } else if (choice === "2") {
      await hmReportUser(p.id);
    } else if (choice === "3") {
      await hmBlockUser(p.id);
      await hmReportUser(p.id);
    } else {
      alert("未執行任何動作。");
      return;
    }

    showPage("people");
  }

  let currentFriendTab = "friends";
  let friendTabFriendsEl = null;
  let friendTabSentEl = null;
  let friendTabReceivedEl = null;

  function getPersonById(id) {
    return people.find(p => p.id === id) || null;
  }

  function hmGetRelation(id) {
    if (friendIds.includes(id)) return "friend";
    if (sentRequestIds.includes(id)) return "sent";
    if (receivedRequestIds.includes(id)) return "received";
    return "none";
  }

  function createTabBadgeHTML(num) {
    if (!num) return "";
    return '<span class="friend-tab-badge">' + num + '</span>';
  }

  const HM_LOCAL_FRIEND_KEY = "linko.friend.state.v2";

  function hmArrayUnique(arr) {
    return Array.from(new Set((arr || []).map(x => String(x || "")).filter(Boolean)));
  }

  function hmGetPersonCached(id) {
    const sid = String(id || "");
    let p = getPersonById(sid);
    try {
      if (!p && peopleById && typeof peopleById.get === "function") p = peopleById.get(sid);
      if (!p && peopleById && peopleById[sid]) p = peopleById[sid];
    } catch (_e) {}
    if (!p && friendProfilesById && friendProfilesById[sid]) p = friendProfilesById[sid];
    return p || null;
  }

  function hmReadLocalFriendState() {
    try {
      const raw = localStorage.getItem(HM_LOCAL_FRIEND_KEY);
      const data = raw ? JSON.parse(raw) : {};
      return {
        friends: hmArrayUnique(data.friends),
        sent: hmArrayUnique(data.sent),
        received: hmArrayUnique(data.received),
        rejected: hmArrayUnique(data.rejected),
        profiles: (data.profiles && typeof data.profiles === "object") ? data.profiles : {}
      };
    } catch (_e) {
      return { friends: [], sent: [], received: [], rejected: [], profiles: {} };
    }
  }

  function hmWriteLocalFriendState(state) {
    try {
      localStorage.setItem(HM_LOCAL_FRIEND_KEY, JSON.stringify({
        friends: hmArrayUnique(state.friends),
        sent: hmArrayUnique(state.sent),
        received: hmArrayUnique(state.received),
        rejected: hmArrayUnique(state.rejected),
        profiles: state.profiles || {}
      }));
    } catch (_e) {}
  }

  function hmCacheLocalFriendProfile(state, id) {
    const sid = String(id || "");
    if (!sid) return;
    const p = hmGetPersonCached(sid);
    if (p) {
      state.profiles = state.profiles || {};
      state.profiles[sid] = {
        id: sid,
        name: p.name || "（未設定）",
        region: p.region || "",
        avatar: p.avatar || p.avatar_url || p.avatarUrl || p.avatarURL || "",
        avatar_url: p.avatar_url || p.avatar || "",
        last_seen_at: p.last_seen_at || null,
        status: p.status || "",
        desc: p.desc || ""
      };
    }
  }

  function hmApplyLocalFriendState(state) {
    state = state || hmReadLocalFriendState();
    friendIds = hmArrayUnique(state.friends);
    sentRequestIds = hmArrayUnique(state.sent).filter(id => !friendIds.includes(id));
    receivedRequestIds = hmArrayUnique(state.received).filter(id => !friendIds.includes(id));
    rejectedSentRequestIds = hmArrayUnique(state.rejected).filter(id => !friendIds.includes(id) && !sentRequestIds.includes(id));

    friendProfilesById = friendProfilesById || Object.create(null);
    const allIds = hmArrayUnique([].concat(friendIds, sentRequestIds, receivedRequestIds, rejectedSentRequestIds));
    allIds.forEach(id => {
      const p = hmGetPersonCached(id) || (state.profiles && state.profiles[id]);
      if (p) friendProfilesById[id] = p;
    });

    updateFriendTabCounts();
    renderFriendsList(currentFriendTab || "friends");
  }

  function hmLocalFriendRefresh() {
    const state = hmReadLocalFriendState();
    hmApplyLocalFriendState(state);
  }

  // Supabase 有時候 insert 成功後，因為 RLS / 延遲 / 欄位策略，select pending 不會立刻回來。
  // 這裡保留本機「我已送出」快取，讓「送出申請」分頁一定會立即顯示，等伺服器狀態校正。
  function hmPersistLocalSentRequest(id) {
    const sid = String(id || "");
    if (!sid) return;
    const state = hmReadLocalFriendState();
    hmCacheLocalFriendProfile(state, sid);
    state.sent = hmArrayUnique((state.sent || []).concat(sid));
    state.received = hmArrayUnique(state.received).filter(x => x !== sid);
    state.rejected = hmArrayUnique(state.rejected).filter(x => x !== sid);
    hmWriteLocalFriendState(state);
  }

  function hmRemoveLocalSentRequest(id) {
    const sid = String(id || "");
    if (!sid) return;
    const state = hmReadLocalFriendState();
    state.sent = hmArrayUnique(state.sent).filter(x => x !== sid);
    hmWriteLocalFriendState(state);
  }

  function hmMergeLocalSentRequestsIntoRuntime() {
    const state = hmReadLocalFriendState();
    const localSent = hmArrayUnique(state.sent)
      .filter(id => !friendIds.includes(id))
      .filter(id => !receivedRequestIds.includes(id))
      .filter(id => !rejectedSentRequestIds.includes(id))
      .filter(id => !(blockedIds && blockedIds.length && hmIsBlocked(id)));

    sentRequestIds = hmArrayUnique([].concat(sentRequestIds || [], localSent));

    friendProfilesById = friendProfilesById || Object.create(null);
    localSent.forEach(id => {
      const p = hmGetPersonCached(id) || (state.profiles && state.profiles[id]);
      if (p) friendProfilesById[id] = p;
    });
  }


  function hmSetFriendActionButtonState(btn, stateText, disabled) {
    try {
      if (!btn) return;
      btn.textContent = stateText;
      btn.disabled = !!disabled;
      if (disabled) btn.classList.add("is-loading");
      else btn.classList.remove("is-loading");
    } catch (_e) {}
  }

  function hmOptimisticMoveToSent(id) {
    const sid = String(id || "");
    if (!sid) return;

    // 立即把對方加入「送出申請」，讓使用者不用等 Supabase round-trip。
    hmPersistLocalSentRequest(sid);
    if (!friendIds.includes(sid) && !sentRequestIds.includes(sid)) {
      sentRequestIds = hmArrayUnique((sentRequestIds || []).concat(sid));
    }
    receivedRequestIds = hmArrayUnique(receivedRequestIds || []).filter(x => x !== sid);
    rejectedSentRequestIds = hmArrayUnique(rejectedSentRequestIds || []).filter(x => x !== sid);

    try {
      const p = hmGetPersonCached(sid) || (friendProfilesById && friendProfilesById[sid]);
      if (p) friendProfilesById[sid] = p;
    } catch (_e) {}

    updateFriendTabCounts();
    setFriendTabActive("sent");
    hmGotoPage("friends");
    renderFriendsList("sent");
  }

  function hmLocalAddFriend(id, btn) {
    const sid = String(id || "");
    if (!sid) return;
    hmSetFriendActionButtonState(btn, "申請已送出", true);
    const state = hmReadLocalFriendState();
    hmCacheLocalFriendProfile(state, sid);

    if (state.friends.includes(sid)) {
      hmApplyLocalFriendState(state);
      hmGotoPage("friends");
      openFriendTab("friends");
      alert("你們已經是好友了。");
      return;
    }

    if (state.received.includes(sid)) {
      state.received = state.received.filter(x => x !== sid);
      state.sent = state.sent.filter(x => x !== sid);
      state.rejected = state.rejected.filter(x => x !== sid);
      state.friends = hmArrayUnique(state.friends.concat(sid));
      hmWriteLocalFriendState(state);
      hmApplyLocalFriendState(state);
      hmGotoPage("friends");
      openFriendTab("friends");
      alert("已同意好友申請，已加入好友列表。");
      return;
    }

    if (!state.sent.includes(sid)) {
      state.sent.push(sid);
      state.rejected = state.rejected.filter(x => x !== sid);
    }

    hmWriteLocalFriendState(state);
    hmApplyLocalFriendState(state);
    hmOptimisticMoveToSent(sid);
    alert("已送出好友申請，已移到「好友 > 送出申請」。");
  }

  function hmLocalAcceptFriend(id) {
    const sid = String(id || "");
    const state = hmReadLocalFriendState();
    hmCacheLocalFriendProfile(state, sid);
    state.received = state.received.filter(x => x !== sid);
    state.sent = state.sent.filter(x => x !== sid);
    state.rejected = state.rejected.filter(x => x !== sid);
    state.friends = hmArrayUnique(state.friends.concat(sid));
    hmWriteLocalFriendState(state);
    hmApplyLocalFriendState(state);
    hmGotoPage("friends");
    openFriendTab("friends");
    alert("已同意好友申請。");
  }

  function hmLocalRejectFriend(id) {
    const sid = String(id || "");
    const state = hmReadLocalFriendState();
    hmCacheLocalFriendProfile(state, sid);
    state.received = state.received.filter(x => x !== sid);
    state.rejected = hmArrayUnique(state.rejected.concat(sid));
    hmWriteLocalFriendState(state);
    hmApplyLocalFriendState(state);
    hmGotoPage("friends");
    openFriendTab("received");
    alert("已拒絕好友申請。");
  }

  function hmLocalCancelFriendRequest(id) {
    const sid = String(id || "");
    const state = hmReadLocalFriendState();
    state.sent = state.sent.filter(x => x !== sid);
    state.rejected = state.rejected.filter(x => x !== sid);
    hmWriteLocalFriendState(state);
    hmApplyLocalFriendState(state);
    hmGotoPage("friends");
    openFriendTab("sent");
    alert("已取消好友申請。");
  }

  // 本機測試用：在 console 輸入 hmSimulateIncomingFriendRequest("對方id") 可模擬對方送來申請。
  function hmSimulateIncomingFriendRequest(id) {
    const sid = String(id || "");
    if (!sid) return;
    const state = hmReadLocalFriendState();
    hmCacheLocalFriendProfile(state, sid);
    if (!state.friends.includes(sid) && !state.received.includes(sid)) {
      state.received.push(sid);
      state.sent = state.sent.filter(x => x !== sid);
      hmWriteLocalFriendState(state);
    }
    hmApplyLocalFriendState(state);
    hmGotoPage("friends");
    openFriendTab("received");
  }

  function updateFriendTabCounts() {
    const friendCount = friendIds.length;
    const sentCount = sentRequestIds.length + rejectedSentRequestIds.length;
    const receivedCount = receivedRequestIds.length;

    if (friendTabFriendsEl) friendTabFriendsEl.innerHTML = "好友" + createTabBadgeHTML(friendCount);
    if (friendTabSentEl) friendTabSentEl.innerHTML = "送出申請" + createTabBadgeHTML(sentCount);
    if (friendTabReceivedEl) friendTabReceivedEl.innerHTML = "收到申請" + createTabBadgeHTML(receivedCount);

    const navBadge = document.getElementById("friendNavBadge");
    if (navBadge) {
      const total = sentCount + receivedCount;
      navBadge.textContent = total > 99 ? "99+" : String(total);
      navBadge.style.display = total > 0 ? "inline-block" : "none";
    }
  }

  // 送出好友申請
  
  // 送出好友申請（Supabase）
  async function hmAddFriend(id, btn) {
    try {
      hmSetFriendActionButtonState(btn, "送出中…", true);
      if (!isUuid(id)) {
        hmLocalAddFriend(id, btn);
        return;
      }
      const cli = await hmGetSupabaseClient();
      if (!cli) { hmLocalAddFriend(id, btn); return; }
      const uid = await hmGetAuthedUid(cli);
      if (!uid) { hmLocalAddFriend(id, btn); return; }
      if (id === uid) return alert("不能加自己為好友。");

      // 防止連點造成重複送出（前端保護）
      window.__hmBusy = window.__hmBusy || Object.create(null);
      const busyKey = `addFriend:${uid}:${id}`;
      if (window.__hmBusy[busyKey]) return;
      window.__hmBusy[busyKey] = true;

      // UX：先立即移到「送出申請」並顯示紅點；後面再用 Supabase 結果校正。
      hmOptimisticMoveToSent(id);
      hmSetFriendActionButtonState(btn, "申請已送出", true);

      // 不在這裡刷新，避免剛做好的即時送出狀態被伺服器延遲查詢覆蓋。
      // 後面用 friend_requests 查詢結果來判斷是否已存在。

      // 若已是好友就不重複送
      if (friendIds.includes(id)) {
        alert("你們已經是好友了。");
        return;
      }

      // 是否已送出待回覆，改由下方 friend_requests 查詢判斷；
      // 因為前面已經先做 optimistic sent，不能再用 sentRequestIds 當作 return 條件。

      // 如果你有封鎖或被封鎖，禁止操作（以本地 blockedIds 判斷；伺服器端仍應由 RLS 防護）
      if (Array.isArray(blockedIds) && blockedIds.includes(id)) {
        alert("你已封鎖此用戶，無法送出好友申請。");
        return;
      }

      // 先查資料庫是否已有任一方向的申請（避免 unique constraint 23505）
      const { data: exReq, error: exErr } = await cli
        .from("friend_requests")
        .select("id,from_user,to_user,status")
        .or(`and(from_user.eq.${uid},to_user.eq.${id}),and(from_user.eq.${id},to_user.eq.${uid})`)
        .limit(1)
        .maybeSingle();

      if (exErr) throw exErr;

      if (exReq) {
        const st = exReq.status;

        if (st === "accepted") {
          await hmRefreshFriendsFromSupabase();
          updateFriendTabCounts();
          renderFriendsList("friends");
          alert("你們已經是好友了。");
          return;
        }

        if (st === "pending") {
          // 若是你送出的 pending
          if (exReq.from_user === uid) {
            await hmRefreshFriendsFromSupabase();
            updateFriendTabCounts();
            hmGotoPage("friends");
            openFriendTab("sent");
            alert("已送出好友申請，請耐心等候。");
            return;
          }
          // 若是對方送你的 pending：可直接引導同意
          const ok = confirm("對方已送出好友申請，是否直接同意？");
          if (ok) {
            await hmAcceptFriend(exReq.from_user); // from_user 就是對方
          }
          return;
        }

        if (st === "rejected") {
          // 只允許「送出者」重新送出（避免 RLS 擋 update）
          if (exReq.from_user === uid) {
            const { error: upErr } = await cli
              .from("friend_requests")
              .update({ status: "pending" })
              .eq("from_user", uid)
              .eq("to_user", id);
            if (upErr) throw upErr;

            await hmRefreshFriendsFromSupabase();
            updateFriendTabCounts();
            hmGotoPage("friends");
            openFriendTab("sent");
            alert("已重新送出好友申請。");
            return;
          } else {
            alert("此用戶先前的申請已被你拒絕。若要恢復關係，請讓對方重新送出申請（或你改為同意對方的申請）。");
            return;
          }
        }

        // 其他未知狀態：先刷新再提示
        await hmRefreshFriendsFromSupabase();
        updateFriendTabCounts();
        hmGotoPage("friends");
            openFriendTab("sent");
        /* 已有申請紀錄：不跳提示，直接切到好友 > 送出申請 */
        return;
      }

      // 真正送出申請
      const res = await cli
        .from("friend_requests")
        .insert({ from_user: uid, to_user: id, status: "pending" })
        .select("id")
        .single();

      if (res.error) {
        // 若是 unique constraint（23505），表示已存在，刷新後給提示
        if (res.error.code === "23505") {
          await hmRefreshFriendsFromSupabase();
          updateFriendTabCounts();
          hmGotoPage("friends");
            openFriendTab("sent");
          /* 重複送出時不跳提示，直接切到好友 > 送出申請 */
          return;
        }
        throw res.error;
      }

      await hmRefreshFriendsFromSupabase();
      updateFriendTabCounts();
      hmGotoPage("friends");
            openFriendTab("sent");
      alert("已送出好友申請，已移到「好友 > 送出申請」。");
    } catch (e) {
      console.warn(e);
      try { await hmRefreshFriendsFromSupabase(); } catch (_e) {}
      hmRemoveLocalSentRequest(id);
      sentRequestIds = hmArrayUnique(sentRequestIds || []).filter(x => x !== String(id || ""));
      updateFriendTabCounts();
      renderFriendsList(currentFriendTab || "sent");
      hmSetFriendActionButtonState(btn, "加入好友", false);
      alert("送出申請失敗：" + (e && e.message ? e.message : String(e)));
    } finally {
      try {
        const cli = await hmGetSupabaseClient();
        const uid = cli ? await hmGetAuthedUid(cli) : "";
        const busyKey = `addFriend:${uid}:${id}`;
        if (window.__hmBusy) window.__hmBusy[busyKey] = false;
      } catch (e) {}
    }
  }


  // 同意好友
  
  // 同意對方好友申請（Supabase）
  async function hmAcceptFriend(id) {
    try {
      if (!isUuid(id)) { hmLocalAcceptFriend(id); return; }
      const cli = await hmGetSupabaseClient();
      if (!cli) { hmLocalAcceptFriend(id); return; }
      const uid = await hmGetAuthedUid(cli);
      if (!uid) { hmLocalAcceptFriend(id); return; }

      // 1) update request -> accepted
      const up = await cli
        .from("friend_requests")
        .update({ status: "accepted" })
        .eq("from_user", id)
        .eq("to_user", uid)
        .eq("status", "pending")
        .select("id")
        .maybeSingle();
      if (up.error) throw up.error;

      // 2) Demo 版以 friend_requests.status=accepted 當作好友成立（不依賴 friends 表）


      await hmRefreshFriendsFromSupabase();
      hmGotoPage("friends");
      openFriendTab("friends");
      alert("已同意好友申請。");
    } catch (e) {
      console.warn(e);
      alert("同意失敗：" + (e && e.message ? e.message : String(e)));
    }
  }


  // 拒絕好友
  
  // 拒絕對方好友申請（Supabase）
  async function hmRejectFriend(id) {
    try {
      if (!isUuid(id)) { hmLocalRejectFriend(id); return; }
      const cli = await hmGetSupabaseClient();
      if (!cli) { hmLocalRejectFriend(id); return; }
      const uid = await hmGetAuthedUid(cli);
      if (!uid) { hmLocalRejectFriend(id); return; }

      const up = await cli
        .from("friend_requests")
        .update({ status: "rejected" })
        .eq("from_user", id)
        .eq("to_user", uid)
        .eq("status", "pending")
        .select("id")
        .maybeSingle();
      if (up.error) throw up.error;

      await hmRefreshFriendsFromSupabase();
      hmGotoPage("friends");
      openFriendTab("received");
      alert("已拒絕好友申請。");
    } catch (e) {
      console.warn(e);
      alert("拒絕失敗：" + (e && e.message ? e.message : String(e)));
    }
  }


  // 取消自己送出的申請
  
  // 取消自己送出的好友申請（Supabase）
  async function hmCancelFriendRequest(id) {
    try {
      if (!isUuid(id)) { hmLocalCancelFriendRequest(id); return; }
      const cli = await hmGetSupabaseClient();
      if (!cli) { hmLocalCancelFriendRequest(id); return; }
      const uid = await hmGetAuthedUid(cli);
      if (!uid) { hmLocalCancelFriendRequest(id); return; }

      const up = await cli
        .from("friend_requests")
        .update({ status: "canceled" })
        .eq("from_user", uid)
        .eq("to_user", id)
        .eq("status", "pending")
        .select("id")
        .maybeSingle();
      if (up.error) throw up.error;

      hmRemoveLocalSentRequest(id);
      await hmRefreshFriendsFromSupabase();
      hmGotoPage("friends");
      openFriendTab("sent");
      alert("已取消好友申請。");
    } catch (e) {
      console.warn(e);
      alert("取消失敗：" + (e && e.message ? e.message : String(e)));
    }
  }



  // 解除好友（Supabase：優先將 accepted 關係標記為 removed；若環境政策不允許則改刪除）
  async function hmRemoveFriend(id) {
    try {
      if (!isUuid(id)) return;
      const cli = await hmGetSupabaseClient();
      if (!cli) return alert("Supabase 尚未初始化。");
      const uid = await hmGetAuthedUid(cli);
      if (!uid) return alert("請先登入 Supabase 再操作好友功能。");
      if (id === uid) return alert("不能解除自己。");

      const ok = confirm("確定要解除好友嗎？解除後會回到可重新申請的狀態。");
      if (!ok) return;

      // 先同步一次，避免畫面顯示是好友但本地狀態已過期
      try { await hmRefreshFriendsFromSupabase(); } catch (_e) {}

      // 先查當前 accepted 關係實際是哪個方向存在
      const relRes = await cli
        .from("friend_requests")
        .select("id,from_user,to_user,status")
        .eq("status", "accepted")
        .or(`and(from_user.eq.${uid},to_user.eq.${id}),and(from_user.eq.${id},to_user.eq.${uid})`);

      if (relRes.error) throw relRes.error;

      const acceptedRows = Array.isArray(relRes.data) ? relRes.data : [];
      if (!acceptedRows.length) {
        await hmRefreshFriendsFromSupabase();
        updateFriendTabCounts();
        if (currentProfileId && String(currentProfileId) === String(id)) {
          try { openProfileDetail(id); } catch (_e) {}
        }
        alert("目前查不到好友關係，可能已經解除或狀態已更新。");
        return;
      }

      let changedCount = 0;
      let lastErr = null;

      // 逐筆處理，避免 .or(update) 在某些環境或政策下打不到資料
      for (const row of acceptedRows) {
        const q1 = await cli
          .from("friend_requests")
          .update({ status: "removed" })
          .eq("id", row.id)
          .eq("status", "accepted")
          .select("id");

        if (!q1.error) {
          changedCount += Array.isArray(q1.data) ? q1.data.length : 0;
          continue;
        }

        // 有些專案的 update RLS 可能不允許改狀態，退而求其次刪除 accepted 關係
        const q2 = await cli
          .from("friend_requests")
          .delete()
          .eq("id", row.id)
          .eq("status", "accepted")
          .select("id");

        if (!q2.error) {
          changedCount += Array.isArray(q2.data) ? q2.data.length : 0;
          continue;
        }

        lastErr = q2.error || q1.error;
        console.warn("hmRemoveFriend row failed", { rowId: row.id, updateError: q1.error, deleteError: q2.error });
      }

      await hmRefreshFriendsFromSupabase();
      updateFriendTabCounts();

      const stillFriend = friendIds.includes(String(id));
      if (stillFriend) {
        throw lastErr || new Error("好友狀態仍存在，請檢查 friend_requests 的 update/delete RLS policy。");
      }

      if (currentProfileId && String(currentProfileId) === String(id)) {
        try { openProfileDetail(id); } catch (_e) {}
      }
      hmGotoPage("friends");
      openFriendTab("friends");
      alert("已解除好友。");
    } catch (e) {
      console.warn(e);
      alert("解除好友失敗：" + (e && e.message ? e.message : String(e)));
    }
  }


  // ===== 詳細檔案：VIP + 好友流程 =====
  function openProfileDetail(id) {
    const p = (peopleById && peopleById.get(String(id))) || people.find(x => String(x.id) === String(id));
    if (!p) return;
    currentProfileId = id;

    // 送禮對象（Profile Detail 開啟時更新）
    try { hmGiftSetTarget(p.id, p.name); } catch (e) {}

    let statusClass = "status-badge";
    if (p.status === "busy") statusClass += " status-busy";
    if (p.status === "away" || p.status === "offline") statusClass += " status-away";
    if (p.status === "eating") statusClass += " status-eating";
    if (p.status === "shower") statusClass += " status-shower";

    const statusBadgeHtml =
      '<span class="' + statusClass + '"><span class="status-dot"></span><span>' +
      (p.statusText || "已上線") + "</span></span>";

    const vipLevel = typeof p.vipLevel === "number" ? p.vipLevel : 0;
    const vipTag = '<span class="vip-badge">VIP' + vipLevel + '</span>';

    const relation = hmGetRelation(p.id);
    let actionHtml = "";

    if (relation === "friend") {
      actionHtml = ''
        + '<div class="profile-action-row">'
        + '  <button class="btn btn-primary" onclick="openChatWith(\'' + p.id + '\')">1 對 1 聊天</button>'
        + '  <button class="btn btn-danger-soft" onclick="hmRemoveFriend(\'' + p.id + '\')">解除好友</button>'
        + '</div>'
        + '<div class="profile-action-note">已經是好友，若想保留互動感也可以先維持好友，只把聊天節奏放慢。</div>';
    } else if (relation === "sent") {
      actionHtml = ''
        + '<div class="profile-action-row">'
        + '  <button class="btn btn-soft" disabled>已送出好友申請</button>'
        + '  <button class="btn btn-outline" onclick="hmCancelFriendRequest(\'' + p.id + '\')">取消申請</button>'
        + '</div>'
        + '<div class="profile-action-note">申請已送到對方的「收到申請」，目前等待對方確認。</div>';
    } else if (relation === "received") {
      actionHtml = ''
        + '<div class="profile-action-row">'
        + '  <button class="btn btn-primary" onclick="event.stopPropagation(); hmAcceptFriend(\'' + p.id + '\')">加入好友</button>'
        + '  <button class="btn btn-outline" onclick="event.stopPropagation(); hmRejectFriend(\'' + p.id + '\')">拒絕</button>'
        + '</div>'
        + '<div class="profile-action-note">這個請求來自對方的加入好友申請，確認後就會進到好友列表。</div>';
    } else {
      actionHtml = ''
        + '<div class="profile-action-row">'
        + '  <button class="btn btn-primary" onclick="hmAddFriend(\'' + p.id + '\', this)">加入好友</button>'
        + '</div>'
        + '<div class="profile-action-note">想慢慢升溫的話，先加好友再開聊會比直接衝聊天更自然。</div>';
    }

    const totalSlots = (Array.isArray(p.album) && p.album.length > 0)
      ? p.album.length
      : 6;

    const myVipLevel = hmGetVipLevel();
    const unlocked = hmAlbumIsUnlocked();

    const albumHtml = Array.from({ length: totalSlots }).map((_, idx) => {
      const src = hmGetPersonAlbumPhotoSrc(p.id, idx);
      const isFree = idx < 2;
      const isLocked = !isFree && myVipLevel === 0 && !unlocked;
      const lockedClass = isLocked ? " locked" : "";
      return ''
        + '<div class="album-item' + lockedClass + '" onclick="handleStrangerAlbumClick(\'' + p.id + '\',' + idx + ')">'
        + '  <img src="' + src + '" alt="photo' + (idx + 1) + '" />'
        + '  <div class="album-gift-btn" onclick="event.stopPropagation(); sendGiftAnimation(this)">💝 送禮</div>'
        + '</div>';
    }).join("");

    profileDetailContent.innerHTML = ''
      + '<div class="profile-header">'
      + '  <div class="profile-row-main">'
      + '    <div class="profile-avatar">'
      + '      <img src="' + p.avatar + '" alt="' + p.name + '" />'
      + '    </div>'
      + '    <div>'
      + '      <div class="profile-name">' + p.name + ' ' + vipTag + '</div>'
      + '      <div class="profile-sub">' + p.ageText + ' · 台灣 · 暫無更多介紹</div>'
      + '      <div id="hm-recv-stats" class="profile-sub" style="margin-top:4px; font-size:13px; color:#6b7280;">收到玫瑰：<span id="hm-recv-roses">🌹 0</span></div>'
      + '      <div style="margin-top:6px; font-size:15px;">' + statusBadgeHtml + '</div>'
      + '    </div>'
      + '  </div>'
      + '  <div class="profile-actions">'
      +      actionHtml
      + '    <button class="btn btn-outline" onclick="hmBlockOrReport(\'' + p.id + '\')">封鎖 / 舉報</button>'
      + '  </div>'
      + '</div>'
      + '<div class="section">'
      + '  <div class="profile-cta-row">'
      + '    <button class="big-cta-btn primary" onclick="sendGiftAnimationFromHeader(this)">🌹 送玫瑰</button>'
      + '  </div>'
      + '</div>'
      + '<div class="section">'
      + '  <div class="section-title">相簿（每張都可送玫瑰）</div>'
      + '  <div class="album-grid">'
      +       albumHtml
      + '  </div>'
      + '  <div class="album-note">'
      + '    相簿僅示意，正式版可以上傳自己的照片、設定可見範圍與解鎖方式。<br/>'
      + '    Demo：前兩張為免費預覽，後四張需觀看廣告才可在 20 分鐘內解鎖。'
      + '  </div>'
      + '</div>'
      + '<div class="section">'
      + '  <div class="section-title">基本資料</div>'
      + '  <table class="info-table">'
      + '    <tr><td class="info-key">暱稱</td><td class="info-value">' + p.name + '</td></tr>'
      + '    <tr><td class="info-key">性別</td><td class="info-value">' + (p.genderText || '未設定') + '</td></tr>'
      + '    <tr><td class="info-key">年齡層</td><td class="info-value">' + p.ageText + '</td></tr>'
      + '    <tr><td class="info-key">國家</td><td class="info-value">台灣</td></tr>'
      + '    <tr><td class="info-key">地區</td><td class="info-value">未設定</td></tr>'
      + '    <tr><td class="info-key">自我介紹</td><td class="info-value">' + p.desc + '</td></tr>'
      + '  </table>'
      + '</div>'
      + '<div class="section">'
      + '  <div class="section-title">公開日記</div>'
      + '  <div class="diary-list" id="publicDiaryList"></div>'
      + '</div>';

    showPage("profileDetail");
    topTitleEl.textContent = p.name;
    topRightSlot.innerHTML = "";


    // 載入對方收到的道具統計（🌹/🎁）
    try { hmLoadReceivedGiftStatsIntoDetail(p.id); } catch (_e) {}
    // 載入對方公開日記（Supabase diaries）
    try { hmLoadPublicDiariesIntoDetail(p.id); } catch (_e) {}
  }

  // ==== 好友列表 ====
  function renderStatusInline(status, text) {
    let cls = "status-badge status-inline";
    if (status === "online") cls += " status-busy";
    if (status === "busy") cls += " status-busy";
    if (status === "away" || status === "offline") cls += " status-away";
    if (status === "eating") cls += " status-eating";
    if (status === "shower") cls += " status-shower";
    return '<span class="' + cls + '"><span class="status-dot"></span><span>' + text + "</span></span>";
  }

  
    // 查看用戶對外資料：好友 / 送出申請 / 收到申請 都可點進去看（沿用巧遇同一個對外資料頁）
  async function hmOpenPublicProfile(id) {
  if (!id) return;

  const cli = await hmGetSupabaseClient();
  if (!cli || !isUuid(id)) {
    const pLocal = hmGetPersonCached(id);
    if (pLocal) {
      friendProfilesById[String(id)] = pLocal;
      openProfileDetail(String(id));
      return;
    }
    alert("讀取對外資料失敗。");
    return;
  }

  // 重要：不要直接用快取資料開啟（避免跨裝置更新後，仍顯示舊頭像/相簿/性別年齡等資訊）
  // 每次點擊頭像/照片進入「對外資料夾」時，都即時向 Supabase 拉最新 profiles + profile_photos。
  const pr = await cli.from("profiles").select("*").eq("id", id).single();
  if (pr.error || !pr.data) {
    console.warn("[hmOpenPublicProfile] fetch profiles failed:", pr.error);
    alert("讀取對外資料失敗（profiles）。請稍後再試。");
    return;
  }

  const p = hmNormalizeProfileRow(pr.data);

  // 重新抓照片（頭貼/相簿），確保最新
  await hmAttachPhotosToPeople(cli, [p]);

  // 更新快取（供巧遇/好友/聊天列表重用）
  peopleById[p.id] = p;
  friendProfilesById[p.id] = p;

  openProfileDetail(p.id);
}

// 保留此函式名：openProfileDetail(id) 會被多處呼叫（例如巧遇卡片/聊天頭像），避免舊按鈕失效
  function hmOpenFriendProfile(id) {
    hmOpenPublicProfile(id);
  }

function renderFriendsList(type) {
    friendsListEl.innerHTML = "";
    currentFriendTab = type;
    const noteText = (friendNoteInput && friendNoteInput.value.trim()) || "（尚未設定）";

    let ids = [];
    if (type === "friends") ids = friendIds.slice();
    else if (type === "sent") ids = sentRequestIds.concat(rejectedSentRequestIds);
    else if (type === "received") ids = receivedRequestIds.slice();

    if (!ids.length) {
      const li = document.createElement("li");
      li.className = "list-item";
      const err = (friendLastError && String(friendLastError).trim()) ? ('<div class="item-row3" style="color:#ef4444;">讀取好友資料失敗：' + String(friendLastError).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").slice(0,180) + '</div>') : '';
      li.innerHTML = '<div class="avatar"></div>'
        + '<div class="item-main">'
        + '<div class="item-row1"><div class="item-name">（清單目前為空）</div></div>'
        + '<div class="item-row2">切換上方「好友 / 送出申請 / 收到申請」查看不同清單。</div>'
        + err
        + '<div class="item-row3">（此區已改為 Supabase 真實資料；若你尚未建立好友/邀請，會顯示空清單）</div>'
        + '</div>';friendsListEl.appendChild(li);
      return;
    }

    ids.forEach((id) => {
      const p = friendProfilesById[id] || { id, name: "（未設定）", region: "", avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22160%22%20height%3D%22160%22%20viewBox%3D%220%200%20160%20160%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%2280%22%20cy%3D%2261%22%20r%3D%2222%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2235%22%20y%3D%2293%22%20width%3D%2290%22%20height%3D%2226%22%20rx%3D%228%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2213%22%20fill%3D%22%237c3aed%22%3ELinko%20160%C3%97160%3C/text%3E%0A%3C/svg%3E", last_seen_at: null };
      const st = onlineStatusFromLastSeen(p.last_seen_at);
      const statusHtml = renderStatusInline(st.status, st.text);

      const safeId = "\'" + String(id).replace(/\'/g, "\\\'") + "\'"; // 支援 UUID
      const avatar = (p && (p.avatar || p.avatar_url || p.avatarUrl || p.avatarURL)) || "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22160%22%20height%3D%22160%22%20viewBox%3D%220%200%20160%20160%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%2280%22%20cy%3D%2261%22%20r%3D%2222%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2235%22%20y%3D%2293%22%20width%3D%2290%22%20height%3D%2226%22%20rx%3D%228%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2213%22%20fill%3D%22%237c3aed%22%3ELinko%20160%C3%97160%3C/text%3E%0A%3C/svg%3E";

      let row3Html = "";
      let extraActionsHtml = "";

      if (type === "friends") {
        row3Html = '<div class="item-row3"><span class="label">好友限定：</span>' + noteText + '</div>';
        extraActionsHtml = ''
          + '<div class="item-row3">'
          + '  <button class="btn btn-sm" onclick="event.stopPropagation(); hmOpenFriendProfile(' + safeId + ')">查看資料</button>'
          + '</div>';
      } else if (type === "sent") {
        const isRejected = rejectedSentRequestIds.includes(id);
        row3Html = isRejected
          ? '<div class="item-row3"><span class="label">狀態：</span><span class="friend-status-rejected">對方已拒絕</span></div>'
          : '<div class="item-row3"><span class="label">狀態：</span>已送出好友申請，等待對方回應</div>';
        extraActionsHtml = isRejected
          ? ''
            + '<div class="item-row3">'
            + '  <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); hmAddFriend(' + safeId + ')">重新申請</button>'
            + '</div>'
          : ''
            + '<div class="item-row3">'
            + '  <button class="btn btn-sm" onclick="event.stopPropagation(); hmCancelFriendRequest(' + safeId + ')">取消申請</button>'
            + '</div>';
      } else if (type === "received") {
        row3Html = '<div class="item-row3"><span class="label">狀態：</span>對方想加你為好友</div>';
        extraActionsHtml = ''
          + '<div class="item-row3">'
          + '  <button class="btn btn-sm" onclick="event.stopPropagation(); hmOpenPublicProfile(' + safeId + ')">查看資料</button>'
          + '  <button class="btn btn-sm" onclick="event.stopPropagation(); hmAcceptFriend(' + safeId + ')">同意</button>'
          + '  <button class="btn btn-sm btn-outline" onclick="event.stopPropagation(); hmRejectFriend(' + safeId + ')">拒絕</button>'
          + '</div>';
      }

      const li = document.createElement("li");
      li.className = "list-item";
      li.innerHTML = ''
        + '<div class="avatar"><img src="' + avatar + '" alt="avatar"></div>'
        + '<div class="item-main">'
        + '  <div class="item-row1">'
        + '    <div class="item-name">' + (p.name || "（未設定）") + '</div>'
        + '    <div class="item-right">' + statusHtml + '</div>'
        + '  </div>'
        + '  <div class="item-row2"><span class="label">地區：</span>' + (p.region || "—") + '</div>'
        + row3Html
        + extraActionsHtml
        + '</div>';

      // 點整列可開啟對方對外資料（按鈕已 stopPropagation，不會誤觸）
      li.addEventListener("click", function () { hmOpenPublicProfile(id); });

      friendsListEl.appendChild(li);
    });
  }

  // ==== 排行榜假資料 ====
  const rankPyramidEl = document.getElementById("rankPyramid");
  const rankListEl = document.getElementById("rankList");

  const rankData = {
    pop: [
      { pos: 1, title: "King", name: "Sunny", city: "台北", age: "20+", score: 9820, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 2, title: "Princess", name: "Amy", city: "高雄", age: "25+", score: 9130, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 3, title: "Prince", name: "Max", city: "新北", age: "22+", score: 8990, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 4, title: "Duke", name: "Lynn", city: "台中", age: "23+", score: 8500, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 5, title: "Duke", name: "Zero", city: "桃園", age: "20+", score: 8420, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 6, title: "Duchess", name: "Mika", city: "台南", age: "27+", score: 8300, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 7, title: "Marquis", name: "阿哲", city: "新竹", age: "28+", score: 7900, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 8, title: "Baron", name: "小葉", city: "基隆", age: "24+", score: 7600, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" }
    ],
    receive: [
      { pos: 1, title: "Queen", name: "Rin", city: "台北", age: "21+", score: 10010, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 2, title: "Princess", name: "Nana", city: "新北", age: "26+", score: 9200, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 3, title: "Duke", name: "Ken", city: "高雄", age: "29+", score: 8800, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 4, title: "Duchess", name: "Sasa", city: "桃園", age: "23+", score: 8400, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" }
    ],
    send: [
      { pos: 1, title: "King", name: "Leo", city: "台中", age: "30+", score: 11000, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 2, title: "Prince", name: "Sean", city: "台北", age: "24+", score: 9600, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 3, title: "Duke", name: "Kai", city: "新北", age: "27+", score: 9000, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" },
      { pos: 4, title: "Baron", name: "米糕", city: "花蓮", age: "32+", score: 8200, avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E" }
    ]
  };

  function renderRank(type) {
    const data = rankData[type] || [];
    if (data.length === 0) {
      rankPyramidEl.innerHTML = "<div style='font-size:14px; color:#9ca3af; text-align:center;'>暫無排名資料</div>";
      rankListEl.innerHTML = "";
      return;
    }

    const king = data[0];
    const second = data[1];
    const third = data[2];
    const fourth = data[3];
    const fifth = data[4];
    const sixth = data[5];
    const rest = data.slice(6);

    let pyramidHtml = ''
      + '<div class="rank-row">'
      + '  <div class="rank-card">'
      + '    <div class="rank-badge">'
      + '      <span class="icon">👑</span>'
      + '      <span>' + king.title + '</span>'
      + '    </div>'
      + '    <div class="rank-avatar-wrap king">'
      + '      <div class="rank-avatar">'
      + '        <img src="' + king.avatar + '" alt="' + king.name + '" />'
      + '      </div>'
      + '    </div>'
      + '    <div class="rank-name">' + king.name + '</div>'
      + '    <div class="rank-sub">' + king.city + ' · ' + king.age + '</div>'
      + '  </div>'
      + '</div>';

    pyramidHtml += '<div class="rank-row">';
    if (second) {
      pyramidHtml += ''
        + '<div class="rank-card">'
        + '  <div class="rank-avatar-wrap">'
        + '    <div class="rank-avatar medium">'
        + '      <img src="' + second.avatar + '" alt="' + second.name + '" />'
        + '    </div>'
        + '  </div>'
        + '  <div class="rank-name">' + second.name + '</div>'
        + '  <div class="rank-sub">' + second.title + ' · ' + second.city + '</div>'
        + '</div>';
    }
    if (third) {
      pyramidHtml += ''
        + '<div class="rank-card">'
        + '  <div class="rank-avatar-wrap">'
        + '    <div class="rank-avatar medium">'
        + '      <img src="' + third.avatar + '" alt="' + third.name + '" />'
        + '    </div>'
        + '  </div>'
        + '  <div class="rank-name">' + third.name + '</div>'
        + '  <div class="rank-sub">' + third.title + ' · ' + third.city + '</div>'
        + '</div>';
    }
    pyramidHtml += '</div>';

    pyramidHtml += '<div class="rank-row">';
    [fourth, fifth, sixth].forEach(item => {
      if (!item) return;
      pyramidHtml += ''
        + '<div class="rank-card">'
        + '  <div class="rank-avatar-wrap">'
        + '    <div class="rank-avatar small">'
        + '      <img src="' + item.avatar + '" alt="' + item.name + '" />'
        + '    </div>'
        + '  </div>'
        + '  <div class="rank-name">' + item.name + '</div>'
        + '  <div class="rank-sub">' + item.title + ' · ' + item.city + '</div>'
        + '</div>';
    });
    pyramidHtml += '</div>';

    rankPyramidEl.innerHTML = pyramidHtml;

    rankListEl.innerHTML = "";
    rest.forEach(item => {
      const li = document.createElement("div");
      li.className = "rank-list-item";
      li.innerHTML = ''
        + '<div class="rank-pos">' + item.pos + '</div>'
        + '<div class="rank-list-avatar">'
        + '  <img src="' + item.avatar + '" alt="' + item.name + '" />'
        + '</div>'
        + '<div class="rank-list-main">'
        + '  <div class="rank-list-name">' + item.name + ' · ' + item.title + '</div>'
        + '  <div class="rank-list-sub">' + item.city + ' · ' + item.age + '</div>'
        + '</div>'
        + '<div class="rank-score">' + item.score + ' 分</div>';
      rankListEl.appendChild(li);
    });
  }

  const pages = {
    people: document.getElementById("page-people"),
    profileDetail: document.getElementById("page-profileDetail"),
    friends: document.getElementById("page-friends"),
    mood: document.getElementById("page-mood"),
    rank: document.getElementById("page-rank"),
    chat: document.getElementById("page-chat"),
    me: document.getElementById("page-me")
  };

  function showPage(pageName) {
    Object.keys(pages).forEach(k => {
      pages[k].classList.toggle("active", k === pageName);
    });

    // 進入好友頁時：從 Supabase 拉取真實好友/邀請資料
    try {
      if (pageName === "friends") {
        hmRefreshFriendsFromSupabase();
      }
    } catch (e) {}

    // 進入巧遇頁時：從 Supabase 拉取真實 profiles（排除自己），取代 Demo 假資料
    try {
      if (pageName === "people") {
        hmLoadPeopleFromSupabase(false);
      }
    } catch (e) {}

    try { hmUpdateMeetFullscreenState(); } catch (e) {}
  }

  function renderTopRightForPage(pageName) {
    topRightSlot.innerHTML = "";
    if (pageName === "me") {
      const btn = document.createElement("button");
      btn.className = "icon-button";
      btn.innerHTML = ''
        + '<svg class="icon-gear" viewBox="0 0 20 20" fill="none">'
        + '<path d="M9.999 12.5a2.5 2.5 0 1 0 0-5.001 2.5 2.5 0 0 0 0 5z" stroke="#4B5563" stroke-width="1.3" />'
        + '<path d="M15.167 8.583a5.53 5.53 0 0 0-.11-.44l1.16-1.174a.55.55 0 0 0 .09-.648l-1.1-1.905a.55.55 0 0 0-.628-.26l-1.62.49a5.43 5.43 0 0 0-.77-.44l-.25-1.68A.55.55 0 0 0 11.41 2h-2.2a.55.55 0 0 0-.546.46l-.25 1.68a5.42 5.42 0 0 0-.77.44l-1.62-.49a.55.55 0 0 0-.629.26L4.295 5.3a.55.55 0 0 0 .09.649l1.16 1.173c-.05.144-.087.291-.11.441L4.5 8.999a.55.55 0 0 0-.5.546v2.91c0 .29.219.53.5.546l1.935.12c.034.145.077.288.129.429l-1.178 1.24a.55.55 0 0 0-.067.659l1.2 1.856a.55.55 0 0 0 .622.239l1.74-.56c.13.073.263.14.4.2l.27 1.78a.55.55 0 0 0 .545.46h2.2a.55.55 0 0 0 .545-.46l.27-1.78c.137-.06.27-.127.4-.2l1.74.56a.55.55 0 0 0 .622-.239l1.2-1.857a.55.55 0 0 0-.068-.658l-1.177-1.24c.052-.141.095-.284.129-.429l1.935-.12a.55.55 0 0 0 .5-.547v-2.91a.55.55 0 0 0-.5-.546L15.167 8.583z" stroke="#4B5563" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>'
        + '</svg>';
      btn.addEventListener("click", () => {
        alert("設定面板之後會接上真正的功能（目前為示意）。");
      });
      topRightSlot.appendChild(btn);
    }
  }

  function switchPage(pageName) {
    if (pageName === "shop") {
      try { if (typeof hmOpenShopModal === "function") hmOpenShopModal(); } catch (e) {}
      return;
    }
    if (pageName === "people") topTitleEl.textContent = "人們 · Linko";
    if (pageName === "friends") topTitleEl.textContent = "好友";
    if (pageName === "mood") topTitleEl.textContent = "心情廣場";
    if (pageName === "rank") topTitleEl.textContent = "排行榜";
    if (pageName === "chat") topTitleEl.textContent = "聊天";
    if (pageName === "me") topTitleEl.textContent = "我的檔案";

    if (pageName !== "profileDetail") {
      showPage(pageName);
    }
    renderTopRightForPage(pageName);

    // 進入好友頁時自動同步好友/邀請資料（避免清單看起來永遠是空的）
    if (pageName === "friends") {
      try { setFriendTabActive(currentFriendTab || "friends"); } catch (e) {}
      try { renderFriendsList(currentFriendTab || "friends"); } catch (e) {}
      hmScheduleFriendRefresh(120);
    }

    // 切換到其他頁面時，自動關閉聊天室滑窗
    if (pageName !== "chat") {
      hideChatPanel();
    }
  }

  // 開啟聊天：只有好友可以
  function openChatWith(id) {
    const relation = hmGetRelation(id);
    if (relation !== "friend") {
      alert("只有成為好友後才能使用 1 對 1 聊天。（Demo）");
      return;
    }
    ensureFriendChatThread(id);
    switchPage("chat");
    openChatThread("friend-" + id);
  }

  window.openChatWith = openChatWith;
  window.hmAddFriend = hmAddFriend;
  window.hmAcceptFriend = hmAcceptFriend;
  window.hmRejectFriend = hmRejectFriend;
  window.hmCancelFriendRequest = hmCancelFriendRequest;
  window.hmSimulateIncomingFriendRequest = hmSimulateIncomingFriendRequest;

  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", () => {
      const page = item.getAttribute("data-page");
      document.querySelectorAll(".nav-item").forEach(i => i.classList.remove("active"));
      item.classList.add("active");
      switchPage(page);

      if (page === "rank") renderRank(currentRankTab);
    });
  });


  // 好友頁 tab 操作（避免從其他頁觸發後 UI 沒同步）
  function setFriendTabActive(type) {
    const t = type || "friends";
    document.querySelectorAll("[data-friendtab]").forEach(b => b.classList.remove("active"));
    const btn = document.querySelector('[data-friendtab="' + t + '"]');
    if (btn) btn.classList.add("active");
    currentFriendTab = t;
  }

  function openFriendTab(type) {
    setFriendTabActive(type);
    // 先用目前資料立即繪製，背景延遲刷新；避免「空清單 → 有資料」或「有資料 → 空清單」閃爍。
    renderFriendsList(currentFriendTab);
    hmScheduleFriendRefresh(120);
  }

  function hmGotoPage(page) {
    const nav = document.querySelector('.nav-item[data-page="' + page + '"]');
    if (nav && typeof nav.click === "function") nav.click();
    else switchPage(page);
  }

  document.querySelectorAll("[data-friendtab]").forEach(btn => {
    btn.addEventListener("click", () => {
      const type = btn.getAttribute("data-friendtab");
      openFriendTab(type);
    });
  });

  let currentRankTab = "pop";
  document.querySelectorAll("[data-ranktab]").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("[data-ranktab]").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentRankTab = btn.getAttribute("data-ranktab");
      renderRank(currentRankTab);
    });
  });

  // toggle
  document.querySelectorAll(".toggle").forEach(t => {
    t.addEventListener("click", () => {
      t.classList.toggle("on");
    });
  });


  // 聊天送出 & + 功能（改為列表式對話：官方 + 好友）
  const chatMessagesEl = document.getElementById("chatMessages");
  const chatInputEl = document.getElementById("chatInput");
  const chatSendBtn = document.getElementById("chatSendBtn");
  const stickerBar = document.getElementById("stickerBar");
  const chatMoreMenu = document.getElementById("chatMoreMenu");
  const chatPlusBtn = document.getElementById("chatPlusBtn");
  const chatWrapper = document.getElementById("chatWrapper");
  const chatPhotoBtn = document.getElementById("chatPhotoBtn");
  const chatGifBtn = document.getElementById("chatGifBtn");
  const chatPhotoInput = document.getElementById("chatPhotoInput");
  const chatGifInput = document.getElementById("chatGifInput");
  const chatThreadListEl = document.getElementById("chatThreadList");
  const chatPanel = document.getElementById("chatPanel");
  const chatBackBtn = document.getElementById("chatBackBtn");
  const chatPanelTitleEl = document.getElementById("chatPanelTitle");
  const chatPanelSubtitleEl = document.getElementById("chatPanelSubtitle");

  let currentChatThreadId = null;
  const chatThreads = {};
  const chatHistories = {};

  function ensureChatThread(thread) {
    if (!thread || !thread.id) return;
    if (!chatThreads[thread.id]) {
      chatThreads[thread.id] = thread;
    }
    if (!chatHistories[thread.id]) {
      chatHistories[thread.id] = [];
    }
  }

  function ensureFriendChatThread(personId) {
    const p = getPersonById(personId);
    if (!p) return;
    const id = "friend-" + personId;
    if (!chatThreads[id]) {
      ensureChatThread({
        id,
        personId,
        title: p.name,
        preview: p.desc || "成為好友後即可開始聊天。",
        isOfficial: false,
        pinned: false,
        avatar: p.avatar,
        unread: 0
      });
    }
  }

  function showChatPanel(thread) {
    if (!chatPanel) return;
    chatPanel.classList.add("show");

    if (chatPanelTitleEl) {
      if (thread && thread.isOfficial) {
        chatPanelTitleEl.textContent = "Linko小精靈";
      } else if (thread && thread.personId) {
        const p = getPersonById(thread.personId);
        chatPanelTitleEl.textContent = (p && p.name) ? p.name : (thread.title || "聊天");
      } else if (thread && thread.title) {
        chatPanelTitleEl.textContent = thread.title;
      } else {
        chatPanelTitleEl.textContent = "聊天";
      }
    }

    if (chatPanelSubtitleEl) {
      if (thread && thread.isOfficial) {
        chatPanelSubtitleEl.textContent = "官方訊息 / 系統公告";
      } else if (thread && thread.personId) {
        chatPanelSubtitleEl.textContent = "1 對 1 聊天";
      } else {
        chatPanelSubtitleEl.textContent = "";
      }
    }
  }

  function hideChatPanel() {
    if (!chatPanel) return;
    chatPanel.classList.remove("show");
  }

  function renderChatThreadList() {
    if (!chatThreadListEl) return;
    const threads = Object.values(chatThreads).filter(t => !t.hidden);

    threads.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });

    chatThreadListEl.innerHTML = "";

    threads.forEach(thread => {
      const li = document.createElement("li");
      li.className = "list-item";
      li.dataset.threadId = thread.id;

      const avatarDiv = document.createElement("div");
      avatarDiv.className = "avatar";
      avatarDiv.innerHTML = '<img src="' + (thread.avatar || "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E") + '" alt="' + thread.title + '">';
      li.appendChild(avatarDiv);

      const main = document.createElement("div");
      main.className = "item-main";

      const row1 = document.createElement("div");
      row1.className = "item-row1";

      const left = document.createElement("div");
      left.className = "item-row1-left";

      const nameSpan = document.createElement("span");
      nameSpan.className = "item-name";
      nameSpan.textContent = thread.title;
      left.appendChild(nameSpan);

      if (thread.isOfficial) {
        const moodSpan = document.createElement("span");
        moodSpan.className = "item-mood";
        moodSpan.textContent = "📢";
        left.appendChild(moodSpan);
      }

      row1.appendChild(left);

      if (thread.unread && thread.unread > 0) {
        const badge = document.createElement("span");
        badge.className = "friend-tab-badge";
        badge.textContent = thread.unread > 99 ? "99+" : String(thread.unread);
        row1.appendChild(badge);
      }

      main.appendChild(row1);

      const row2 = document.createElement("div");
      row2.className = "item-row2";
      row2.textContent = thread.preview || "";
      main.appendChild(row2);

      if (thread.isOfficial) {
        const row3 = document.createElement("div");
        row3.className = "item-row3";
        row3.innerHTML = '<span class="label">官方通知：</span>此聊天室會放置系統公告、活動通知，可刪除（Demo）。';
        main.appendChild(row3);
      }

      li.appendChild(main);

      if (thread.isOfficial) {
        const delBtn = document.createElement("button");
        delBtn.type = "button";
        delBtn.className = "btn btn-sm";
        delBtn.textContent = "刪除";
        delBtn.style.marginLeft = "8px";
        delBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          if (!confirm("確定要從列表中移除官方訊息嗎？（Demo）")) return;
          thread.hidden = true;
          if (currentChatThreadId === thread.id) {
            currentChatThreadId = null;
            if (chatMessagesEl) {
              chatMessagesEl.innerHTML = "";
            }
            topTitleEl.textContent = "聊天";
          }
          renderChatThreadList();
        });
        li.appendChild(delBtn);
      }

      li.addEventListener("click", () => {
        openChatThread(thread.id);
      });

      chatThreadListEl.appendChild(li);
    });
  }

  function renderChatMessages(threadId) {
    if (!chatMessagesEl) return;
    const msgs = chatHistories[threadId] || [];

    chatMessagesEl.innerHTML = "";

    if (!msgs.length) {
      const row = document.createElement("div");
      row.className = "bubble-row";
      row.innerHTML = '<div class="bubble them">尚未開始聊天，先傳一則訊息試試看。（Demo）</div>';
      chatMessagesEl.appendChild(row);
      return;
    }

    msgs.forEach(msg => {
      const row = document.createElement("div");
      row.className = "bubble-row" + (msg.from === "me" ? " me" : "");
      let inner = "";

      if (msg.type === "image" && msg.dataUrl) {
        inner = '<img src="' + msg.dataUrl + '" alt="' + (msg.label || "image") + '" class="chat-image" />';
      } else {
        inner = (msg.text || "").replace(/\n/g, "<br>");
      }

      row.innerHTML = '<div class="bubble ' + (msg.from === "me" ? "me" : "them") + '">' + inner + "</div>";
      chatMessagesEl.appendChild(row);
    });

    chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
  }

  function openChatThread(threadId) {
    const thread = chatThreads[threadId];
    if (!thread) return;

    currentChatThreadId = threadId;
    thread.unread = 0;
    renderChatThreadList();

    // 保持頂部標題為「聊天」，實際對話對象顯示在聊天室視窗內
    topTitleEl.textContent = "聊天";

    renderChatMessages(threadId);
    showChatPanel(thread);
  }

  function initChatModule() {
    if (!chatThreadListEl) return;

    // 官方聊天室
    ensureChatThread({
      id: "official",
      title: "Linko小精靈（官方）",
      preview: "歡迎加入Linko！有任何問題可以在這裡詢問我。",
      isOfficial: true,
      pinned: true,
      avatar: "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E",
      unread: 1
    });

    if (!chatHistories["official"] || chatHistories["official"].length === 0) {
      chatHistories["official"] = [
        {
          from: "them",
          type: "text",
          text: "歡迎來到「Linko」聊天介面示意。\n目前是前端原型，未連接真實後端。"
        },
        {
          from: "me",
          type: "text",
          text: "老闆你可以切換上方聊天背景、試試輸入文字、用下面的 + 號打開貼圖 / 照片 / GIF。"
        }
      ];
    }

    // 依照現有好友列表建立對話室
    friendIds.forEach(fid => {
      ensureFriendChatThread(fid);
    });

    renderChatThreadList();
  }

  function sendChat() {
    if (!chatInputEl) return;
    const text = chatInputEl.value.trim();
    if (!text) return;
    if (!currentChatThreadId) {
      alert("請先從上方聊天列表選擇一個對話，再輸入訊息。（Demo）");
      return;
    }
    const msgs = chatHistories[currentChatThreadId] || (chatHistories[currentChatThreadId] = []);
    msgs.push({
      from: "me",
      type: "text",
      text,
      ts: Date.now()
    });

    const thread = chatThreads[currentChatThreadId];
    if (thread) {
      thread.preview = text;
    }

    chatInputEl.value = "";
    renderChatMessages(currentChatThreadId);
    renderChatThreadList();
  }

  chatSendBtn.addEventListener("click", sendChat);
  chatInputEl.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendChat();
    }
  });

  chatPlusBtn.addEventListener("click", () => {
    chatMoreMenu.classList.toggle("show");
  });

  // 貼圖 / 照片 / GIF
  chatMoreMenu.querySelectorAll(".chat-more-btn").forEach(btn => {
    const type = btn.getAttribute("data-type");
    if (type === "sticker") {
      btn.addEventListener("click", () => {
        stickerBar.classList.toggle("show");
      });
    }
  });

  function sendImageMessage(dataUrl, label) {
    if (!currentChatThreadId) {
      alert("請先從上方聊天列表選擇一個對話，再傳送圖片。（Demo）");
      return;
    }
    const msgs = chatHistories[currentChatThreadId] || (chatHistories[currentChatThreadId] = []);
    msgs.push({
      from: "me",
      type: "image",
      dataUrl,
      label,
      ts: Date.now()
    });

    const thread = chatThreads[currentChatThreadId];
    if (thread && !thread.preview) {
      thread.preview = label === "gif" ? "[GIF]" : "[圖片]";
    }

    renderChatMessages(currentChatThreadId);
    renderChatThreadList();
  }

  chatPhotoBtn.addEventListener("click", () => {
    chatPhotoInput.click();
  });
  chatGifBtn.addEventListener("click", () => {
    chatGifInput.click();
  });

  chatPhotoInput.addEventListener("change", e => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const dataUrl = ev.target && ev.target.result;
      if (!dataUrl) return;
      sendImageMessage(dataUrl, "photo");
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  });

  chatGifInput.addEventListener("change", e => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const dataUrl = ev.target && ev.target.result;
      if (!dataUrl) return;
      sendImageMessage(dataUrl, "gif");
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  });

  stickerBar.querySelectorAll(".sticker-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const emo = btn.textContent || "";
      chatInputEl.value += emo;
      chatInputEl.focus();
    });
  });

  // 聊天背景主題
  document.querySelectorAll(".chat-theme-pill").forEach(pill => {
    pill.addEventListener("click", () => {
      document.querySelectorAll(".chat-theme-pill").forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      const theme = pill.getAttribute("data-theme");
      chatWrapper.className = "chat-wrapper chat-theme-" + theme;
    });
  });

  // 我的狀態
  const statusSelect = document.getElementById("statusSelect");
  const myStatusBadge = document.getElementById("myStatusBadge");
  const myStatusText = document.getElementById("myStatusText");
  const myProfileSub = document.getElementById("myProfileSub");
  function updateMyStatus() {
    const val = statusSelect.value;
    let text = "已上線";
    let cls = "status-badge";

    if (val === "online") text = "已上線";
    if (val === "busy") { text = "忙碌中…"; cls += " status-busy"; }
    if (val === "eating") { text = "用餐去…"; cls += " status-eating"; }
    if (val === "shower") { text = "洗澡中…"; cls += " status-shower"; }
    if (val === "away") { text = "暫離中…"; cls += " status-away"; }
    if (val === "offline") { text = "離線中"; cls += " status-away"; }
    if (val === "chatty") text = "想聊天";

    myStatusBadge.className = cls;
    myStatusText.textContent = text;
    myProfileSub.textContent = "台灣 · 30 歲左右 · " + text;
  }
  statusSelect.addEventListener("change", updateMyStatus);

  // 好友限定小語同步預覽
  const friendNoteInput = document.getElementById("friendNoteInput");
  const friendNotePreview = document.getElementById("friendNotePreview");
  function updateFriendNotePreview() {
    const t = friendNoteInput.value.trim() || "（尚未設定）";
    friendNotePreview.innerHTML = '<span class="label">好友限定：</span>' + t;
  }
  friendNoteInput.addEventListener("input", updateFriendNotePreview);

  // 我的日記（免費 3 則，VIP 可至 30 則）模組
  function hmHasVipDiaryAccess() {
    try {
      if (typeof hmIsVipEntitledActive === "function" && hmIsVipEntitledActive()) return true;
    } catch (e) {}
    return hmGetVipLevel() > 0;
  }

  function hmGetDiaryLimit() {
    return hmHasVipDiaryAccess() ? 30 : 3;
  }

  function hmLoadDiaries() {
    try {
      const raw = localStorage.getItem("hmMyDiaries");
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function hmSaveDiaries(list) {
    try {
      localStorage.setItem("hmMyDiaries", JSON.stringify(list));
    } catch (e) {}
  }

  function hmDeleteDiary(diaryId) {
    const list = hmLoadDiaries().filter(d => d.id !== diaryId);
    hmSaveDiaries(list);
    renderMyDiaries();
  }

  function renderMyDiaries() {
    const listEl = document.getElementById("myDiaryList");
    const limitTextEl = document.getElementById("myDiaryLimitText");
    if (!listEl || !limitTextEl) return;

    const diaries = hmLoadDiaries();
    const limit = hmGetDiaryLimit();
    const vip = hmHasVipDiaryAccess() ? 1 : 0;

    limitTextEl.textContent = vip > 0
      ? "目前已建立 " + diaries.length + " 則日記，VIP 身份最多可建立 " + limit + " 則。"
      : "目前已建立 " + diaries.length + " 則日記，免費版最多可建立 " + limit + " 則，升級 VIP 後可到 30 則。";

    listEl.innerHTML = "";

    if (!diaries.length) {
      const empty = document.createElement("div");
      empty.className = "diary-item";
      empty.innerHTML = '<div class="diary-date">尚未建立任何日記</div><div>可以寫幾句想讓別人看到的自我介紹或心情。</div>';
      listEl.appendChild(empty);
      return;
    }

    diaries.slice().reverse().forEach(diary => {
      const item = document.createElement("div");
      item.className = "diary-item";

      const header = document.createElement("div");
      header.style.display = "flex";
      header.style.justifyContent = "space-between";
      header.style.alignItems = "center";

      const dateDiv = document.createElement("div");
      dateDiv.className = "diary-date";
      const time = diary.createdAt ? new Date(diary.createdAt) : new Date();
      const y = time.getFullYear();
      const m = String(time.getMonth() + 1).padStart(2, "0");
      const day = String(time.getDate()).padStart(2, "0");
      const hh = String(time.getHours()).padStart(2, "0");
      const mm = String(time.getMinutes()).padStart(2, "0");
      dateDiv.textContent = y + "-" + m + "-" + day + " " + hh + ":" + mm;

      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "btn btn-sm";
      delBtn.textContent = "刪除";
      delBtn.addEventListener("click", () => {
        if (confirm("確定要刪除這則日記嗎？（Demo）")) {
          hmDeleteDiary(diary.id);
        }
      });

      header.appendChild(dateDiv);
      header.appendChild(delBtn);
      item.appendChild(header);

      if (diary.image) {
        const img = document.createElement("img");
        img.src = diary.image;
        img.alt = "日記圖片";
        img.style.maxWidth = (diary.imageSize || 100) + "%";
        img.style.borderRadius = "12px";
        img.style.marginTop = "6px";
        img.style.marginBottom = "6px";
        item.appendChild(img);
      }

      if (diary.text) {
        const textDiv = document.createElement("div");
        textDiv.innerHTML = String(diary.text).replace(/\n/g, "<br>");
        textDiv.style.fontSize = (Number(diary.textSize) || 18) + "px";
        textDiv.style.lineHeight = "1.65";
        item.appendChild(textDiv);
      }

      listEl.appendChild(item);
    });
  }


  // Viewer & 送禮動畫
  function openPhotoViewer(src) {
    const viewer = document.getElementById("photoViewer");
    const img = viewer.querySelector("img");
    img.src = src;
    viewer.classList.add("show");
  }
  function closeViewer() {
    document.getElementById("photoViewer").classList.remove("show");
  }
  window.openPhotoViewer = openPhotoViewer;
  window.closeViewer = closeViewer;

  // 依「使用者 id + 第幾張」取得對方的相簿照片
  function hmGetPersonAlbumPhotoSrc(personId, idx) {
    const p = getPersonById(personId);
    if (p && Array.isArray(p.album) && p.album[idx]) {
      return p.album[idx];
    }
    if (albumPhotos && albumPhotos[idx]) {
      return albumPhotos[idx];
    }
    return "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E" + (901 + idx);
  }

  function spawnHeart(x, y) {
    const h = document.createElement("div");
    h.className = "gift-heart";
    h.textContent = "💗";
    h.style.left = x + "px";
    h.style.top = y + "px";
    document.body.appendChild(h);
    setTimeout(() => h.remove(), 1000);
  }
  // ====== 送禮（消耗道具：🌹玫瑰 / 🎁小禮物） ======
  let hmGiftTarget = null;     // { id, name }
  let hmGiftAnchor = null;     // { x, y }

  function hmGiftSetTarget(id, name) {
    hmGiftTarget = { id: String(id || ""), name: String(name || "") };
  }

    async function hmGiftRenderInventory() {
    const invEl = document.getElementById("hm-gift-inventory");
    if (!invEl) return;
    try {
      const elig = await hmRewardGetEligibility();
      if (!elig.ok) { invEl.textContent = "—"; return; }
      const inv = await hmBackendGetInventory();
      const roses = inv && typeof inv.roses === "number" ? Math.max(0, Math.floor(inv.roses)) : 0;
      invEl.textContent = "🌹 玫瑰：" + roses;
    } catch (e) {
      invEl.textContent = "—";
    }
  }

  async function hmOpenGiftModal() {
    const modal = document.getElementById("hm-gift-modal");
    if (!modal) return;

    const subEl = document.getElementById("hm-gift-sub");
    const hintEl = document.getElementById("hm-gift-hint");
    const roseBtn = document.getElementById("hm-send-rose-btn");
    const giftBtn = document.getElementById("hm-send-gift-btn");

    const name = (hmGiftTarget && hmGiftTarget.name) ? hmGiftTarget.name : "";
    if (subEl) subEl.textContent = name ? ("送給：" + name) : "選擇要送出的玫瑰";

    await hmGiftRenderInventory();

    try {
      const elig = await hmRewardGetEligibility();
      if (!elig.ok) {
        if (hintEl) hintEl.textContent = "送禮需先完成 Email 綁定與基本資料。";
        if (roseBtn) roseBtn.disabled = true;
        if (giftBtn) giftBtn.disabled = true;
      } else {
        if (hintEl) hintEl.textContent = "點選下方按鈕即可送出玫瑰。";
        if (roseBtn) roseBtn.disabled = false;
        if (giftBtn) giftBtn.disabled = false;
      }
    } catch (e) {
      if (hintEl) hintEl.textContent = "目前無法送禮。";
    }

    modal.style.display = "flex";
  }

  function hmCloseGiftModal() {
    const modal = document.getElementById("hm-gift-modal");
    if (!modal) return;
    modal.style.display = "none";
  }

  async function hmSendGift(kind) {
    const hintEl = document.getElementById("hm-gift-hint");
    if (hintEl) hintEl.textContent = "送出中…";

    const toId = (hmGiftTarget && hmGiftTarget.id) ? String(hmGiftTarget.id) : "";
    if (!toId) {
      if (hintEl) hintEl.textContent = "尚未選擇送禮對象";
      return;
    }

    const res = await hmBackendSendGift(toId, kind, 1);
    if (!res.ok) {
      if (hintEl) hintEl.textContent = res.reason || "送出失敗";
      try { await hmGiftRenderInventory(); } catch (e) {}
      return;
    }

    // 小動畫：從按鈕位置噴出愛心
    try {
      const x = hmGiftAnchor && Number.isFinite(hmGiftAnchor.x) ? hmGiftAnchor.x : (window.innerWidth / 2);
      const y = hmGiftAnchor && Number.isFinite(hmGiftAnchor.y) ? hmGiftAnchor.y : 120;
      spawnHeart(x, y);
    } catch (e) {}

    const msg = "已送出 🌹 玫瑰 x1";
    if (hintEl) hintEl.textContent = msg;

    try { await hmRewardRenderUI({}); } catch (e) {}
    try { await hmUpdateMoodRoseUI(); } catch (e) {}
    try { await hmGiftRenderInventory(); } catch (e) {}
    try { await hmLoadReceivedGiftStatsIntoDetail(toId); } catch (e) {}

    setTimeout(() => {
      hmCloseGiftModal();
    }, 450);
  }

  function hmInitGiftModal() {
    const modal = document.getElementById("hm-gift-modal");
    if (!modal || modal.dataset.bound) return;
    modal.dataset.bound = "1";

    const closeBtn = document.getElementById("hm-gift-close-btn");
    const roseBtn = document.getElementById("hm-send-rose-btn");
    const giftBtn = document.getElementById("hm-send-gift-btn");

    if (closeBtn) closeBtn.addEventListener("click", hmCloseGiftModal);
    if (roseBtn) roseBtn.addEventListener("click", async () => { await hmSendGift("roses"); });
    if (giftBtn) giftBtn.style.display = "none";

    // 點背景關閉
    modal.addEventListener("click", (e) => {
      if (e.target === modal) hmCloseGiftModal();
    });
  }

  function sendGiftAnimation(el) {
    const rect = el.getBoundingClientRect();
    hmGiftAnchor = { x: rect.left + rect.width / 2, y: rect.top };
    hmOpenGiftModal();
  }
  function sendGiftAnimationFromHeader(btn) {
    const rect = btn.getBoundingClientRect();
    hmGiftAnchor = { x: rect.left + rect.width / 2, y: rect.top };
    hmOpenGiftModal();
  }
  function setAsAvatar(idx) {
    let newAvatar;
    if (currentProfileId != null) {
      newAvatar = hmGetPersonAlbumPhotoSrc(currentProfileId, idx);
    } else {
      newAvatar = hmGetAlbumPhotoSrc(idx);
    }
    const avatarImg = document.querySelector(".profile-avatar img");
    if (avatarImg) avatarImg.src = newAvatar;
    alert("已把這張照片設為頭貼！（Demo）");
  }
  window.sendGiftAnimation = sendGiftAnimation;
  window.sendGiftAnimationFromHeader = sendGiftAnimationFromHeader;
  window.setAsAvatar = setAsAvatar;

  // ====== 對外資料：收到道具統計（累積） ======
  async function hmBackendGetReceivedGiftStats(userId) {
    const id = String(userId || "");
    if (!id) return { ok: false, reason: "no_user" };

    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) return { ok: false, reason: "no_sb" };

      const rpc = await cli.rpc("get_received_gift_stats", { p_user: id });
      if (rpc && rpc.error) {
        return { ok: false, reason: String(rpc.error.message || "rpc_error") };
      }

      const data = rpc && rpc.data ? rpc.data : null;
      const roses = data && typeof data.roses === "number" ? Math.max(0, Math.floor(data.roses)) : parseInt((data && data.roses) || "0", 10) || 0;
      const gifts = data && typeof data.gifts === "number" ? Math.max(0, Math.floor(data.gifts)) : parseInt((data && data.gifts) || "0", 10) || 0;
      return { ok: true, roses, gifts };
    } catch (e) {
      return { ok: false, reason: "fetch_failed" };
    }
  }

  async function hmLoadReceivedGiftStatsIntoDetail(userId) {
    const roseEl = document.getElementById("hm-recv-roses");
    const giftEl = document.getElementById("hm-recv-gifts");
    const boxEl = document.getElementById("hm-recv-stats");
    if (!roseEl || !boxEl) return;

    // 先顯示 loading
    roseEl.textContent = "🌹 —";
    giftEl.textContent = "";

    const res = await hmBackendGetReceivedGiftStats(userId);
    if (!res.ok) {
      // 若未建後端/無權限，仍以 0 顯示，避免 UI 空白
      roseEl.textContent = "🌹 0";
      giftEl.textContent = "";
      return;
    }

    roseEl.textContent = "🌹 " + String(res.roses);
    giftEl.textContent = "";
  }

  // ================== 心情日記廣場（Supabase posts / post_replies） ==================
  
  // in-memory cache（避免每次切頁重打 API）
  let hmMoodPostsCache = [];
  const hmMoodRepliesCache = new Map(); // postId -> replies[]
  const hmMoodAuthorCache = new Map();  // userId -> { name, avatar }

  
  // ====== 道具庫存（與每日簽到共用 inventory：roses / gifts） ======
  let hmMoodRosesCache = 0;

    async function hmSyncInventoryCache() {
    // 後端化：以 Supabase inventories 為權威資料
    try {
      const elig = await hmRewardGetEligibility();
      if (!elig.ok) {
        hmMoodRosesCache = 0;
        return { ok: false, reason: elig.reason };
      }
      const inv = await hmBackendGetInventory();
      const r = inv && typeof inv.roses === "number" ? inv.roses : 0;
      hmMoodRosesCache = Math.max(0, Math.floor(r));
      return { ok: true, inventory: inv };
    } catch (e) {
      hmMoodRosesCache = 0;
      return { ok: false, reason: "讀取失敗" };
    }
  }

  function hmLoadMoodRoses() {
    return Number.isFinite(hmMoodRosesCache) ? hmMoodRosesCache : 0;
  }

    async function hmConsumeInventory(kind, amount, opts) {
    // kind: "roses" | "gifts"
    amount = parseInt(amount || "0", 10);
    if (!Number.isFinite(amount) || amount <= 0) return { ok: false, reason: "數量錯誤" };

    const elig = await hmRewardGetEligibility();
    if (!elig.ok) return { ok: false, reason: elig.reason };

    try {
      const res = await hmBackendConsumeItem(kind, amount, opts || {});
      if (!res.ok) return res;

      // 同步 UI / cache
      try { await hmSyncInventoryCache(); } catch (e) {}
      try { await hmGiftRenderInventory(); } catch (e) {}
      try { await hmRewardRenderUI({}); } catch (e) {}
      return res;
    } catch (e) {
      return { ok: false, reason: "扣款失敗" };
    }
  }

  async function hmUpdateMoodRoseUI() {
    await hmSyncInventoryCache();
    const roseEl = document.getElementById("moodRoseCount");
    if (!roseEl) return;
    roseEl.textContent = String(hmLoadMoodRoses());
  }

  function hmLoadMoodPosts() {
    return Array.isArray(hmMoodPostsCache) ? hmMoodPostsCache : [];
  }

  function hmSetMoodPosts(list) {
    hmMoodPostsCache = Array.isArray(list) ? list : [];
  }

  function hmMoodGetAuthor(uid) {
    const id = String(uid || "");
    return hmMoodAuthorCache.get(id) || null;
  }

  async function hmMoodGetClientAndUid() {
    const cli = await hmGetSupabaseClient();
    if (!cli) return { ok: false, reason: "no_sb" };

    const sessRes = await cli.auth.getSession();
    const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
    if (!session || !session.user) return { ok: false, reason: "no_session", cli };

    return { ok: true, cli, uid: session.user.id };
  }

  function hmMoodNormalizePostRow(r) {
    const id = String(r && r.id ? r.id : "");
    const userId = String(r && r.user_id ? r.user_id : "");
    const createdAt = r && r.created_at ? Date.parse(r.created_at) : Date.now();
    return {
      id,
      user_id: userId,
      content: String((r && r.content) || ""),
      image_url: r && r.image_url ? String(r.image_url) : "",
      createdAt: Number.isFinite(createdAt) ? createdAt : Date.now(),
      is_anonymous: (r && r.is_anonymous === true) || (r && r.identity === "anon"),
      allow_replies: (r && r.allow_replies === false) ? false : true
    };
  }

  function hmMoodNormalizeReplyRow(r) {
    const id = String(r && r.id ? r.id : "");
    const postId = String(r && r.post_id ? r.post_id : "");
    const userId = String(r && r.user_id ? r.user_id : "");
    const createdAt = r && r.created_at ? Date.parse(r.created_at) : Date.now();
    return {
      id,
      post_id: postId,
      user_id: userId,
      body: String((r && (r.body || r.text)) || ""),
      createdAt: Number.isFinite(createdAt) ? createdAt : Date.now(),
      is_anonymous: (r && r.is_anonymous === true) || (r && r.identity === "anon")
    };
  }

  async function hmMoodHydrateAuthors(cli, userIds) {
    try {
      if (!cli) return;
      const ids = Array.from(new Set((userIds || []).map(x => String(x)).filter(isUuid)));
      if (!ids.length) return;

      // profiles
      const pRes = await cli
        .from("profiles")
        .select("id,name,region,age,age_range,avatar_url")
        .in("id", ids);

      if (pRes && pRes.data) {
        (pRes.data || []).forEach(row => {
          const id = String(row.id || "");
          if (!id) return;
          const cur = hmMoodAuthorCache.get(id) || {};
          hmMoodAuthorCache.set(id, {
            name: String(row.name || cur.name || "未設定"),
            avatar: String(row.avatar_url || cur.avatar || "")
          });
        });
      }

      // avatar from profile_photos（避免依賴 foreign key relationship）
      const ownerCol = await hmDetectProfilePhotosOwnerCol(cli);
    const cols = await hmDetectProfilePhotosCols(cli);
    const urlCol = (cols && cols.urlCol) ? cols.urlCol : "url";
    const isAvatarCol = (cols && cols.isAvatarCol) ? cols.isAvatarCol : "is_avatar";
      const chunkSize = 50;
      const allRows = [];
      for (let i = 0; i < ids.length; i += chunkSize) {
        const chunk = ids.slice(i, i + chunkSize);
        const r = await cli
          .from("profile_photos")
          .select(ownerCol + "," + urlCol + "," + isAvatarCol + ",created_at")
          .in(ownerCol, chunk)
          .order("created_at", { ascending: false });
        if (r && r.data) allRows.push(...r.data);
      }

      const byUser = new Map();
      allRows.forEach(row => {
        const uid = String(row[ownerCol] || "");
        if (!uid) return;
        if (!byUser.has(uid)) byUser.set(uid, []);
        byUser.get(uid).push(row);
      });

      ids.forEach(uid => {
        const rows = byUser.get(uid) || [];
        const avatarRow = rows.find(x => x[isAvatarCol] === true) || null;
        if (avatarRow && avatarRow[urlCol]) {
          const cur = hmMoodAuthorCache.get(uid) || {};
          hmMoodAuthorCache.set(uid, {
            name: String(cur.name || "未設定"),
            avatar: String(avatarRow[urlCol])
          });
        }
      });
    } catch (e) {
      // ignore hydration errors（避免影響主要列表）
    }
  }

  async function hmMoodLoadRepliesForPosts(cli, postIds) {
    hmMoodRepliesCache.clear();
    const ids = Array.from(new Set((postIds || []).map(x => String(x)).filter(isUuid)));
    if (!ids.length) return [];

    const res = await cli
      .from("post_replies")
      .select("id,post_id,user_id,body,is_anonymous,created_at")
      .in("post_id", ids)
      .order("created_at", { ascending: true });

    if (res.error) {
      // 如果你還沒建立 post_replies，會在此報錯；前端只顯示 0 則回覆
      return [];
    }

    const replies = (res.data || []).map(hmMoodNormalizeReplyRow);
    replies.forEach(r => {
      if (!hmMoodRepliesCache.has(r.post_id)) hmMoodRepliesCache.set(r.post_id, []);
      hmMoodRepliesCache.get(r.post_id).push(r);
    });
    return replies;
  }

  async function hmRefreshMoodFromSupabase() {
    const listEl = document.getElementById("moodList");
    const emptyEl = document.getElementById("moodEmptyHint");
    if (listEl) listEl.innerHTML = '<div style="padding:10px;color:#6b7280;">載入中…</div>';
    if (emptyEl) emptyEl.style.display = "none";

    const { ok, cli, uid, reason } = await hmMoodGetClientAndUid();
    if (!ok) {
      hmSetMoodPosts([]);
      hmMoodRepliesCache.clear();
      if (listEl) listEl.innerHTML = "";
      if (emptyEl) {
        emptyEl.style.display = "block";
        emptyEl.textContent = "請先在『填寫資料』區登入 Email，才能查看心情廣場。";
      }
      return;
    }

    // 更新封鎖清單，並在前端過濾被你封鎖的用戶
    try { await hmRefreshBlockedIdsFromSupabase(cli, uid); } catch (e) {}

    // posts（兼容：若欄位尚未加上 is_anonymous / allow_replies，會自動降級）
    let pRes = await cli
      .from("posts")
      .select("id,user_id,content,image_url,created_at,is_anonymous,allow_replies")
      .order("created_at", { ascending: false })
      .limit(80);

    if (pRes.error && String(pRes.error.message || "").toLowerCase().includes("is_anonymous")) {
      pRes = await cli
        .from("posts")
        .select("id,user_id,content,image_url,created_at")
        .order("created_at", { ascending: false })
        .limit(80);
    }

    if (pRes.error) {
      hmSetMoodPosts([]);
      hmMoodRepliesCache.clear();
      if (listEl) listEl.innerHTML = "";
      if (emptyEl) {
        emptyEl.style.display = "block";
        emptyEl.textContent = "讀取心情廣場失敗：" + (pRes.error.message || "unknown");
      }
      return;
    }

    const posts = (pRes.data || []).map(hmMoodNormalizePostRow)
      .filter(p => !blockedIds.includes(String(p.user_id)));

    hmSetMoodPosts(posts);

    // replies（一次抓回覆，計算回覆數；若尚未建表則為空）
    let allReplies = [];
    try {
      allReplies = await hmMoodLoadRepliesForPosts(cli, posts.map(p => p.id));
    } catch (e) {
      allReplies = [];
    }

    // hydrate authors（僅抓非匿名的發文/回覆作者）
    const authorIds = [];
    posts.forEach(p => { if (!p.is_anonymous && isUuid(p.user_id)) authorIds.push(p.user_id); });
    (allReplies || []).forEach(r => { if (!r.is_anonymous && isUuid(r.user_id)) authorIds.push(r.user_id); });

    await hmMoodHydrateAuthors(cli, authorIds);

    hmRenderMoodList();
  }

  async function hmMoodInsertPost() {
    const contentEl = document.getElementById("moodContentInput");
    const allowEl = document.getElementById("moodAllowReplies");
    if (!contentEl) return;

    const content = String(contentEl.value || "").trim();
    if (!content) { alert("請先輸入內容"); return; }

    await hmSyncInventoryCache();
    const roses = hmLoadMoodRoses();
    if (roses <= 0) {
      alert("🌹 玫瑰不足，請先簽到領取。");
      return;
    }

    const identity = document.querySelector('input[name="moodIdentity"]:checked')?.value || "anon";
    const isAnon = identity !== "public";
    const allowReplies = allowEl ? !!allowEl.checked : true;

    const { ok, cli, uid } = await hmMoodGetClientAndUid();
    if (!ok) { alert("請先登入 Email，才能發佈"); return; }

    // 發文：每日最多 3 篇（後端硬限制：create_post_with_limit RPC）
    try {
      const rpc = await cli.rpc("create_post_with_limit", {
        p_content: content,
        p_is_anonymous: isAnon,
        p_allow_replies: allowReplies
      });
      const data = rpc && rpc.data ? rpc.data : null;
      if (data && data.ok) {
        // RPC 內已扣除 🌹 並寫入貼文
        try { await hmBackendGetInventory({ force: true }); } catch (e) {}
        try { await hmSyncInventoryCache(); } catch (e) {}
        try { await hmUpdateMoodRoseUI(); } catch (e) {}
        try { await hmGiftRenderInventory(); } catch (e) {}
        try { await hmRewardRenderUI({ force: true }); } catch (e) {}

        contentEl.value = "";
        if (allowEl) allowEl.checked = true;
        const anonRadio = document.querySelector('input[name="moodIdentity"][value="anon"]');
        if (anonRadio) anonRadio.checked = true;

        await hmRefreshMoodFromSupabase();
        return;
      }
      if (data && data.ok === false && data.reason) {
        const r = String(data.reason || "");
        if (r === "daily_post_limit") { alert("今日心情貼文已達上限（3 篇）。"); return; }
        if (r === "insufficient_roses") { alert("🌹 玫瑰不足，請先簽到領取。"); return; }
        // 其他原因：落回舊流程（相容舊後端）
      }
      if (rpc && rpc.error) {
        const msg = String(rpc.error.message || "");
        // 若 RPC 不存在，落回舊流程（相容舊後端）
        if (!msg.includes("create_post_with_limit")) {
          console.warn("create_post_with_limit RPC error:", rpc.error);
        }
      }
    } catch (e) {
      // ignore（相容舊後端）
    }

    // 相容舊後端：前端 best-effort 擋每日上限（無法替代後端硬限制）
    try {
      const ctx = hmRewardTzYmd();
      const start = ctx.ymd + "T00:00:00+08:00";
      const end = ctx.ymd + "T23:59:59+08:00";
      const cntRes = await cli
        .from("posts")
        .select("id", { count: "exact", head: true })
        .eq("user_id", uid)
        .gte("created_at", start)
        .lte("created_at", end);
      const c = (cntRes && typeof cntRes.count === "number") ? cntRes.count : 0;
      if (c >= 3) { alert("今日心情貼文已達上限（3 篇）。"); return; }
    } catch (e) {}

    // 優先寫入新版欄位；若欄位不存在，會自動降級只寫基本欄位
    let ins = await cli
      .from("posts")
      .insert({
        user_id: uid,
        content: content,
        image_url: "",
        is_anonymous: isAnon,
        allow_replies: allowReplies
      })
      .select("id")
      .limit(1);

    if (ins.error && String(ins.error.message || "").toLowerCase().includes("is_anonymous")) {
      ins = await cli
        .from("posts")
        .insert({
          user_id: uid,
          content: content,
          image_url: ""
        })
        .select("id")
        .limit(1);
    }

    if (ins.error) {
      alert("發佈失敗：" + (ins.error.message || "unknown"));
      return;
    }

    await hmConsumeInventory("roses", 1);
    await hmUpdateMoodRoseUI();
    try { await hmRewardRenderUI({}); } catch (e) {}

    contentEl.value = "";
    if (allowEl) allowEl.checked = true;
    const anonRadio = document.querySelector('input[name="moodIdentity"][value="anon"]');
    if (anonRadio) anonRadio.checked = true;

    await hmRefreshMoodFromSupabase();
  }

  async function hmMoodInsertReply(postId, text, isAnon) {
    const { ok, cli, uid } = await hmMoodGetClientAndUid();
    if (!ok) { alert("請先登入 Email，才能回覆"); return { ok: false }; }

    const pid = String(postId || "");
    if (!isUuid(pid)) { alert("回覆失敗：post_id 不正確"); return { ok: false }; }

    const body = String(text || "").trim();
    if (!body) return { ok: false };

    // 回覆：每日免費 3 則；第 4 則起每則消耗 🎁 x1（後端硬限制：create_reply_with_limit RPC）
    try {
      const rpc = await cli.rpc("create_reply_with_limit", {
        p_post_id: pid,
        p_body: body,
        p_is_anonymous: !!isAnon
      });
      const data = rpc && rpc.data ? rpc.data : null;
      if (data && data.ok) {
        // 可能有扣 🎁，統一刷新一次庫存 UI/cache
        try { await hmBackendGetInventory({ force: true }); } catch (e) {}
        try { await hmSyncInventoryCache(); } catch (e) {}
        try { await hmUpdateMoodRoseUI(); } catch (e) {}
        try { await hmGiftRenderInventory(); } catch (e) {}
        try { await hmRewardRenderUI({ force: true }); } catch (e) {}
        return { ok: true };
      }
      if (data && data.ok === false && data.reason) {
        const r = String(data.reason || "");
        if (r === "insufficient_gifts") { alert("🎁 小禮物不足（超過每日免費回覆 3 則後，每則回覆需 🎁 x1）。"); return { ok: false }; }
        if (r === "post_not_found") { alert("回覆失敗：貼文不存在"); return { ok: false }; }
        if (r === "replies_not_allowed") { alert("這則貼文已關閉回覆"); return { ok: false }; }
        // 其他原因：落回舊流程（相容舊後端）
      }
      if (rpc && rpc.error) {
        const msg = String(rpc.error.message || "");
        if (!msg.includes("create_reply_with_limit")) {
          console.warn("create_reply_with_limit RPC error:", rpc.error);
        }
      }
    } catch (e) {
      // ignore（相容舊後端）
    }

    // 相容舊後端：前端 best-effort（無法替代後端硬限制）
    try {
      const ctx = hmRewardTzYmd();
      const start = ctx.ymd + "T00:00:00+08:00";
      const end = ctx.ymd + "T23:59:59+08:00";
      const cntRes = await cli
        .from("post_replies")
        .select("id", { count: "exact", head: true })
        .eq("user_id", uid)
        .gte("created_at", start)
        .lte("created_at", end);
      const c = (cntRes && typeof cntRes.count === "number") ? cntRes.count : 0;
      if (c >= 3) {
        // 超過免費 3 則：扣 🎁 x1
        await hmSyncInventoryCache();
        const inv = await hmBackendGetInventory();
        const g = inv && typeof inv.gifts === "number" ? inv.gifts : 0;
        if (g <= 0) { alert("🎁 小禮物不足（超過每日免費回覆 3 則後，每則回覆需 🎁 x1）。"); return { ok: false }; }
        const pay = await hmConsumeInventory("gifts", 1, { reason: "mood_reply" });
        if (!pay || pay.ok === false) { alert(pay && pay.reason ? pay.reason : "扣除小禮物失敗"); return { ok: false }; }
      }
    } catch (e) {}

    let ins = await cli
      .from("post_replies")
      .insert({
        post_id: pid,
        user_id: uid,
        body: body,
        is_anonymous: !!isAnon
      })
      .select("id")
      .limit(1);

    if (ins.error && String(ins.error.message || "").toLowerCase().includes("relation") && String(ins.error.message || "").toLowerCase().includes("post_replies")) {
      alert("目前尚未建立 post_replies 資料表，請先在 Supabase SQL Editor 執行 schema 補齊 SQL。");
      return { ok: false, need_schema: true };
    }

    if (ins.error && String(ins.error.message || "").toLowerCase().includes("is_anonymous")) {
      ins = await cli
        .from("post_replies")
        .insert({
          post_id: pid,
          user_id: uid,
          body: body
        })
        .select("id")
        .limit(1);
    }

    if (ins.error) {
      alert("回覆失敗：" + (ins.error.message || "unknown"));
      return { ok: false };
    }

    return { ok: true };
  }

  function hmMoodBindProfileClick(el, uid) {
    try {
      if (!el) return;
      const id = String(uid || "");
      if (!isUuid(id)) return;
      el.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        hmOpenPublicProfile(id);
      });
      el.classList.add("hm-profile-click");
    } catch (e) {}
  }

  function hmRenderMoodList() {
    const listEl = document.getElementById("moodList");
    const emptyEl = document.getElementById("moodEmptyHint");
    if (!listEl) return;

    const posts = hmLoadMoodPosts()
      .slice()
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    listEl.innerHTML = "";

    if (!posts.length) {
      if (emptyEl) {
        emptyEl.style.display = "block";
        emptyEl.textContent = "目前沒有任何貼文";
      }
      return;
    }
    if (emptyEl) emptyEl.style.display = "none";

    posts.forEach(post => {
      const card = document.createElement("div");
      card.className = "mood-item";

      const header = document.createElement("div");
      header.className = "mood-item-header";

      const leftWrap = document.createElement("div");
      leftWrap.className = "mood-item-author-wrap";

      const avatarDiv = document.createElement("div");
      avatarDiv.className = "mood-item-avatar";

      const author = hmMoodGetAuthor(post.user_id);
      const isAnon = !!post.is_anonymous;
      const avatarUrl = (author && author.avatar) ? author.avatar : "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E";
      avatarDiv.innerHTML = '<img src="' + avatarUrl + '" alt="avatar">';

      if (!isAnon) {
        hmMoodBindProfileClick(avatarDiv, post.user_id);
      } else {
        avatarDiv.classList.add("is-anon");
        avatarDiv.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:18px;color:#9ca3af;">?</div>';
      }

      const authorDiv = document.createElement("div");
      authorDiv.className = "mood-item-author";

      const nameDiv = document.createElement("div");
      nameDiv.className = "mood-item-author-name";
      nameDiv.textContent = isAnon ? "匿名用戶" : (author && author.name ? author.name : "未設定");

      if (!isAnon) {
        nameDiv.classList.add("is-clickable");
        hmMoodBindProfileClick(nameDiv, post.user_id);
      }

      const metaDiv = document.createElement("div");
      metaDiv.className = "mood-item-meta";
      const t = new Date(post.createdAt || Date.now());
      const y = t.getFullYear();
      const m = String(t.getMonth() + 1).padStart(2, "0");
      const d = String(t.getDate()).padStart(2, "0");
      const hh = String(t.getHours()).padStart(2, "0");
      const mm = String(t.getMinutes()).padStart(2, "0");
      metaDiv.textContent = y + "-" + m + "-" + d + " " + hh + ":" + mm;

      authorDiv.appendChild(nameDiv);
      authorDiv.appendChild(metaDiv);

      leftWrap.appendChild(avatarDiv);
      leftWrap.appendChild(authorDiv);

      const badge = document.createElement("div");
      badge.className = "mood-item-badge";
      badge.textContent = post.allow_replies ? "可回覆" : "不開放回覆";

      header.appendChild(leftWrap);
      header.appendChild(badge);

      const body = document.createElement("div");
      body.className = "mood-item-content";
      body.textContent = post.content || "";

      card.appendChild(header);
      card.appendChild(body);

      // image_url（若你未使用圖片，可忽略）
      if (post.image_url) {
        const img = document.createElement("img");
        img.src = post.image_url;
        img.alt = "post-image";
        img.className = "mood-item-image";
        img.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          // 若你已經有圖片全螢幕 viewer，可在此改成呼叫既有函式
          window.open(post.image_url, "_blank");
        });
        card.appendChild(img);
      }

      const actions = document.createElement("div");
      actions.className = "mood-item-actions";

      const replies = hmMoodRepliesCache.get(String(post.id)) || [];
      const replyCount = document.createElement("div");
      replyCount.className = "mood-item-reply-count";
      replyCount.textContent = (replies.length ? (replies.length + " 則回覆") : "尚無回覆");

      if (post.allow_replies) {
        const replyBtn = document.createElement("button");
        replyBtn.type = "button";
        replyBtn.className = "mood-item-reply-btn";
        replyBtn.textContent = "回覆";

        const toggleBtn = document.createElement("button");
        toggleBtn.type = "button";
        toggleBtn.className = "mood-item-reply-btn";
        toggleBtn.textContent = "查看";

        const repliesWrap = document.createElement("div");
        repliesWrap.className = "mood-replies";
        repliesWrap.style.display = "none";

        const list = document.createElement("div");
        list.className = "mood-replies-list";

        const form = document.createElement("div");
        form.className = "mood-reply-form";

        const anonLabel = document.createElement("label");
        anonLabel.className = "mood-reply-anon";
        anonLabel.innerHTML = '<input type="checkbox" id="anonReply_' + post.id + '"> 匿名回覆';

        const input = document.createElement("textarea");
        input.className = "mood-reply-input";
        input.placeholder = "輸入回覆…";

        const send = document.createElement("button");
        send.type = "button";
        send.className = "btn";
        send.style.padding = "8px 10px";
        send.textContent = "送出";

        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.className = "btn-outline";
        cancel.style.padding = "8px 10px";
        cancel.textContent = "收起";

        function renderRepliesList() {
          list.innerHTML = "";
          const arr = hmMoodRepliesCache.get(String(post.id)) || [];
          if (!arr.length) {
            list.innerHTML = '<div style="padding:8px;color:#6b7280;font-size:12px;">尚無回覆</div>';
            return;
          }
          arr.forEach(r => {
            const item = document.createElement("div");
            item.className = "mood-reply-item";

            const a = hmMoodGetAuthor(r.user_id);
            const rAnon = !!r.is_anonymous;
            const av = document.createElement("div");
            av.className = "mood-reply-avatar";
            if (rAnon) {
              av.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#9ca3af;">?</div>';
            } else {
              av.innerHTML = '<img src="' + ((a && a.avatar) ? a.avatar : "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E") + '" alt="avatar">';
              hmMoodBindProfileClick(av, r.user_id);
            }

            const main = document.createElement("div");
            main.className = "mood-reply-main";

            const top = document.createElement("div");
            top.className = "mood-reply-top";

            const nm = document.createElement("span");
            nm.className = "mood-reply-name";
            nm.textContent = rAnon ? "匿名用戶" : ((a && a.name) ? a.name : "未設定");
            if (!rAnon) hmMoodBindProfileClick(nm, r.user_id);

            const tm = document.createElement("span");
            tm.className = "mood-reply-time";
            const tt = new Date(r.createdAt || Date.now());
            tm.textContent = String(tt.getHours()).padStart(2, "0") + ":" + String(tt.getMinutes()).padStart(2, "0");

            top.appendChild(nm);
            top.appendChild(tm);

            const bd = document.createElement("div");
            bd.className = "mood-reply-body";
            bd.textContent = r.body || "";

            main.appendChild(top);
            main.appendChild(bd);

            item.appendChild(av);
            item.appendChild(main);
            list.appendChild(item);
          });
        }

        async function openReplies(focusInput) {
          repliesWrap.style.display = "block";
          renderRepliesList();
          if (focusInput) input.focus();
        }

        function closeReplies() {
          repliesWrap.style.display = "none";
        }

        replyBtn.addEventListener("click", async () => {
          await openReplies(true);
        });

        toggleBtn.addEventListener("click", async () => {
          if (repliesWrap.style.display === "none") await openReplies(false);
          else closeReplies();
        });

        cancel.addEventListener("click", () => closeReplies());

        send.addEventListener("click", async () => {
          const msg = String(input.value || "").trim();
          if (!msg) return;
          const anonCb = document.getElementById("anonReply_" + post.id);
          const isAnonReply = anonCb ? !!anonCb.checked : false;

          const r = await hmMoodInsertReply(post.id, msg, isAnonReply);
          if (!r || !r.ok) return;

          input.value = "";
          if (anonCb) anonCb.checked = false;

          // 重新抓取一次該貼文的回覆（保持一致）
          const { ok, cli } = await hmMoodGetClientAndUid();
          if (ok && cli) {
            // 只刷新這篇貼文的回覆
            const one = await cli
              .from("post_replies")
              .select("id,post_id,user_id,body,is_anonymous,created_at")
              .eq("post_id", String(post.id))
              .order("created_at", { ascending: true });
            if (one && one.data) {
              const arr = (one.data || []).map(hmMoodNormalizeReplyRow);
              hmMoodRepliesCache.set(String(post.id), arr);

              // hydrate new authors
              const ids = [];
              arr.forEach(x => { if (!x.is_anonymous && isUuid(x.user_id)) ids.push(x.user_id); });
              await hmMoodHydrateAuthors(cli, ids);
            }
          }

          const latest = hmMoodRepliesCache.get(String(post.id)) || [];
          replyCount.textContent = (latest.length ? (latest.length + " 則回覆") : "尚無回覆");
          renderRepliesList();
        });

        form.appendChild(anonLabel);
        form.appendChild(input);

        const btnRow = document.createElement("div");
        btnRow.className = "mood-reply-btnrow";
        btnRow.appendChild(send);
        btnRow.appendChild(cancel);

        form.appendChild(btnRow);

        repliesWrap.appendChild(list);
        repliesWrap.appendChild(form);

        actions.appendChild(replyBtn);
        actions.appendChild(toggleBtn);
        actions.appendChild(replyCount);

        card.appendChild(actions);
        card.appendChild(repliesWrap);
      } else {
        actions.appendChild(replyCount);
        card.appendChild(actions);
      }

      listEl.appendChild(card);
    });
  }

  function initMoodSquare() {
    hmUpdateMoodRoseUI();

    const postBtn = document.getElementById("btnPostMood");
    if (postBtn && !postBtn.dataset.bound) {
      postBtn.dataset.bound = "1";
      postBtn.addEventListener("click", async () => {
        await hmMoodInsertPost();
      });
    }


    const rulesBtn = document.getElementById("btnMoodRules");
    if (rulesBtn && !rulesBtn.dataset.bound) {
      rulesBtn.dataset.bound = "1";
      rulesBtn.addEventListener("click", () => {
        alert(
          "心情廣場規則\n\n" +
          "• 發文：每日最多 3 篇（每篇消耗 🌹 玫瑰 x1）\n" +
          "• 回覆：每日免費 3 則；第 4 則起每則消耗 🎁 小禮物 x1\n" +
          "• 取得方式：每日登入送 🎁 x1；每日簽到—單數日 🌹 x1、雙數日 🎁 x2\n"
        );
      });
    }
    // 初次進入先載入一次（若未登入，會顯示提示）
    hmRefreshMoodFromSupabase();
  }


// ================== 基本資料 + 綁定帳號 + 我的資料卡片 ==================
  function hmHasCompletedProfile() {
    try {
      return localStorage.getItem("hmProfileCompleted") === "true";
    } catch (e) {
      return false;
    }
  }

  function hmSaveProfileData(data) {
    try {
      localStorage.setItem("hmProfileData", JSON.stringify(data));
      localStorage.setItem("hmProfileCompleted", "true");
    } catch (e) {
      console.warn("無法儲存使用者資料到 localStorage：", e);
    }
  }

  // ==============================
  // Supabase sync (public.profiles)
  // ==============================
  // 目標：在「編輯基本資料」存檔時，同步寫入 Supabase 的 public.profiles。
  // 方式：upsert（以登入者 auth.uid() 對應同一筆 profiles.id）
  // 注意：不在程式硬寫 Key，改讀取 localStorage：SB_URL / SB_ANON_KEY（由測試面板寫入）

  var HM_SB_URL_KEY = "SB_URL";
  var HM_SB_ANON_KEY = "SB_ANON_KEY";
  var HM_SB_SDK_URL = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.3/dist/umd/supabase.js";

  // ====== A) 寫死 Supabase 專案連線資訊（必要時仍可用 localStorage 覆蓋） ======
  // 1) Project URL：已寫死為你目前專案
  // 2) anon public key：若你不想再用測試面板貼 key，請把下面字串換成你的 anon key。
  //    （Supabase Dashboard → Project Settings → API → anon public key）
  var HM_SB_DEFAULT_URL = "https://eqtvoxcavjgronfmalfw.supabase.co";
  // 部署前請填入你的 Supabase anon public key（正式版請改為安全設定流程）
  var HM_SB_DEFAULT_ANON_KEY = "";

  // 若瀏覽器尚未存過 SB_URL/SB_ANON_KEY，先用寫死的預設值補上（之後仍可被覆蓋）。
  try {
    if (!localStorage.getItem(HM_SB_URL_KEY) && HM_SB_DEFAULT_URL) {
      localStorage.setItem(HM_SB_URL_KEY, HM_SB_DEFAULT_URL);
    }
    if (!localStorage.getItem(HM_SB_ANON_KEY) && HM_SB_DEFAULT_ANON_KEY) {
      localStorage.setItem(HM_SB_ANON_KEY, HM_SB_DEFAULT_ANON_KEY);
    }
  } catch (e) { /* ignore */ }
  var hmSupabaseClient = null;
  var hmSupabaseSdkLoading = null;

  function hmSbLog(msg) {
    try {
      var el = document.getElementById("sb_log");
      if (!el) return;
      if (typeof msg === "string") el.textContent = msg;
      else el.textContent = JSON.stringify(msg, null, 2);
    } catch (e) { /* ignore */ }
  }

  function hmEnsureSupabaseSdk() {
    if (window.supabase && window.supabase.createClient) return Promise.resolve();
    if (hmSupabaseSdkLoading) return hmSupabaseSdkLoading;

    hmSupabaseSdkLoading = new Promise(function (resolve, reject) {
      var existing = document.getElementById("hm_supabase_sdk");
      if (existing) {
        // wait until ready
        var t0 = Date.now();
        var timer = setInterval(function () {
          if (window.supabase && window.supabase.createClient) {
            clearInterval(timer);
            resolve();
          }
          if (Date.now() - t0 > 15000) {
            clearInterval(timer);
            reject(new Error("Supabase SDK 載入逾時"));
          }
        }, 200);
        return;
      }

      var s = document.createElement("script");
      s.id = "hm_supabase_sdk";
      s.src = HM_SB_SDK_URL;
      s.async = true;
      s.onload = function () {
        if (window.supabase && window.supabase.createClient) resolve();
        else reject(new Error("Supabase SDK 載入後仍未找到 createClient"));
      };
      s.onerror = function () { reject(new Error("Supabase SDK 載入失敗")); };
      document.head.appendChild(s);
    });

    return hmSupabaseSdkLoading;
  }

  function hmGetSupabaseClient() {
    var url = "";
    var key = "";
    try {
      url = (localStorage.getItem(HM_SB_URL_KEY) || HM_SB_DEFAULT_URL || "").trim();
      key = (localStorage.getItem(HM_SB_ANON_KEY) || HM_SB_DEFAULT_ANON_KEY || "").trim();
    } catch (e) { /* ignore */ }

    if (!url || !key) return Promise.resolve(null);
    if (hmSupabaseClient) return Promise.resolve(hmSupabaseClient);

    return hmEnsureSupabaseSdk().then(function () {
      hmSupabaseClient = window.supabase.createClient(url, key, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
      });
      return hmSupabaseClient;
    });
  }

  // ================== Supabase: profile_photos + diaries (minimal, stable) ==================
  var hmProfilePhotosOwnerCol = null;
  var hmProfilePhotosUrlCol = null;
  var hmProfilePhotosIsAvatarCol = null;

  async function hmDetectProfilePhotosCols(cli){
    if (hmProfilePhotosUrlCol && hmProfilePhotosIsAvatarCol) {
      return { urlCol: hmProfilePhotosUrlCol, isAvatarCol: hmProfilePhotosIsAvatarCol };
    }
    hmProfilePhotosUrlCol = "url";
    hmProfilePhotosIsAvatarCol = "is_avatar";
    try {
      const t = await cli.from("profile_photos").select("url").limit(1);
      if (t && t.error) throw t.error;
    } catch(e) {
      try {
        const t2 = await cli.from("profile_photos").select("photo_url").limit(1);
        if (t2 && !t2.error) hmProfilePhotosUrlCol = "photo_url";
      } catch(_e) {}
    }
    try {
      const a = await cli.from("profile_photos").select("is_avatar").limit(1);
      if (a && a.error) throw a.error;
    } catch(e) {
      try {
        const a2 = await cli.from("profile_photos").select("isAvatar").limit(1);
        if (a2 && !a2.error) hmProfilePhotosIsAvatarCol = "isAvatar";
      } catch(_e) {}
    }
    return { urlCol: hmProfilePhotosUrlCol, isAvatarCol: hmProfilePhotosIsAvatarCol };
  }


  async function hmDetectProfilePhotosOwnerCol(cli) {
    if (hmProfilePhotosOwnerCol) return hmProfilePhotosOwnerCol;
    try {
      const t = await cli.from("profile_photos").select("user_id").limit(1);
      if (!t.error) { hmProfilePhotosOwnerCol = "user_id"; return hmProfilePhotosOwnerCol; }
    } catch (e) {}
    try {
      const t2 = await cli.from("profile_photos").select("profile_id").limit(1);
      if (!t2.error) { hmProfilePhotosOwnerCol = "profile_id"; return hmProfilePhotosOwnerCol; }
    } catch (e) {}
    hmProfilePhotosOwnerCol = "user_id";
    return hmProfilePhotosOwnerCol;
  }

  async function hmAttachPhotosToPeople(cli, peopleList) {
    if (!cli || !Array.isArray(peopleList) || peopleList.length === 0) return;
    const ownerCol = await hmDetectProfilePhotosOwnerCol(cli);
    const cols = await hmDetectProfilePhotosCols(cli);
    const urlCol = (cols && cols.urlCol) ? cols.urlCol : "url";
    const isAvatarCol = (cols && cols.isAvatarCol) ? cols.isAvatarCol : "is_avatar";
    const ids = peopleList.map(p => String(p.id));
    const chunkSize = 50;
    const allRows = [];
    for (let i = 0; i < ids.length; i += chunkSize) {
      const chunk = ids.slice(i, i + chunkSize);
      const res = await cli
        .from("profile_photos")
        .select(ownerCol + "," + urlCol + "," + isAvatarCol + ",created_at")
        .in(ownerCol, chunk)
        .order("created_at", { ascending: false });
      if (res && res.data) allRows.push(...res.data);
    }

    const byUser = new Map();
    allRows.forEach(r => {
      const uid = String(r[ownerCol] || "");
      if (!uid) return;
      if (!byUser.has(uid)) byUser.set(uid, []);
      byUser.get(uid).push(r);
    });

    peopleList.forEach(p => {
      const rows = byUser.get(String(p.id)) || [];
      const avatarRow = rows.find(x => x[isAvatarCol] === true) || null;
      if (avatarRow && avatarRow[urlCol]) p.avatar = String(avatarRow[urlCol]);

      const album = rows.filter(x => !x[isAvatarCol] && x[urlCol]).map(x => String(x[urlCol]));
      if (album.length) p.album = album.slice(0, 6);
    });
  }

  async function hmInsertProfilePhotoToSupabase(dataUrl, isAvatar) {
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) return { ok: false, skipped: true, reason: "no_sb_url_key" };
      const sessRes = await cli.auth.getSession();
      const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
      if (!session || !session.user) return { ok: false, skipped: true, reason: "not_signed_in" };

      const ownerCol = await hmDetectProfilePhotosOwnerCol(cli);
    const cols = await hmDetectProfilePhotosCols(cli);
    const urlCol = (cols && cols.urlCol) ? cols.urlCol : "url";
    const isAvatarCol = (cols && cols.isAvatarCol) ? cols.isAvatarCol : "is_avatar";
      const payload = {};
      payload[ownerCol] = session.user.id;
      payload[urlCol] = dataUrl;
      payload[isAvatarCol] = !!isAvatar;

      const res = await cli.from("profile_photos").insert(payload);
      if (res && res.error) throw res.error;
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e };
    }
  }

  async function hmInsertDiaryToSupabase(content, isPublic, imageUrl) {
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) return { ok: false, skipped: true, reason: "no_sb_url_key" };
      const sessRes = await cli.auth.getSession();
      const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
      if (!session || !session.user) return { ok: false, skipped: true, reason: "not_signed_in" };

      // NOTE: imageUrl 目前使用 dataURL（base64）同步到資料庫（Demo 可用）。
      // 若你想改成 Supabase Storage，後續可把這裡的 imageUrl 換成 public URL。
      const payload = {
        user_id: session.user.id,
        content: String(content || ""),
        is_public: !!isPublic
      };
      if (imageUrl) payload.image_url = String(imageUrl);

      // 先嘗試帶 image_url 插入；若資料庫尚未加欄位，會自動降級插入文字並回傳提示
      let res = await cli.from("diaries").insert(payload).select("id,created_at,image_url,is_public");
      if (res && res.error) {
        const msg = String(res.error.message || "");
        const missingCol = msg.includes("image_url") && (msg.includes("does not exist") || msg.includes("column"));
        if (missingCol) {
          // retry without image_url
          const payload2 = { user_id: payload.user_id, content: payload.content, is_public: payload.is_public };
          res = await cli.from("diaries").insert(payload2).select("id,created_at,is_public");
          if (res && res.error) throw res.error;
          var row2 = Array.isArray(res.data) && res.data.length ? res.data[0] : res.data;
          return {
            ok: true,
            id: row2 && row2.id ? String(row2.id) : null,
            created_at: row2 && row2.created_at ? row2.created_at : null,
            image_url: null,
            is_public: !!payload.is_public,
            warning: "missing_image_url_column"
          };
        }
        throw res.error;
      }

      var row = Array.isArray(res.data) && res.data.length ? res.data[0] : res.data;
      return {
        ok: true,
        id: row && row.id ? String(row.id) : null,
        created_at: row && row.created_at ? row.created_at : null,
        image_url: row && row.image_url ? String(row.image_url) : (imageUrl ? String(imageUrl) : null),
        is_public: row && row.is_public != null ? !!row.is_public : !!payload.is_public
      };
    } catch (e) {
      return { ok: false, error: e };
    }
  }

  async function hmLoadPublicDiariesIntoDetail(profileId) {
    const listEl = document.getElementById("publicDiaryList");
    if (!listEl) return;
    listEl.innerHTML = '<div class="diary-item" style="color:#6b7280;">載入中...</div>';
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) { listEl.innerHTML = '<div class="diary-item" style="color:#6b7280;">尚未設定 Supabase 連線。</div>'; return; }
      const sessRes = await cli.auth.getSession();
      const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
      if (!session || !session.user) { listEl.innerHTML = '<div class="diary-item" style="color:#6b7280;">請先登入後再查看公開日記。</div>'; return; }

      const res = await cli
        .from("diaries")
        .select("content,created_at,image_url")
        .eq("user_id", profileId)
        .eq("is_public", true)
        .order("created_at", { ascending: false })
        .limit(10);

      if (res && res.error) throw res.error;
      const rows = res.data || [];
      if (!rows.length) {
        listEl.innerHTML = '<div class="diary-item" style="color:#6b7280;">對方尚未公開任何日記。</div>';
        return;
      }
      listEl.innerHTML = "";
      rows.forEach(r => {
        const item = document.createElement("div");
        item.className = "diary-item";
        const t = document.createElement("div");
        t.style.fontSize = "15px";
        t.style.whiteSpace = "pre-wrap";
        t.textContent = r.content || "";
        const meta = document.createElement("div");
        meta.style.marginTop = "6px";
        meta.style.fontSize = "12px";
        meta.style.color = "#9ca3af";
        meta.textContent = r.created_at ? new Date(r.created_at).toLocaleString() : "";
        item.appendChild(t);
        if (r && r.image_url) {
          const img = document.createElement("img");
          img.src = r.image_url;
          img.alt = "日記照片";
          img.style.width = "100%";
          img.style.maxWidth = "100%";
          img.style.borderRadius = "12px";
          img.style.marginTop = "10px";
          img.style.display = "block";
          item.appendChild(img);
        }
        item.appendChild(meta);
        listEl.appendChild(item);
      });
    } catch (e) {
      listEl.innerHTML = '<div class="diary-item" style="color:#6b7280;">載入失敗（可能尚未建立 diaries 表或 RLS 未設定）。</div>';
    }
  }

  async function hmSyncProfileToSupabase(profile) {
    try {
      var cli = await hmGetSupabaseClient();
      if (!cli) {
        // 沒設定 URL/Key 就不做同步（避免影響 demo 使用）
        return { ok: false, skipped: true, reason: "no_sb_url_key" };
      }

      // 取得 session（避免 missing sub claim / 403：沒有 session 就不要呼叫 getSession）
      var sessRes = await cli.auth.getSession();
      if (sessRes && sessRes.error) throw sessRes.error;
      var session = (sessRes && sessRes.data) ? sessRes.data.session : null;
      if (!session || !session.user) {
        return { ok: false, skipped: true, reason: "not_signed_in" };
      }

      var uid = session.user.id;
      // 轉型（避免 int 欄位塞到字串）
      var heightVal = profile.height === "" || profile.height == null ? null : Number(profile.height);
      var weightVal = profile.weight === "" || profile.weight == null ? null : Number(profile.weight);
      if (Number.isNaN(heightVal)) heightVal = null;
      if (Number.isNaN(weightVal)) weightVal = null;
       
var nameVal = (profile && profile.name != null) ? String(profile.name).trim() : "";
if (!nameVal) nameVal = null;
       
      var payload = {
        id: uid,
        name: nameVal,                 
        gender: (profile && profile.gender) ? String(profile.gender) : null,
        age_range: (profile && profile.age_range) ? String(profile.age_range) : null,
        region: profile.region || null,
        height: heightVal,
        weight: weightVal,
        avatar_url: (profile && profile.avatar_url) ? profile.avatar_url : (function(){ try { return localStorage.getItem("hmAvatarImage") || null; } catch(e){ return null; } })()
      };

      // upsert：同一個 uid 永遠寫回同一筆 profiles.id
      var upsertRes = await cli
        .from("profiles")
        .upsert(payload, { onConflict: "id" })
        .select("id,name,gender,age_range,region,height,weight,avatar_url,age,last_seen_at,created_at")
        .single();

      if (upsertRes && upsertRes.error) throw upsertRes.error;

      // 方便除錯：把結果寫到測試面板 log
      hmSbLog({ ok: true, profiles_upsert: upsertRes.data });
      return { ok: true, data: upsertRes.data };
    } catch (e) {
      console.warn("同步 profiles 到 Supabase 失敗：", e);
      hmSbLog({ ok: false, error: (e && e.message) ? e.message : String(e) });
      return { ok: false, error: e };
    }
  }

  
  // ================== Supabase profiles：讀取（頁面載入自動回填） ==================
  async function hmFetchProfileFromSupabase() {
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) return { ok: false, skipped: true, reason: "no_sb_url_key" };

      const sessRes = await cli.auth.getSession();
      if (sessRes.error) throw sessRes.error;

      const session = sessRes.data && sessRes.data.session;
      if (!session || !session.user) return { ok: false, skipped: true, reason: "no_session" };

      const uid = session.user.id;

      const res = await cli
        .from("profiles")
        .select("id,name,region,height,weight,avatar_url,created_at,updated_at")
        .eq("id", uid)
        .maybeSingle();

      if (res.error) throw res.error;

      if (!res.data) {
        hmSbLog({ ok: true, profiles_read: null, note: "no_row" });
        return { ok: true, data: null };
      }

      hmSbLog({ ok: true, profiles_read: res.data });
      return { ok: true, data: res.data };
    } catch (e) {
      console.warn("讀取 Supabase profiles 失敗：", e);
      hmSbLog({ ok: false, error: (e && e.message) ? e.message : String(e) });
      return { ok: false, error: e };
    }
  }

  async function hmHydrateProfileFromSupabase() {
    const got = await hmFetchProfileFromSupabase();
    if (!got || !got.ok || !got.data) return got;

    // Merge into local profile (keep socials/other local-only fields)
    let localProfile = {};
    try {
      const raw = localStorage.getItem("hmProfileData");
      if (raw) localProfile = JSON.parse(raw) || {};
    } catch (e) { /* ignore */ }

    const merged = Object.assign({}, localProfile);

    // Supabase as source of truth for these fields
    if (got.data.name != null) merged.name = got.data.name;
    if (got.data.region != null) merged.region = got.data.region;
    if (got.data.height != null) merged.height = got.data.height;
    if (got.data.weight != null) merged.weight = got.data.weight;
    if (got.data.avatar_url != null) merged.avatar_url = got.data.avatar_url;

    hmSaveProfileData(merged);

    // Refresh UI
    try { hmInitProfileCard(); } catch (e) { /* ignore */ }
    try { hmInitMyProfileHeader(); } catch (e) { /* ignore */ }

    // 同步頭貼/相簿（來自 profile_photos）
    try { await hmHydrateMyPhotosFromSupabase(); } catch (e) { /* ignore */ }

    // If the edit modal/form is present, also refill it
    try {
      if (document.getElementById("hm-name")) {
        hmFillProfileForm({ lockBasic: hmHasCompletedProfile() });
      }
    } catch (e) { /* ignore */ }

    return { ok: true, data: merged };
  }

  async function hmHydrateMyPhotosFromSupabase() {
    try {
      const cli = await hmGetSupabaseClient();
      if (!cli) return { ok: false, skipped: true, reason: "no_sb_url_key" };

      const sessRes = await cli.auth.getSession();
      const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
      if (!session || !session.user) return { ok: false, skipped: true, reason: "no_session" };

      const uid = session.user.id;

      // 透過 profile_photos 拉回最新頭貼/相簿，讓「我的資料」與「對外資料」保持一致（可跨裝置）。
      const arr = [{ id: uid }];
      try {
        await hmAttachPhotosToPeople(cli, arr);
      } catch (e) {
        console.warn("載入 profile_photos 失敗：", e);
        return { ok: false, error: e };
      }
      const me = arr[0] || {};
      const avatar = me.avatar || null;
      const album = Array.isArray(me.album) ? me.album : [];

      if (avatar) {
        try { localStorage.setItem("hmAvatarImage", avatar); } catch(_e) {}
        try {
          const imgEl = document.getElementById("myAvatarImage");
          if (imgEl) imgEl.src = avatar;
        } catch(_e) {}
        try {
          const raw = localStorage.getItem("hmProfileData");
          const prof = raw ? JSON.parse(raw) : {};
          prof.avatar_url = avatar;
          hmSaveProfileData(prof);
        } catch(_e) {}
        try { hmApplyAvatarToProfileCard(); } catch(_e) {}
      }

      // 相簿固定 6 格：依最新資料回填（多的取前 6、少的補 null）
      const fixed = new Array(MY_ALBUM_SLOTS).fill(null);
      for (let i = 0; i < Math.min(album.length, MY_ALBUM_SLOTS); i++) fixed[i] = album[i];

      myAlbumPhotosCache = fixed;
      try { localStorage.setItem("hmMyAlbumPhotos", JSON.stringify(fixed)); } catch(_e) {}

      try { renderMyAlbum(); } catch(_e) {}

      return { ok: true, avatar_url: avatar, album: fixed };
    } catch (e) {
      console.warn("hmHydrateMyPhotosFromSupabase 失敗：", e);
      return { ok: false, error: e };
    }
  }
// 保持相容：某些舊版程式碼呼叫 hmUpsertProfileToSupabase
  // 這裡直接 alias 到 hmSyncProfileToSupabase，避免 ReferenceError
  window.hmUpsertProfileToSupabase = hmSyncProfileToSupabase;

  function hmSetAuthProvider(provider) {
    try {
      localStorage.setItem("hmAuthProvider", provider);
    } catch (e) {
      console.warn("無法儲存綁定系統：", e);
    }
  }

  function hmGetAuthProvider() {
    try {
      return localStorage.getItem("hmAuthProvider") || "";
    } catch (e) {
      return "";
    }
  }

  function hmBuildSocialUrl(platform, value) {
    if (!value) return null;
    const v = value.trim();
    if (!v) return null;
    if (v.startsWith("http://") || v.startsWith("https://")) {
      return v;
    }
    switch (platform) {
      case "threads":
        return "https://www.threads.net/@" + v.replace(/^@/, "");
      case "x":
        return "https://x.com/" + v.replace(/^@/, "");
      case "instagram":
        return "https://www.instagram.com/" + v.replace(/^@/, "");
      case "facebook":
        return "https://www.facebook.com/" + v;
      case "other":
      default:
        return null;
    }
  }

  
  
  
  // ================== Region (縣市選單 + 其他) ==================
  const HM_TW_CITIES = [
    "臺北市","新北市","基隆市","桃園市","新竹市","新竹縣","宜蘭縣",
    "苗栗縣","臺中市","彰化縣","南投縣","雲林縣",
    "嘉義市","嘉義縣","臺南市","高雄市","屏東縣",
    "花蓮縣","臺東縣","澎湖縣","金門縣","連江縣"
  ];

  function hmWireRegionOtherToggle() {
    const sel = document.getElementById("hm-region");
    const other = document.getElementById("hm-region-other");
    if (!sel || !other) return;

    function apply() {
      const v = (sel.value || "").trim();
      if (v === "__other__") {
        other.style.display = "block";
      } else {
        other.style.display = "none";
        other.value = "";
      }
    }

    sel.addEventListener("change", apply);
    apply();
  }

  function hmGetRegionFromForm() {
    const sel = document.getElementById("hm-region");
    const other = document.getElementById("hm-region-other");
    if (!sel) return "";
    const v = (sel.value || "").trim();
    if (v === "__other__") {
      return (other && other.value ? other.value.trim() : "");
    }
    return v;
  }

  function hmSetRegionToForm(regionText) {
    const sel = document.getElementById("hm-region");
    const other = document.getElementById("hm-region-other");
    if (!sel) return;

    const r = (regionText || "").trim();

    // If no region -> reset
    if (!r) {
      sel.value = "";
      if (other) { other.value = ""; other.style.display = "none"; }
      return;
    }

    // If matches known city list -> select it
    if (HM_TW_CITIES.indexOf(r) >= 0) {
      sel.value = r;
      if (other) { other.value = ""; other.style.display = "none"; }
      return;
    }

    // Otherwise -> "other"
    sel.value = "__other__";
    if (other) {
      other.value = r;
      other.style.display = "block";
    }
  }
function hmFillProfileForm(options) {
    const opts = options || {};
    const nameInput = document.getElementById("hm-name");
    const heightInput = document.getElementById("hm-height");
    const weightInput = document.getElementById("hm-weight");
    const genderInput = document.getElementById("hm-gender");
    const ageRangeInput = document.getElementById("hm-age-range");
    const regionInput = document.getElementById("hm-region");
    const threadsInput = document.getElementById("hm-threads");
    const xInput = document.getElementById("hm-x");
    const igInput = document.getElementById("hm-instagram");
    const fbInput = document.getElementById("hm-facebook");
    const otherInput = document.getElementById("hm-other");
    const agreeInput = document.getElementById("hm-agree");

    if (!nameInput) return;

    let profile = null;
    const dataStr = localStorage.getItem("hmProfileData");
    if (dataStr) {
      try {
        profile = JSON.parse(dataStr);
      } catch (e) {
        console.warn("解析 hmProfileData 失敗（fill form）：", e);
      }
    }
    profile = profile || {};

    const socials = profile.socials || {};

    // 基本欄位
    nameInput.value = profile.name || "";
    heightInput.value = profile.height || "";
    weightInput.value = profile.weight || "";
    if (genderInput) genderInput.value = profile.gender || "";
    if (ageRangeInput) ageRangeInput.value = profile.age_range || "";
        hmSetRegionToForm(profile.region || "");
// 社群欄位
    threadsInput.value = socials.threads || "";
    xInput.value = socials.x || "";
    igInput.value = socials.instagram || "";
    fbInput.value = socials.facebook || "";
    otherInput.value = socials.other || "";

    const lockBasic = !!opts.lockBasic;

    // 控制是否可編輯
    nameInput.readOnly = lockBasic;
    heightInput.readOnly = lockBasic;
    weightInput.readOnly = lockBasic;
    if (genderInput) { if (genderInput.tagName === "SELECT") genderInput.disabled = lockBasic; else genderInput.readOnly = lockBasic; }
    if (ageRangeInput) { if (ageRangeInput.tagName === "SELECT") ageRangeInput.disabled = lockBasic; else ageRangeInput.readOnly = lockBasic; }
        if (regionInput) {
      if (regionInput.tagName === "SELECT") regionInput.disabled = lockBasic;
      else regionInput.readOnly = lockBasic;
    }
if (agreeInput) {
      if (lockBasic) {
        // 已完成基本資料後再次開啟，只編輯社群帳號，條款視為已同意
        agreeInput.checked = true;
        agreeInput.disabled = true;
      } else {
        agreeInput.disabled = false;
        agreeInput.checked = false;
      }
    }
  }


  function hmInitAvatar() {
    try {
      const imgEl = document.getElementById("myAvatarImage");
      if (!imgEl) return;
      const dataUrl = localStorage.getItem("hmAvatarImage");
      if (dataUrl) {
        imgEl.src = dataUrl;
        try {
          hmApplyAvatarToProfileCard();
        } catch (e2) {
          console.warn("同步對外頭貼失敗：", e2);
        }
      }
    } catch (e) {
      console.warn("初始化頭貼失敗：", e);
    }
  }

function hmHandleAvatarFile(inputEl) {
  try {
    const imgEl = document.getElementById("myAvatarImage");
    if (!inputEl || !imgEl) return;
    const file = inputEl.files && inputEl.files[0];
    if (!file) return;

    // 先用 Object URL 讓各種瀏覽器（含 iOS / Android）立即預覽
    try {
      const objectUrl = URL.createObjectURL(file);
      imgEl.src = objectUrl;
      try {
        hmApplyAvatarToProfileCard();
      } catch (e3) {
        console.warn("同步對外頭貼失敗 (object URL)：", e3);
      }
    } catch (eObj) {
      console.warn("建立 Object URL 失敗：", eObj);
    }

    // 再用 FileReader 讀成 base64，存進 localStorage，供下次載入使用
    const reader = new FileReader();
    reader.onload = function (ev) {
      const result = ev.target && ev.target.result;
      if (!result) return;
      try {
        localStorage.setItem("hmAvatarImage", result);
      // Update profileData.avatar_url + sync to Supabase (best-effort)
      try {
        const raw = localStorage.getItem("hmProfileData");
        const prof = raw ? JSON.parse(raw) : {};
        prof.avatar_url = result;
        hmSaveProfileData(prof);
        if (window.hmUpsertProfileToSupabase) { window.hmUpsertProfileToSupabase(prof); }
      } catch(e) { /* ignore */ }
      // Insert avatar into profile_photos (best-effort)
      try { hmInsertProfilePhotoToSupabase(result, true); } catch(e) { /* ignore */ }

      } catch (err) {
        console.warn("儲存頭貼失敗：", err);
      }
      try {
        hmApplyAvatarToProfileCard();
      } catch (e2) {
        console.warn("同步對外頭貼失敗 (base64)：", e2);
      }
    };
    reader.readAsDataURL(file);
  } catch (e) {
    console.warn("處理頭貼上傳失敗：", e);
  }
}

function hmBindAvatarUploader() {
  const imgEl = document.getElementById("myAvatarImage");
  const input = document.getElementById("myAvatarFileInput");
  const btn = document.getElementById("myAvatarChangeBtn");
  if (!imgEl || !input) return;

  // 按鈕：更換頭貼
  if (btn) {
    btn.onclick = function () {
      input.click();
    };
  }

  // 點擊頭像也能開啟上傳（iOS / Android / Desktop 通用）
  imgEl.onclick = function () {
    input.click();
  };

  // 統一走 hmHandleAvatarFile，確保各環境一致
  input.onchange = function () {
    try {
      hmHandleAvatarFile(input);
    } catch (e) {
      console.warn("頭貼變更處理失敗：", e);
    }
  };
}

function hmApplyAvatarToProfileCard() {
    const avatarWrapper = document.querySelector(".hm-profile-avatar");
    const avatarTextEl = document.getElementById("hm-profile-avatar-text");
    if (!avatarWrapper || !avatarTextEl) return;
    const dataUrl = localStorage.getItem("hmAvatarImage");
    if (dataUrl) {
      avatarWrapper.style.backgroundImage = "url('" + dataUrl + "')";
      avatarWrapper.style.backgroundSize = "cover";
      avatarWrapper.style.backgroundPosition = "center";
      avatarWrapper.style.color = "transparent";
    } else {
      avatarWrapper.style.backgroundImage = "";
      avatarWrapper.style.backgroundSize = "";
      avatarWrapper.style.backgroundPosition = "";
      avatarWrapper.style.color = "#fff";
    }
  }

function hmInitProfileCard() {
    const dataStr = localStorage.getItem("hmProfileData");
    const nameEl = document.getElementById("hm-profile-name");
    const metaEl = document.getElementById("hm-profile-meta");
    const regionEl = document.getElementById("hm-profile-region");
    const avatarTextEl = document.getElementById("hm-profile-avatar-text");
    const socialListEl = document.getElementById("hm-profile-social-list");
    const bindEl = document.getElementById("hm-profile-bind");

    if (!nameEl || !metaEl || !regionEl || !avatarTextEl || !socialListEl) return;

    let profile = null;
    if (dataStr) {
      try {
        profile = JSON.parse(dataStr);
      } catch (e) {
        console.warn("解析 hmProfileData 失敗：", e);
      }
    }
    const name = profile && profile.name ? profile.name : "未設定姓名";
    const height = profile && profile.height ? profile.height : "";
    const weight = profile && profile.weight ? profile.weight : "";
    const region = profile && profile.region ? profile.region : "未填寫";

    nameEl.textContent = name;
    regionEl.textContent = "居住區域：" + region;

    if (height || weight) {
      const hText = height ? height + "cm" : "身高未填寫";
      const wText = weight ? weight + "kg" : "體重未填寫";
      metaEl.textContent = hText + " ／ " + wText;
    } else {
      metaEl.textContent = "身高 / 體重 未填寫";
    }

    let avatarText = "Me";
    if (name && typeof name === "string") {
      const trimmed = name.trim();
      if (trimmed.length === 1) avatarText = trimmed;
      else if (trimmed.length >= 2) avatarText = trimmed.slice(0, 2);
    }
    avatarTextEl.textContent = avatarText;

    const provider = hmGetAuthProvider();
    if (bindEl) {
      if (!provider) {
        bindEl.textContent = "尚未綁定帳號";
      } else if (provider === "google") {
        bindEl.textContent = "已綁定：Google 帳號（示意）";
      } else if (provider === "facebook") {
        bindEl.textContent = "已綁定：Facebook 帳號（示意）";
      } else if (provider === "apple") {
        bindEl.textContent = "已綁定：Apple 帳號（示意）";
      } else {
        bindEl.textContent = "已綁定：其他系統帳號（示意）";
      }
    }

    const socials = (profile && profile.socials) || {};
    const items = [];
    const config = [
      { key: "threads", label: "Threads", short: "Th", className: "hm-social-threads" },
      { key: "x", label: "X", short: "X", className: "hm-social-x" },
      { key: "instagram", label: "IG", short: "IG", className: "hm-social-instagram" },
      { key: "facebook", label: "FB", short: "FB", className: "hm-social-facebook" },
      { key: "other", label: "其他", short: "?", className: "hm-social-other" }
    ];

    socialListEl.innerHTML = "";
    config.forEach((c) => {
      const rawValue = socials[c.key];
      if (!rawValue || !rawValue.trim) return;
      if (!rawValue.trim()) return;
      const url = hmBuildSocialUrl(c.key, rawValue);
      items.push({
        key: c.key,
        label: c.label,
        short: c.short,
        className: c.className,
        raw: rawValue.trim(),
        url
      });
    });

    if (items.length === 0) {
      const span = document.createElement("span");
      span.className = "hm-profile-social-empty";
      span.textContent = "目前尚未串聯任何社群帳號";
      socialListEl.appendChild(span);
    } else {
      items.forEach((item) => {
        let el;
        if (item.url) {
          el = document.createElement("a");
          el.href = item.url;
          el.target = "_blank";
          el.rel = "noopener noreferrer";
        } else {
          el = document.createElement("div");
        }

        el.className = "hm-social-chip " + item.className;

        const icon = document.createElement("span");
        icon.className = "hm-social-icon";
        icon.textContent = item.short;

        const text = document.createElement("span");
        const displayRaw = item.raw.length > 14 ? item.raw.slice(0, 13) + "..." : item.raw;
        text.textContent = item.label + "｜" + displayRaw;

        el.appendChild(icon);
        el.appendChild(text);
        socialListEl.appendChild(el);
      });
    }
  }

  
  function hmInitMyProfileHeader() {
    try {
      const dataStr = localStorage.getItem("hmProfileData");
      const nameSpan = document.getElementById("myProfileName");
      const subEl = document.getElementById("myProfileSub");
      const statusTextEl = document.getElementById("myStatusText");

      if (!nameSpan || !subEl) return;

      let profile = null;
      if (dataStr) {
        try {
          profile = JSON.parse(dataStr);
        } catch (e) {
          console.warn("解析 hmProfileData 失敗（header）：", e);
        }
      }

      const name = profile && profile.name ? profile.name : "未設定姓名";
      const height = profile && profile.height ? profile.height : "";
      const weight = profile && profile.weight ? profile.weight : "";
      const region = profile && profile.region ? profile.region : "";

      nameSpan.textContent = name;

      let subText = "台灣";
      if (region) {
        subText += " · " + region;
      }

      if (height || weight) {
        let hw = "";
        if (height) hw += height + "cm";
        if (height && weight) hw += " / ";
        if (weight) hw += weight + "kg";
        if (hw) subText += " · " + hw;
      }

      if (statusTextEl && statusTextEl.textContent) {
        subText += " · " + statusTextEl.textContent;
      }

      subEl.textContent = subText;
    } catch (e) {
      console.warn("初始化我的資料頁頭時發生錯誤：", e);
    }
  }

// ================== VIP & 我的 6 張照片（本機示意） ==================
  const MY_ALBUM_SLOTS = 6;
  let myAlbumPhotosCache = null;

  // ================== Monetization scaffold (Ads + VIP Entitlements) ==================
  // 後端權威來源：rpc('get_monetization_state') / rpc('grant_album_unlock')
  // - 目前仍保留 localStorage 作為快取與 Demo fallback
  const HM_MONETIZATION_LOCAL_KEY = "hmMonetizationStateCache";
  let hmMonetizationCache = {
    env: "prod",
    platform: "web",
    config: {},
    entitlements: null,  // { vip_tier, vip_until, vip_active, is_album_ad_free, daily_roses_quota, ... }
    unlocks: {}          // { album_unlock_until }
  };

  function hmMonetizationLoadLocal() {
    try {
      const raw = localStorage.getItem(HM_MONETIZATION_LOCAL_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object") {
        hmMonetizationCache = Object.assign({}, hmMonetizationCache, parsed);
      }
    } catch (e) {}
  }

  function hmMonetizationSaveLocal() {
    try {
      localStorage.setItem(HM_MONETIZATION_LOCAL_KEY, JSON.stringify(hmMonetizationCache || {}));
    } catch (e) {}
  }

  function hmParseTimeToMs(v) {
    if (!v) return 0;
    try {
      if (typeof v === "number") return v;
      if (typeof v === "string") {
        const s = v.trim();
        if (!s) return 0;
        if (/^\d+$/.test(s)) return parseInt(s, 10);
        const t = Date.parse(s);
        return isNaN(t) ? 0 : t;
      }
      const t = Date.parse(String(v));
      return isNaN(t) ? 0 : t;
    } catch (e) {
      return 0;
    }
  }

  function hmGetVipUntilMsFromEntitlements() {
    try {
      const ent = hmMonetizationCache && hmMonetizationCache.entitlements ? hmMonetizationCache.entitlements : null;
      if (!ent) return 0;
      const ms = hmParseTimeToMs(ent.vip_until);
      return ms > 0 ? ms : 0;
    } catch (e) {
      return 0;
    }
  }

  function hmIsVipEntitledActive() {
    const ms = hmGetVipUntilMsFromEntitlements();
    return ms > Date.now();
  }

  function hmGetAlbumUnlockUntilMsFromBackend() {
    try {
      const u = hmMonetizationCache && hmMonetizationCache.unlocks ? hmMonetizationCache.unlocks.album_unlock_until : null;
      const ms = hmParseTimeToMs(u);
      return ms > 0 ? ms : 0;
    } catch (e) {
      return 0;
    }
  }

  function hmGetAlbumUnlockMinutesConfig() {
    try {
      const cfg = hmMonetizationCache && hmMonetizationCache.config ? hmMonetizationCache.config : {};
      const v = cfg.album_unlock_minutes;
      const n = parseInt(v || "20", 10);
      if (!isNaN(n) && n > 0) return n;
    } catch (e) {}
    return 20;
  }


  function hmGetVipLevel() {
    try {
      const raw = localStorage.getItem("hmVipLevel");
      const n = parseInt(raw || "0", 10);
      if (isNaN(n) || n < 0) return 0;
      if (n > 5) return 5;
      return n;
    } catch (e) {
      return 0;
    }
  }

  function hmSetVipLevel(level) {
    const lvl = Math.min(Math.max(level, 0), 5);
    try {
      localStorage.setItem("hmVipLevel", String(lvl));
    } catch (e) {}
    hmUpdateVipUI();
    renderMyAlbum();
    renderMyDiaries();
    initMoodSquare();
    if (pages.profileDetail.classList.contains("active") && currentProfileId != null) {
      openProfileDetail(currentProfileId);
    }
  }

  function hmVip60GetPriceTwd() {
    try {
      const c = (typeof hmMonetizationCache === 'object' && hmMonetizationCache && hmMonetizationCache.config) ? hmMonetizationCache.config : null;
      const raw = c && typeof c.vip60_price_twd === 'string' ? c.vip60_price_twd : '';
      const n = parseInt(raw || '150', 10);
      return Number.isFinite(n) && n > 0 ? n : 150;
    } catch (e) {
      return 150;
    }
  }

  function hmVip60IsDevGrantEnabled() {
    try {
      const params = new URLSearchParams(location.search || '');
      if (params.get('devvip') === '1') return true;
      const c = (typeof hmMonetizationCache === 'object' && hmMonetizationCache && hmMonetizationCache.config) ? hmMonetizationCache.config : null;
      const raw = c && typeof c.dev_vip_grant_enabled === 'string' ? c.dev_vip_grant_enabled : '';
      return String(raw).toLowerCase() === 'true';
    } catch (e) {
      return false;
    }
  }

  async function hmBackendDevGrantVip60(days) {
    try {
      const ctx = await hmBackendGetClientAndUser();
      if (!ctx || !ctx.ok) return { ok: false, reason: (ctx && ctx.reason) ? ctx.reason : 'not_authenticated' };
      const d = parseInt(days || '30', 10);
      const payload = { p_days: (Number.isFinite(d) && d > 0) ? d : 30 };
      const { data, error } = await ctx.cli.rpc('dev_grant_vip60', payload);
      if (error) return { ok: false, reason: error.message || 'rpc_error' };
      return data || { ok: true };
    } catch (e) {
      return { ok: false, reason: String(e && e.message ? e.message : e) };
    }
  }

  async function hmBackendDevRevokeVip() {
    try {
      const ctx = await hmBackendGetClientAndUser();
      if (!ctx || !ctx.ok) return { ok: false, reason: (ctx && ctx.reason) ? ctx.reason : 'not_authenticated' };
      const { data, error } = await ctx.cli.rpc('dev_revoke_vip');
      if (error) return { ok: false, reason: error.message || 'rpc_error' };
      return data || { ok: true };
    } catch (e) {
      return { ok: false, reason: String(e && e.message ? e.message : e) };
    }
  }

  async function hmVip60HandleSubscribeClick() {
    const price = hmVip60GetPriceTwd();
    // Web Demo：無法真的付款，保留導流與未來 IAP 接口位置
    const devEnabled = hmVip60IsDevGrantEnabled();
    if (!devEnabled) {
      alert('VIP（每月 NT$' + price + '）將在上架 App 後透過 Apple/Google 內購訂閱啟用。\n\n目前為 Web Demo，已預留後端權益結構；你可以先用「測試開通」或由後台手動設定 vip_until 來驗證。');
      return;
    }

    const ok = confirm('是否以「測試模式」開通 VIP（30 天）？\n\n注意：此模式僅用於開發測試，正式上架會改為內購驗證。');
    if (!ok) return;

    const r = await hmBackendDevGrantVip60(30);
    if (!r || !r.ok) {
      alert('測試開通失敗：' + (r && r.reason ? r.reason : 'unknown'));
      return;
    }

    try { if (typeof hmMonetizationBootstrap === 'function') await hmMonetizationBootstrap(); } catch (e) {}
    try { if (typeof hmSyncInventoryCache === 'function') await hmSyncInventoryCache(); } catch (e) {}
    try { if (typeof hmRewardRenderUI === 'function') await hmRewardRenderUI({ force: true }); } catch (e) {}
    try { if (typeof hmRenderMoodList === 'function') hmRenderMoodList(); } catch (e) {}
    try { if (typeof hmUpdateVipUI === 'function') hmUpdateVipUI(); } catch (e) {}
  }

  async function hmVip60HandleDevRevoke() {
    const ok = confirm('要取消 VIP（測試用）嗎？');
    if (!ok) return;
    const r = await hmBackendDevRevokeVip();
    if (!r || !r.ok) {
      alert('取消失敗：' + (r && r.reason ? r.reason : 'unknown'));
      return;
    }
    try { if (typeof hmMonetizationBootstrap === 'function') await hmMonetizationBootstrap(); } catch (e) {}
    try { if (typeof hmSyncInventoryCache === 'function') await hmSyncInventoryCache(); } catch (e) {}
    try { if (typeof hmRewardRenderUI === 'function') await hmRewardRenderUI({ force: true }); } catch (e) {}
    try { if (typeof hmRenderMoodList === 'function') hmRenderMoodList(); } catch (e) {}
    try { if (typeof hmUpdateVipUI === 'function') hmUpdateVipUI(); } catch (e) {}
  }

  function hmUpdateVipUI() {
    const entitled = (typeof hmIsVipEntitledActive === 'function') ? hmIsVipEntitledActive() : false;
    const badge = document.getElementById("myVipBadge");
    const statusEl = document.getElementById("vip60StatusText");
    const noteEl = document.getElementById("vip60NoteText");

    const untilMs = (typeof hmGetVipUntilMsFromEntitlements === 'function') ? hmGetVipUntilMsFromEntitlements() : 0;
    const dt = untilMs ? new Date(untilMs) : null;

    if (badge) {
      if (entitled) {
        badge.style.display = 'inline-flex';
        badge.textContent = 'VIP';
      } else {
        badge.style.display = 'none';
        badge.textContent = '';
      }
    }

    if (statusEl) {
      if (entitled) {
        statusEl.textContent = dt ? ('VIP：啟用中（到期：' + dt.toLocaleString() + '）') : 'VIP：啟用中';
      } else {
        statusEl.textContent = 'VIP：未開通';
      }
    }

    // Dev buttons visibility
    const devEnabled = hmVip60IsDevGrantEnabled();
    const grantBtn = document.getElementById('vip60DevGrantBtn');
    const revokeBtn = document.getElementById('vip60DevRevokeBtn');
    const subBtn = document.getElementById('vip60SubscribeBtn');

    if (subBtn) {
      subBtn.textContent = entitled ? '管理 VIP' : '開通 VIP';
      // 管理入口仍先導向提示
    }

    if (grantBtn) grantBtn.style.display = devEnabled ? '' : 'none';
    if (revokeBtn) revokeBtn.style.display = devEnabled ? '' : 'none';

    if (noteEl) {
      const price = hmVip60GetPriceTwd();
      if (devEnabled) {
        noteEl.innerHTML = '已啟用 <code>devvip</code> 測試模式（可直接開通/取消 VIP）。正式上架會改為 Apple/Google 內購訂閱驗證。VIP（月費 NT$' + price + '）。';
      } else {
        noteEl.innerHTML = '目前先使用本機寫死版測試 VIP 流程：可直接開通 30 天 / 365 天，用來檢查相簿、足跡、日記上限等權限 UI。回家後再接 Google Play Billing。VIP（月費 NT$' + price + '）。';
      }
    }
  }

  function hmLoadAlbumPhotos() {
    if (myAlbumPhotosCache) return myAlbumPhotosCache;
    try {
      const raw = localStorage.getItem("hmMyAlbumPhotos");
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length === MY_ALBUM_SLOTS) {
          myAlbumPhotosCache = parsed;
          return parsed;
        }
      }
    } catch (e) {
      console.warn("讀取相簿照片失敗：", e);
    }
    myAlbumPhotosCache = new Array(MY_ALBUM_SLOTS).fill(null);
    return myAlbumPhotosCache;
  }

  function hmSaveAlbumPhotos() {
    try {
      localStorage.setItem("hmMyAlbumPhotos", JSON.stringify(myAlbumPhotosCache || []));
    } catch (e) {
      console.warn("儲存相簿照片失敗：", e);
    }
  }

  function hmAlbumGetUnlockUntil() {
    try {
      const raw = localStorage.getItem("hmAlbumUnlockUntil");
      const t = parseInt(raw || "0", 10);
      return isNaN(t) ? 0 : t;
    } catch (e) {
      return 0;
    }
  }

  function hmAlbumIsUnlocked() {
    // VIP（後端 entitlement）視為解鎖
    if (typeof hmIsVipEntitledActive === 'function' && hmIsVipEntitledActive()) return true;
    const localUntil = hmAlbumGetUnlockUntil();
    const backendUntil = (typeof hmGetAlbumUnlockUntilMsFromBackend === 'function') ? hmGetAlbumUnlockUntilMsFromBackend() : 0;
    const until = Math.max(localUntil, backendUntil);
    return until > Date.now();
  }

  function hmAlbumUnlockFor20Minutes() {
    const mins = (typeof hmGetAlbumUnlockMinutesConfig === 'function') ? hmGetAlbumUnlockMinutesConfig() : 20;
    const unlockUntil = Date.now() + mins * 60 * 1000;
    try {
      localStorage.setItem("hmAlbumUnlockUntil", String(unlockUntil));
    } catch (e) {
      console.warn("儲存相簿解鎖時間失敗：", e);
    }

    // Best-effort：若已登入且後端已部署 monetization SQL，就同步寫入 feature_unlocks
    try {
      if (typeof hmBackendGrantAlbumUnlock === "function") {
        hmBackendGrantAlbumUnlock(mins).catch(()=>{});
      }
    } catch (e) {}

    alert("Demo：假設你看完一段廣告，接下來 " + mins + " 分鐘內 6 張照片都會開放給陌生人與好友查看。\n（若已後端化，解鎖狀態也會同步到 Supabase）");
    renderMyAlbum();
    if (pages.profileDetail.classList.contains("active") && currentProfileId != null) {
      openProfileDetail(currentProfileId);
    }
  }

  // 相容舊版本命名（避免快取或舊事件仍呼叫 30 分鐘函式）  // 相容舊版本命名（避免快取或舊事件仍呼叫 30 分鐘函式）
  function hmAlbumUnlockFor30Minutes() {
    return hmAlbumUnlockFor20Minutes();
  }

  function hmAlbumUnlock() {
    hmAlbumUnlockFor20Minutes();
  }

  function hmGetAlbumPhotoSrc(idx) {
    const photos = hmLoadAlbumPhotos();
    const fallback = albumPhotos;
    const p = photos[idx];
    if (p) return p;
    if (fallback && fallback[idx]) return fallback[idx];
    return "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22400%22%20height%3D%22400%22%20viewBox%3D%220%200%20400%20400%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22200%22%20cy%3D%22152%22%20r%3D%2256%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2288%22%20y%3D%22232%22%20width%3D%22224%22%20height%3D%2264%22%20rx%3D%2220%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2233%22%20fill%3D%22%237c3aed%22%3ELinko%20400%C3%97400%3C/text%3E%0A%3C/svg%3E" + (901 + idx);
  }

  function renderMyAlbum() {
    const grid = document.getElementById("myAlbumGrid");
    if (!grid) return;
    const photos = hmLoadAlbumPhotos();

    grid.innerHTML = "";

    for (let i = 0; i < MY_ALBUM_SLOTS; i++) {
      const slot = document.createElement("div");
      slot.className = "my-album-item";

      const img = document.createElement("img");
      img.alt = "我的相簿照片 " + (i + 1);
      if (photos[i]) {
        img.src = photos[i];
        img.style.objectFit = "cover";
      } else {
        img.style.objectFit = "contain";
      }
      slot.appendChild(img);

      const label = document.createElement("div");
      label.className = "my-album-label";
      if (i < 2) {
        label.textContent = "第 " + (i + 1) + " 張 · 對外免費預覽";
      } else {
        label.textContent = "第 " + (i + 1) + " 張 · 對陌生人為鎖定照片（需解鎖後才會顯示）";
      }
      slot.appendChild(label);

      const fileInput = document.createElement("input");
      fileInput.type = "file";
      fileInput.accept = "image/*";
      fileInput.style.display = "none";
      fileInput.id = "myAlbumInput_" + i;
      slot.appendChild(fileInput);

      const uploadBtn = document.createElement("button");
      uploadBtn.type = "button";
      uploadBtn.className = "my-album-upload-btn";
      uploadBtn.textContent = photos[i] ? "更換" : "上傳";
      uploadBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        fileInput.click();
      });
      slot.appendChild(uploadBtn);

      fileInput.addEventListener("change", (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => {
          const result = ev.target && ev.target.result;
          if (!result) return;
          const arr = hmLoadAlbumPhotos();
          arr[i] = result;
          myAlbumPhotosCache = arr;
          hmSaveAlbumPhotos();
          // 同步相簿照片到 Supabase（寫入 profile_photos，讓對外資料與跨裝置一致）
          try { await hmInsertProfilePhotoToSupabase(result, false); } catch(e) {}
          try { await hmHydrateMyPhotosFromSupabase(); } catch(e) {}
          renderMyAlbum();
          if (pages.profileDetail.classList.contains("active") && currentProfileId != null) {
            openProfileDetail(currentProfileId);
          }
        };
        reader.readAsDataURL(file);
      });

      grid.appendChild(slot);
    }
  }


  function hmShowAlbumAdPrompt() {
    const mins = (typeof hmGetAlbumUnlockMinutesConfig === 'function') ? hmGetAlbumUnlockMinutesConfig() : 20;
    const go = confirm("這 4 張照片需觀看一次解鎖流程，完成後可在 " + mins + " 分鐘內查看。\n要立即解鎖嗎？");
    if (!go) return;
    hmAlbumUnlockFor20Minutes();
    try { alert("已為你開啟限時查看權限。"); } catch (e) {}
  }

  function handleStrangerAlbumClick(personId, idx) {
    const entitledVip = (typeof hmIsVipEntitledActive === 'function') ? hmIsVipEntitledActive() : false;
    const vip = hmGetVipLevel();
    if (idx < 2 || entitledVip || vip > 0 || hmAlbumIsUnlocked()) {
      openPhotoViewer(hmGetPersonAlbumPhotoSrc(personId, idx));
    } else {
      hmShowAlbumAdPrompt();
    }
  }
  window.handleStrangerAlbumClick = handleStrangerAlbumClick;
  window.hmGetAlbumPhotoSrc = hmGetAlbumPhotoSrc;
  window.hmGetPersonAlbumPhotoSrc = hmGetPersonAlbumPhotoSrc;

  if (chatBackBtn) {
    chatBackBtn.addEventListener("click", () => {
      hideChatPanel();
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    pickRandomBatch();
    renderPeopleGrid();

    // 送禮面板初始化
    try { hmInitGiftModal(); } catch (e) {}

    // 好友 tab 元件
    friendTabFriendsEl = document.querySelector('.tab-btn[data-friendtab="friends"]');
    friendTabSentEl = document.querySelector('.tab-btn[data-friendtab="sent"]');
    friendTabReceivedEl = document.querySelector('.tab-btn[data-friendtab="received"]');
    updateFriendTabCounts();

    renderFriendsList("friends");
    updateMyStatus();
    updateFriendNotePreview();
    renderTopRightForPage("people");
    renderRank("pop");

    // 初始化 Monetization 快取（相簿解鎖/權益）
    try { if (typeof hmMonetizationLoadLocal === 'function') hmMonetizationLoadLocal(); } catch(e) {}

    // 初始化 VIP & 我的照片
    hmUpdateVipUI();
    renderMyAlbum();
    renderMyDiaries();
    initMoodSquare();

    // 初始化「我的」頭貼（讀取 & 點擊上傳）
    hmInitAvatar();
    hmBindAvatarUploader();

    // 初始化聊天模組
    initChatModule();

    // 我的日記輸入元件綁定
    const diaryInput = document.getElementById("myDiaryInput");
    const diaryImageUpload = document.getElementById("myDiaryImageUpload");
    const diaryImageCamera = document.getElementById("myDiaryImageCamera");
    const diaryImageUploadBtn = document.getElementById("myDiaryImageUploadBtn");
    const diaryImageCameraBtn = document.getElementById("myDiaryImageCameraBtn");
    const diaryImageSize = document.getElementById("myDiaryImageSize");
    const diaryImageSizeText = document.getElementById("myDiaryImageSizeText");
    const diaryTextSize = document.getElementById("myDiaryTextSize");
    const diaryTextSizeText = document.getElementById("myDiaryTextSizeText");
    const diaryImagePreview = document.getElementById("myDiaryImagePreview");
    const diaryImagePreviewImg = document.getElementById("myDiaryImagePreviewImg");
    const diaryTextPreview = document.getElementById("myDiaryTextPreview");
    const diaryAddBtn = document.getElementById("myDiaryAddBtn");
    let diaryPendingImage = null;
    let diaryPendingImageSize = diaryImageSize ? (Number(diaryImageSize.value) || 80) : 80;
    let diaryPendingTextSize = diaryTextSize ? (Number(diaryTextSize.value) || 18) : 18;

    function bindDiaryFileInput(inputEl) {
      if (!inputEl) return;
      inputEl.addEventListener("change", (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) {
          diaryPendingImage = null;
          updateDiaryPreview();
          return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
          diaryPendingImage = ev.target && ev.target.result;
          updateDiaryPreview();
        };
        reader.readAsDataURL(file);
      });
    }

    if (diaryImageUploadBtn && diaryImageUpload) {
      diaryImageUploadBtn.addEventListener("click", () => diaryImageUpload.click());
    }
    if (diaryImageCameraBtn && diaryImageCamera) {
      diaryImageCameraBtn.addEventListener("click", () => diaryImageCamera.click());
    }

    bindDiaryFileInput(diaryImageUpload);
    bindDiaryFileInput(diaryImageCamera);

    function updateDiaryPreview() {
      const hasImage = !!diaryPendingImage;
      const textValue = diaryInput ? diaryInput.value.trim() : "";
      if (diaryImagePreview) {
        diaryImagePreview.style.display = (hasImage || textValue) ? "block" : "none";
      }
      if (diaryImagePreviewImg) {
        if (hasImage) {
          diaryImagePreviewImg.src = diaryPendingImage;
          diaryImagePreviewImg.style.display = "block";
          diaryImagePreviewImg.style.maxWidth = diaryPendingImageSize + "%";
        } else {
          diaryImagePreviewImg.removeAttribute("src");
          diaryImagePreviewImg.style.display = "none";
        }
      }
      if (diaryTextPreview) {
        diaryTextPreview.style.fontSize = diaryPendingTextSize + "px";
        diaryTextPreview.innerHTML = textValue ? String(textValue).replace(/\n/g, "<br>") : '<span style="color:#9ca3af;">這裡會顯示日記文字預覽</span>';
      }
    }

    if (diaryImageSize && diaryImageSizeText) {
      const updateDiarySizeLabel = () => {
        diaryPendingImageSize = Number(diaryImageSize.value) || 80;
        diaryImageSizeText.textContent = "照片大小：" + diaryPendingImageSize + "%";
        updateDiaryPreview();
      };
      diaryImageSize.addEventListener("input", updateDiarySizeLabel);
      updateDiarySizeLabel();
    }

    if (diaryTextSize && diaryTextSizeText) {
      const updateDiaryTextSizeLabel = () => {
        diaryPendingTextSize = Number(diaryTextSize.value) || 18;
        diaryTextSizeText.textContent = "字體大小：" + diaryPendingTextSize + "px";
        updateDiaryPreview();
      };
      diaryTextSize.addEventListener("input", updateDiaryTextSizeLabel);
      updateDiaryTextSizeLabel();
    }

    if (diaryInput) {
      diaryInput.addEventListener("input", updateDiaryPreview);
    }
    updateDiaryPreview();

	    async function handleDiaryAdd() {
      if (!diaryInput) return;
      const text = diaryInput.value.trim();
      if (!text && !diaryPendingImage) {
        alert("請至少輸入一些文字或選擇一張圖片。");
        return;
      }
      const list = hmLoadDiaries();
      const limit = hmGetDiaryLimit();
      if (list.length >= limit) {
        alert("目前最多只能建立 " + limit + " 則日記。升級 VIP 後可擴充到 30 則。");
        return;
      }
      const now = new Date();
      const diary = {
        id: now.getTime(),
        text,
        image: diaryPendingImage,
        imageSize: diaryPendingImageSize,
        textSize: diaryPendingTextSize,
        createdAt: now.toISOString()
      };
      list.push(diary);
      hmSaveDiaries(list);
	      // 同步公開日記到 Supabase（避免「我的日記有改，但對外資料沒跟著變」）
	      try {
	        const isPublic = (document.getElementById("myDiaryIsPublic") && document.getElementById("myDiaryIsPublic").checked) ? true : false;
	        if (isPublic && !text && !diaryPendingImage) {
	          alert("公開日記建議至少填寫一些文字，否則對外顯示會是空白。\n\n你可以先取消勾選『公開』，或補上文字後再送出。");
	        } else {
	          const sbRes = await hmInsertDiaryToSupabase(text || "", isPublic, diaryPendingImage || null);
	          if (sbRes && sbRes.ok) {
	            try {
	              if (sbRes.warning === "missing_image_url_column" && diaryPendingImage) {
	                alert("日記文字已同步到 Supabase，但『image_url』欄位尚未建立，因此照片無法同步。\n\n請到 Supabase SQL Editor 執行：\nALTER TABLE public.diaries ADD COLUMN IF NOT EXISTS image_url text;\n\n執行後再新增一次含照片的日記即可。");
	              }
	            } catch(_e) {}
	            diary.sb_id = sbRes.id || null;
	            diary.is_public = isPublic;
	            // 回寫一次（讓本機也記得這則已同步）
	            hmSaveDiaries(list);
	          } else {
	            console.warn("diary sync failed", sbRes);
	            alert("已新增到本機日記，但未同步到 Supabase（因此對外資料看不到）。\n\n請確認：\n1) 已在右下 Supabase 設定並登入\n2) Supabase 已建立 diaries 表與 RLS\n3) 勾選『公開』才會顯示給別人");
	          }
	        }
	      } catch(e) { console.warn(e); }
      diaryInput.value = "";
      if (diaryImageUpload) diaryImageUpload.value = "";
      if (diaryImageCamera) diaryImageCamera.value = "";
      diaryPendingImage = null;
      if (diaryTextSize) diaryTextSize.value = "18";
      diaryPendingTextSize = 18;
      if (diaryImageSize) diaryImageSize.value = "80";
      diaryPendingImageSize = 80;
      updateDiaryPreview();
      renderMyDiaries();
    }

    if (diaryAddBtn) {
      diaryAddBtn.addEventListener("click", handleDiaryAdd);
    }

    const vipToggleBtn = document.getElementById("vipLevelToggleBtn");
    if (vipToggleBtn) {
      vipToggleBtn.addEventListener("click", () => {
        let lvl = hmGetVipLevel();
        lvl = (lvl + 1) % 6; // 0~5 循環
        hmSetVipLevel(lvl);
      });
    }


    // VIP60（訂閱/權益）按鈕
    const vip60Btn = document.getElementById("vip60SubscribeBtn");
    if (vip60Btn) {
      vip60Btn.addEventListener("click", async () => {
        try { await hmVip60HandleSubscribeClick(); } catch (e) {}
      });
    }
    const vip60DevGrantBtn = document.getElementById("vip60DevGrantBtn");
    if (vip60DevGrantBtn) {
      vip60DevGrantBtn.addEventListener("click", async () => {
        try {
          const r = await hmBackendDevGrantVip60(30);
          if (!r || !r.ok) return alert('測試開通失敗：' + (r && r.reason ? r.reason : 'unknown'));
          try { if (typeof hmMonetizationBootstrap === 'function') await hmMonetizationBootstrap(); } catch (e) {}
          try { if (typeof hmSyncInventoryCache === 'function') await hmSyncInventoryCache(); } catch (e) {}
          try { if (typeof hmRewardRenderUI === 'function') await hmRewardRenderUI({ force: true }); } catch (e) {}
          try { if (typeof hmRenderMoodList === 'function') hmRenderMoodList(); } catch (e) {}
          try { if (typeof hmUpdateVipUI === 'function') hmUpdateVipUI(); } catch (e) {}
        } catch (e) {}
      });
    }
    const vip60DevRevokeBtn = document.getElementById("vip60DevRevokeBtn");
    if (vip60DevRevokeBtn) {
      vip60DevRevokeBtn.addEventListener("click", async () => {
        try { await hmVip60HandleDevRevoke(); } catch (e) {}
      });
    }


    // 登入 / 基本資料 Modal
    const loginModal = document.getElementById("hm-login-modal");
    const profileModal = document.getElementById("hm-profile-modal");
    const form = document.getElementById("hm-profile-form");

    if (!hmHasCompletedProfile()) {
      if (loginModal) loginModal.style.display = "flex";
    }

    function handleFakeLogin(provider) {
      hmSetAuthProvider(provider);
      if (loginModal) loginModal.style.display = "none";
      if (!hmHasCompletedProfile() && profileModal) {
        // 初次綁定後，開啟完整基本資料填寫
        const headerTitle = profileModal.querySelector(".hm-modal-header h2");
        const headerSub = profileModal.querySelector(".hm-modal-header p");
        if (headerTitle) headerTitle.textContent = "完成基本資料，開始配對";
        if (headerSub) headerSub.textContent = "為了提升真實度與配對品質，請先填寫以下資訊。";
        hmFillProfileForm({ lockBasic: false });
        profileModal.style.display = "flex";
      }
      hmInitProfileCard();
      hmInitMyProfileHeader();
      hmWireRegionOtherToggle();
      // A) 頁面載入時自動從 public.profiles 讀回資料並回填
      hmHydrateProfileFromSupabase();
    }

    const btnGoogle = document.getElementById("hm-login-google");
    const btnFacebook = document.getElementById("hm-login-facebook");
    const btnApple = document.getElementById("hm-login-apple");

    if (btnGoogle) {
      btnGoogle.addEventListener("click", () => handleFakeLogin("google"));
    }
    if (btnFacebook) {
      btnFacebook.addEventListener("click", () => handleFakeLogin("facebook"));
    }
    if (btnApple) {
      btnApple.addEventListener("click", () => handleFakeLogin("apple"));
    }

    if (form) {
      form.addEventListener("submit", async function (e) {
        e.preventDefault();

        const alreadyCompleted = hmHasCompletedProfile();

        const name = document.getElementById("hm-name").value.trim();
        const height = document.getElementById("hm-height").value.trim();
        const weight = document.getElementById("hm-weight").value.trim();
        const gender = (document.getElementById("hm-gender") && document.getElementById("hm-gender").value || "").trim();
        const age_range = (document.getElementById("hm-age-range") && document.getElementById("hm-age-range").value || "").trim();
                const region = hmGetRegionFromForm();
const threads = document.getElementById("hm-threads").value.trim();
        const x = document.getElementById("hm-x").value.trim();
        const instagram = document.getElementById("hm-instagram").value.trim();
        const facebook = document.getElementById("hm-facebook").value.trim();
        const other = document.getElementById("hm-other").value.trim();
        const agree = document.getElementById("hm-agree").checked;

        let existingProfile = null;
        try {
          const raw = localStorage.getItem("hmProfileData");
          if (raw) existingProfile = JSON.parse(raw);
        } catch (err) {
          console.warn("解析現有 Profile 失敗：", err);
        }
        if (!existingProfile) existingProfile = {};

        if (!alreadyCompleted || !existingProfile.name || !existingProfile.height || !existingProfile.weight) {
          // 第一次完成基本資料（或本機資料缺失），需要完整驗證
          if (!name) {
            alert("請填寫稱呼（暱稱）");
            return;
          }
          if (!height || !weight) {
            alert("身高與體重為必填欄位");
            return;
          }
          if (!gender) {
            alert("請選擇性別");
            return;
          }
          if (!age_range) {
            alert("請選擇年齡層");
            return;
          }
          if (!agree) {
            alert("請勾選同意服務條款與隱私政策");
            return;
          }
        } else {
          // 已完成基本資料後再次開啟，只允許修改社群帳號
          // 不再強制檢查稱呼 / 身高 / 體重
        }

        let profileData;
        if (!alreadyCompleted || !existingProfile.name || !existingProfile.height || !existingProfile.weight) {
          // 初次建立或補齊缺漏，全部寫入
          profileData = {
            name,
            gender,
            age_range,
            height,
            weight,
            region,
            socials: { threads, x, instagram, facebook, other },
            createdAt: existingProfile.createdAt || new Date().toISOString()
          };
        } else {
  // 已完成基本資料後：仍允許把 name/height/weight/region 同步寫回 Supabase
  // （避免 Supabase 那筆 name 仍為 NULL 時永遠補不上）
  profileData = Object.assign({}, existingProfile, {
    name,
    gender,
    age_range,
    height,
    weight,
    region,
    socials: { threads, x, instagram, facebook, other }
  });
}


        hmSaveProfileData(profileData);

        // 同步寫入 Supabase public.profiles（以 auth.uid() 當作 id，使用 upsert）
        // 若尚未設定 SB_URL/SB_ANON_KEY 或尚未登入，會自動略過，不影響本地 Demo 流程。
        try {
          const sbRes = await hmUpsertProfileToSupabase(profileData);
          if (sbRes && sbRes.ok) {
            console.log("已同步至 Supabase profiles：", sbRes.data);
          } else if (sbRes && sbRes.skipped) {
            console.log("Supabase 同步略過：", sbRes.reason);
          }
        } catch (err) {
          console.warn("Supabase profiles 同步失敗（不影響本地 Demo）：", err);
        }
        if (profileModal) profileModal.style.display = "none";

        // Daily Reward popup: after Email 綁定 + 基本資料完成
        try { setTimeout(function(){ if (typeof hmMaybeShowRewardModal === "function") hmMaybeShowRewardModal({ reason: "profileCompleted" }); }, 80); } catch (e) {}

        hmInitProfileCard();
        hmInitMyProfileHeader();
        console.log(alreadyCompleted ? "HeartMeet 社群資料已更新：" : "HeartMeet 基本資料已完成：", profileData);
      });
    }

    hmInitProfileCard();
    hmInitMyProfileHeader();
    hmInitAvatar();
    hmBindAvatarUploader();

    const editBtn = document.getElementById("hm-profile-edit-btn");
    if (editBtn && profileModal) {
      editBtn.addEventListener("click", function () {
        const isCompleted = hmHasCompletedProfile();
        const headerTitle = profileModal.querySelector(".hm-modal-header h2");
        const headerSub = profileModal.querySelector(".hm-modal-header p");

        if (isCompleted) {
          if (headerTitle) headerTitle.textContent = "編輯社群帳號";
          if (headerSub) headerSub.textContent = "基本資料（稱呼、身高、體重、居住區域）已鎖定，如需修改請刪除帳號重新建立。本畫面僅供補上或調整社群帳號。";
          hmFillProfileForm({ lockBasic: true });
        } else {
          if (headerTitle) headerTitle.textContent = "完成基本資料，開始配對";
          if (headerSub) headerSub.textContent = "為了提升真實度與配對品質，請先填寫以下資訊。";
          hmFillProfileForm({ lockBasic: false });
        }

        profileModal.style.display = "flex";
      });
    }

    const logoutBtn = document.getElementById("hm-logout-btn");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", function () {
        if (!confirm("確定要登出並清除本機的暫存資料嗎？\n（包含基本資料、綁定系統、VIP 等級與相簿照片 Demo 資料）")) {
          return;
        }
        try {
          localStorage.removeItem("hmProfileData");
          localStorage.removeItem("hmProfileCompleted");
          localStorage.removeItem("hmAuthProvider");
          localStorage.removeItem("hmVipLevel");
          localStorage.removeItem("hmMyAlbumPhotos");
          localStorage.removeItem("hmAlbumUnlockUntil");
          localStorage.removeItem("hmAvatarImage");
          sessionStorage.removeItem("hmAlbumUnlocked");
        // 同步清除每日簽到 / 獎勵紀錄（避免切換帳號造成混用）
        try {
          Object.keys(localStorage || {}).forEach(function(k){
            if (!k) return;
            if (k.indexOf("hmRewardState::") === 0 || k.indexOf("hmRewardLastShown::") === 0) {
              localStorage.removeItem(k);
            }
          });
        } catch (e) {}

        } catch (e) {
          console.warn("登出時清除 localStorage / sessionStorage 失敗：", e);
        }
        location.reload();
      });
    }



// ================== Supabase Auth: Email 登入 / 註冊 / 切換（放在填寫資料 Modal 底部） ==================
async function hmRefreshAuthStatusUI() {
  try {
    const statusEl = document.getElementById("hm-auth-status");
    const emailEl = document.getElementById("hm-auth-email");
    const passEl = document.getElementById("hm-auth-password");
    if (!statusEl || !emailEl || !passEl) return;

    const cli = await hmGetSupabaseClient();
    if (!cli) {
      statusEl.textContent = "尚未初始化 Supabase（請先在右下角 Supabase Test Panel 填 SB_URL / ANON_KEY）";
      return;
    }

    const sessRes = await cli.auth.getSession();
    const session = (sessRes && sessRes.data) ? sessRes.data.session : null;
    const email = session && session.user ? (session.user.email || "") : "";
    if (email) {
      statusEl.textContent = "目前登入 Email：" + email;
      if (!emailEl.value) emailEl.value = email;
      try { await hmBackendTryClaimLoginGiftOnce(); } catch (e) {}
      try { if (typeof hmMonetizationBootstrap === 'function') await hmMonetizationBootstrap(); } catch (e) {}
    } else {
      statusEl.textContent = "尚未登入（請輸入 Email / Password 後按登入或註冊）";
    }
  } catch (e) {
    console.warn("hmRefreshAuthStatusUI 失敗：", e);
  }
}

async function hmAuthEnsureClientOrAlert() {
  const cli = await hmGetSupabaseClient();
  if (!cli) {
    alert("Supabase 尚未初始化。\n請先在右下角 Supabase Test Panel 綁定 SUPABASE_URL / ANON_KEY。");
    return null;
  }
  return cli;
}

async function hmAuthSignInWithPassword(email, password) {
  const cli = await hmAuthEnsureClientOrAlert();
  if (!cli) return;
  const res = await cli.auth.signInWithPassword({ email: email, password: password });
  if (res && res.error) throw res.error;
  return res;
}

async function hmAuthSignUp(email, password) {
  const cli = await hmAuthEnsureClientOrAlert();
  if (!cli) return;
  const res = await cli.auth.signUp({ email: email, password: password });
  if (res && res.error) throw res.error;
  return res;
}

async function hmAuthSignOutEmail() {
  const cli = await hmAuthEnsureClientOrAlert();
  if (!cli) return;
  await cli.auth.signOut();
  try {
    localStorage.removeItem("hmProfileData");
    localStorage.removeItem("hmProfileCompleted");
    localStorage.removeItem("hmAuthProvider");
    localStorage.removeItem("hmVipLevel");
    localStorage.removeItem("hmMyAlbumPhotos");
    localStorage.removeItem("hmAlbumUnlockUntil");
    localStorage.removeItem("hmAvatarImage");
    sessionStorage.removeItem("hmAlbumUnlocked");
        // 同步清除每日簽到 / 獎勵紀錄（避免切換帳號造成混用）
        try {
          Object.keys(localStorage || {}).forEach(function(k){
            if (!k) return;
            if (k.indexOf("hmRewardState::") === 0 || k.indexOf("hmRewardLastShown::") === 0) {
              localStorage.removeItem(k);
            }
          });
        } catch (e) {}

  } catch (e) { /* ignore */ }
}

// Bind modal auth buttons (safe: 不影響主程式)
(function bindHmAuthUiInProfileModal() {
  try {
    const btnIn = document.getElementById("hm-auth-signin-btn");
    const btnUp = document.getElementById("hm-auth-signup-btn");
    const btnOut = document.getElementById("hm-auth-signout-btn");
    const emailEl = document.getElementById("hm-auth-email");
    const passEl = document.getElementById("hm-auth-password");

    if (btnIn) btnIn.addEventListener("click", async function () {
      try {
        const email = (emailEl && emailEl.value ? emailEl.value : "").trim();
        const password = (passEl && passEl.value ? passEl.value : "").trim();
        if (!email || !password) { alert("請輸入 Email 與 Password"); return; }
        await hmAuthSignInWithPassword(email, password);
        await hmRefreshAuthStatusUI();
        try { await hmRefreshFriendsFromSupabase(); } catch (e) {}
        try { setTimeout(function(){ if (typeof hmMaybeShowRewardModal === "function") hmMaybeShowRewardModal({ reason: "emailLogin" }); }, 80); } catch (e) {}
        alert("登入成功。\n請回到「巧遇」按「換一批」載入真人資料。");
      } catch (e) {
        console.warn("登入失敗：", e);
        alert("登入失敗：" + (e && e.message ? e.message : e));
      }
    });

    if (btnUp) btnUp.addEventListener("click", async function () {
      try {
        const email = (emailEl && emailEl.value ? emailEl.value : "").trim();
        const password = (passEl && passEl.value ? passEl.value : "").trim();
        if (!email || !password) { alert("請輸入 Email 與 Password"); return; }
        await hmAuthSignUp(email, password);
        await hmRefreshAuthStatusUI();
        try { await hmRefreshFriendsFromSupabase(); } catch (e) {}
        alert("註冊成功。\n若專案有啟用 Email 驗證，請先完成信箱驗證後再登入。");
      } catch (e) {
        console.warn("註冊失敗：", e);
        alert("註冊失敗：" + (e && e.message ? e.message : e));
      }
    });

    if (btnOut) btnOut.addEventListener("click", async function () {
      try {
        if (!confirm("確定要登出 Email 嗎？\n登出後你可以切換到另一個 Email 登入。")) return;
        await hmAuthSignOutEmail();
        await hmRefreshAuthStatusUI();
        alert("已登出 Email。");
      } catch (e) {
        console.warn("登出失敗：", e);
        alert("登出失敗：" + (e && e.message ? e.message : e));
      }
    });

    // init status (best-effort)
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", hmRefreshAuthStatusUI);
    } else {
      hmRefreshAuthStatusUI();
    }
  } catch (e) {
    console.warn("bindHmAuthUiInProfileModal 失敗：", e);
  }
})();

// Supabase Auth 登出（切換 Email）
const signOutEmailBtn = document.getElementById("hm-signout-email-btn");
if (signOutEmailBtn) {
  signOutEmailBtn.addEventListener("click", function () {
    if (!confirm("確定要登出 Email 嗎？\n登出後你可以使用另一個 Email 重新登入。")) return;

    // 確保 Supabase SDK 已載入
    hmEnsureSupabaseSdk().then(function () {
      if (!hmSupabaseClient || !hmSupabaseClient.auth) {
        alert("Supabase 尚未初始化。\n請先在右下角 Supabase Test Panel 綁定 SUPABASE_URL / ANON_KEY。登入/註冊可在「填寫資料」視窗底部操作。");
        return;
      }

      hmSupabaseClient.auth
        .signOut()
        .then(function () {
          // 同步清除本機暫存（避免同一裝置殘留 UI 狀態）
          try {
            localStorage.removeItem("hmProfileData");
            localStorage.removeItem("hmProfileCompleted");
            localStorage.removeItem("hmAuthProvider");
            localStorage.removeItem("hmVipLevel");
            localStorage.removeItem("hmMyAlbumPhotos");
            localStorage.removeItem("hmAlbumUnlockUntil");
            localStorage.removeItem("hmAvatarImage");
            sessionStorage.removeItem("hmAlbumUnlocked");
        // 同步清除每日簽到 / 獎勵紀錄（避免切換帳號造成混用）
        try {
          Object.keys(localStorage || {}).forEach(function(k){
            if (!k) return;
            if (k.indexOf("hmRewardState::") === 0 || k.indexOf("hmRewardLastShown::") === 0) {
              localStorage.removeItem(k);
            }
          });
        } catch (e) {}

          } catch (e) {
            console.warn("Email 登出時清除 localStorage / sessionStorage 失敗：", e);
          }
          location.reload();
        })
        .catch(function (err) {
          console.warn("Supabase signOut 失敗：", err);
          alert("登出失敗：" + (err && err.message ? err.message : err));
        });
    }).catch(function (e) {
      console.warn("載入 Supabase SDK 失敗：", e);
      alert("載入 Supabase SDK 失敗，請確認網路後重試。");
    });
  });
}
  });
 
  // === Expose inline onclick handlers (important for mobile & GitHub Pages) ===
  // Some browsers do not resolve functions declared in script scope from HTML event attributes unless
  // they are attached to window. Export the handlers we use in onclick="...".
  try {
    window.hmAddFriend = hmAddFriend;
    window.hmAcceptFriend = hmAcceptFriend;
    window.hmRejectFriend = hmRejectFriend;
    window.hmCancelFriendRequest = hmCancelFriendRequest;
    window.hmSimulateIncomingFriendRequest = hmSimulateIncomingFriendRequest;
    window.hmOpenFriendProfile = hmOpenFriendProfile;
    window.hmBlockOrReport = hmBlockOrReport;
    window.handleStrangerAlbumClick = handleStrangerAlbumClick;
    window.openChatWith = openChatWith;
    window.sendGiftAnimationFromHeader = sendGiftAnimationFromHeader;
    window.closeViewer = closeViewer;
  } catch (e) {
    console.warn("[ExposeHandlers] failed", e);
  }

