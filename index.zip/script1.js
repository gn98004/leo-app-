
document.addEventListener("change", function (e) {
  const input = e.target;
  if (
    input.type === "file" &&
    (input.id.includes("photo") || input.id.includes("diary"))
  ) {
    let preview = input.parentElement.querySelector(".photo-preview");
    if (!preview) {
      preview = document.createElement("div");
      preview.className = "photo-preview";
      preview.style.display = "flex";
      preview.style.flexWrap = "wrap";
      preview.style.gap = "8px";
      preview.style.padding = "10px 0";
      input.parentElement.appendChild(preview);
    }
    preview.innerHTML = "";

    const files = input.files;
    if (!files || files.length === 0) return;

    [...files].forEach((file) => {
      if (!file.type.startsWith("image/")) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const img = document.createElement("img");
        img.src = ev.target.result;
        img.style.width = "90px";
        img.style.height = "90px";
        img.style.objectFit = "cover";
        img.style.borderRadius = "12px";
        img.style.boxShadow = "0 2px 6px rgba(0,0,0,0.15)";
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  }
});
