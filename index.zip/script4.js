
(function(){
  const POST_COST = 5;
  const REPLY_OTHER_COST = 1;
  const REPLY_COOLDOWN_MS = 30 * 1000;
  const MAX_SELF_REPLIES_PER_POST = 5;
  const STICKERS = ["🌹","😊","🥺","❤️","👍","😭"];

  function hmPatchDailyRewards(){
    window.hmRewardComputeForDay = function(dayNum){
      const d = parseInt(dayNum || "0", 10);
      if (!Number.isFinite(d) || d <= 0) return { type: "rose", qty: 1, label: "🌹 玫瑰 x1" };
      if (d % 7 === 0) return { type: "rose", qty: 5, label: "💐 1束玫瑰（5朵）" };
      return { type: "rose", qty: 1, label: "🌹 玫瑰 x1" };
    };
    try {
      const summary = document.getElementById("hm-daily-reward-summary");
      if (summary) summary.innerHTML = '每日登入獎勵：<b>🌹 1朵</b><br>第 7 天：<b>💐 1束＝5朵</b>';
    } catch(e){}
    try { if (typeof hmRewardRenderUI === "function") hmRewardRenderUI({force:true}); } catch(e){}
  }

  function hmApplyMoodTexts(){
    const sub = document.querySelector("#page-mood .mood-sub");
    if (sub){
      sub.innerHTML =
        '匿名或顯示暱稱，分享今天的心情。<br>' +
        '<span class="mood-rules-inline"><span class="rose-big">🌹</span> 發文消耗 5 玫瑰；回覆自己帖子免費但不頂帖；回覆他人消耗 1 玫瑰。</span><br>' +
        '回覆需間隔 30 秒；每篇最多自回 5 則。<br>' +
        '發帖最多可附 3 張圖；回覆他人僅限文字與簡單貼圖。';
    }
    const cost = document.querySelector("#page-mood .mood-rose-cost");
    if (cost) cost.innerHTML = '每次發佈會消耗 🌹 <span>5</span> 玫瑰';
  }

  let moodSelectedImages = [];

  function fileToCompressedDataUrl(file){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const maxSize = 1280;
          let w = img.width, h = img.height;
          if (w > h && w > maxSize) { h = Math.round(h * maxSize / w); w = maxSize; }
          else if (h >= w && h > maxSize) { w = Math.round(w * maxSize / h); h = maxSize; }
          const canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function renderMoodImagePreview(){
    const wrap = document.getElementById("moodImagePreview");
    if (!wrap) return;
    wrap.innerHTML = "";
    moodSelectedImages.forEach((src, idx) => {
      const item = document.createElement("div");
      item.className = "mood-image-thumb";
      item.innerHTML = '<img src="'+src+'" alt="preview"><button type="button" class="mood-image-remove">✕</button>';
      item.querySelector("button").addEventListener("click", () => {
        moodSelectedImages.splice(idx, 1);
        renderMoodImagePreview();
      });
      wrap.appendChild(item);
    });
  }

  function bindMoodImageInput(){
    const input = document.getElementById("moodImageInput");
    if (!input || input.dataset.bound) return;
    input.dataset.bound = "1";
    input.addEventListener("change", async (e) => {
      const files = Array.from((e.target && e.target.files) || []).slice(0, 3);
      if (!files.length) { moodSelectedImages = []; renderMoodImagePreview(); return; }
      try {
        const urls = [];
        for (const f of files) urls.push(await fileToCompressedDataUrl(f));
        moodSelectedImages = urls.slice(0, 3);
        renderMoodImagePreview();
      } catch(err){
        alert("圖片處理失敗，請改用其他圖片再試一次");
      }
      input.value = "";
    });
  }

  function parsePostImages(post){
    const raw = post && post.image_url ? String(post.image_url) : "";
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.filter(Boolean).slice(0,3);
    } catch(e){}
    return [raw];
  }

  const oldNormalizePost = window.hmMoodNormalizePostRow;
  window.hmMoodNormalizePostRow = function(r){
    const out = oldNormalizePost ? oldNormalizePost(r) : {
      id: String((r&&r.id)||""),
      user_id: String((r&&r.user_id)||""),
      content: String((r&&r.content)||""),
      image_url: r&&r.image_url ? String(r.image_url) : "",
      createdAt: r&&r.created_at ? Date.parse(r.created_at) : Date.now(),
      is_anonymous: !!(r&&r.is_anonymous),
      allow_replies: (r && r.allow_replies === false) ? false : true
    };
    out.image_urls = parsePostImages(out);
    return out;
  };

  function getReplyCooldownKey(uid){
    return "hm_mood_reply_cooldown_" + String(uid || "");
  }

  function readLocalReplyCooldown(uid){
    try {
      const raw = localStorage.getItem(getReplyCooldownKey(uid));
      const ts = parseInt(raw || "0", 10);
      return Number.isFinite(ts) ? ts : 0;
    } catch(e){
      return 0;
    }
  }

  function writeLocalReplyCooldown(uid, ts){
    try { localStorage.setItem(getReplyCooldownKey(uid), String(ts || Date.now())); } catch(e){}
  }

  async function getLatestReplyTime(cli, uid){
    let latest = readLocalReplyCooldown(uid);
    try {
      const res = await cli
        .from("post_replies")
        .select("created_at")
        .eq("user_id", uid)
        .order("created_at", { ascending: false })
        .limit(1);

      const row = res && res.data && res.data[0] ? res.data[0] : null;
      const ts = row && row.created_at ? Date.parse(row.created_at) : 0;
      if (Number.isFinite(ts) && ts > latest) latest = ts;
    } catch(e){}
    return latest;
  }

  async function getSelfReplyCountForPost(cli, uid, postId){
    try {
      const res = await cli
        .from("post_replies")
        .select("id", { count: "exact", head: true })
        .eq("post_id", postId)
        .eq("user_id", uid);
      const c = (res && typeof res.count === "number") ? res.count : 0;
      return c;
    } catch(e){
      return 0;
    }
  }

  window.hmMoodInsertPost = async function(){
    const contentEl = document.getElementById("moodContentInput");
    const allowEl = document.getElementById("moodAllowReplies");
    if (!contentEl) return;

    const content = String(contentEl.value || "").trim();
    if (!content) { alert("請先輸入內容"); return; }

    await hmSyncInventoryCache();
    const roses = (typeof hmLoadMoodRoses === "function") ? hmLoadMoodRoses() : 0;
    if (roses < POST_COST) { alert("🌹 玫瑰不足，發文需要 5 朵玫瑰。"); return; }

    const identity = document.querySelector('input[name="moodIdentity"]:checked')?.value || "anon";
    const isAnon = identity !== "public";
    const allowReplies = allowEl ? !!allowEl.checked : true;
    const imagePayload = moodSelectedImages.length ? JSON.stringify(moodSelectedImages.slice(0,3)) : "";

    const { ok, cli, uid } = await hmMoodGetClientAndUid();
    if (!ok) { alert("請先登入 Email，才能發佈"); return; }

    try {
      const ctx = hmRewardTzYmd();
      const start = ctx.ymd + "T00:00:00+08:00";
      const end = ctx.ymd + "T23:59:59+08:00";
      const cntRes = await cli.from("posts").select("id", { count: "exact", head: true }).eq("user_id", uid).gte("created_at", start).lte("created_at", end);
      const c = (cntRes && typeof cntRes.count === "number") ? cntRes.count : 0;
      if (c >= 3) { alert("今日心情貼文已達上限（3 篇）。"); return; }
    } catch (e) {}

    let ins = await cli.from("posts").insert({
      user_id: uid,
      content: content,
      image_url: imagePayload,
      is_anonymous: isAnon,
      allow_replies: allowReplies
    }).select("id").limit(1);

    if (ins.error && String(ins.error.message || "").toLowerCase().includes("is_anonymous")) {
      ins = await cli.from("posts").insert({
        user_id: uid,
        content: content,
        image_url: imagePayload
      }).select("id").limit(1);
    }
    if (ins.error) {
      alert("發佈失敗：" + (ins.error.message || "unknown"));
      return;
    }

    const postId = ins.data && ins.data[0] && ins.data[0].id ? ins.data[0].id : null;
    const pay = await hmConsumeInventory("roses", POST_COST, { reason: "mood_post" });
    if (!pay || pay.ok === false) {
      if (postId) {
        try { await cli.from("posts").delete().eq("id", postId); } catch(e){}
      }
      alert((pay && pay.reason) ? pay.reason : "扣除玫瑰失敗");
      return;
    }

    contentEl.value = "";
    moodSelectedImages = [];
    renderMoodImagePreview();
    if (allowEl) allowEl.checked = true;
    const anonRadio = document.querySelector('input[name="moodIdentity"][value="anon"]');
    if (anonRadio) anonRadio.checked = true;

    try { await hmBackendGetInventory({ force: true }); } catch (e) {}
    try { await hmSyncInventoryCache(); } catch (e) {}
    try { await hmUpdateMoodRoseUI(); } catch (e) {}
    try { await hmGiftRenderInventory(); } catch (e) {}
    try { await hmRewardRenderUI({ force: true }); } catch (e) {}
    await hmRefreshMoodFromSupabase();
  };

  window.hmMoodInsertReply = async function(postId, text, isAnon){
    const { ok, cli, uid } = await hmMoodGetClientAndUid();
    if (!ok) { alert("請先登入 Email，才能回覆"); return { ok: false }; }

    const pid = String(postId || "");
    if (!pid) { alert("回覆失敗：post_id 不正確"); return { ok: false }; }

    const body = String(text || "").trim();
    if (!body) return { ok: false };

    const posts = (typeof hmLoadMoodPosts === "function") ? hmLoadMoodPosts() : [];
    const targetPost = posts.find(p => String(p.id) === pid) || null;
    if (!targetPost) { alert("回覆失敗：找不到原貼文"); return { ok: false }; }
    if (targetPost.allow_replies === false) { alert("這則貼文已關閉回覆"); return { ok: false }; }

    const isReplyOwnPost = String(targetPost.user_id || "") === String(uid || "");

    const latestReplyTs = await getLatestReplyTime(cli, uid);
    const remainMs = latestReplyTs ? (REPLY_COOLDOWN_MS - (Date.now() - latestReplyTs)) : 0;
    if (remainMs > 0) {
      const sec = Math.ceil(remainMs / 1000);
      alert("回覆太快了，請 " + sec + " 秒後再試。");
      return { ok: false, reason: "cooldown" };
    }

    if (isReplyOwnPost) {
      const selfCount = await getSelfReplyCountForPost(cli, uid, pid);
      if (selfCount >= MAX_SELF_REPLIES_PER_POST) {
        alert("同一篇貼文最多只能自回 5 則。");
        return { ok: false, reason: "self_reply_limit" };
      }
    } else {
      await hmSyncInventoryCache();
      const roses = (typeof hmLoadMoodRoses === "function") ? hmLoadMoodRoses() : 0;
      if (roses < REPLY_OTHER_COST) {
        alert("🌹 玫瑰不足，回覆他人需要 1 朵玫瑰。");
        return { ok: false };
      }
    }

    let ins = await cli.from("post_replies").insert({
      post_id: pid,
      user_id: uid,
      body: body,
      is_anonymous: !!isAnon
    }).select("id,created_at").limit(1);

    if (ins.error && String(ins.error.message || "").toLowerCase().includes("relation") && String(ins.error.message || "").toLowerCase().includes("post_replies")) {
      alert("目前尚未建立 post_replies 資料表，請先在 Supabase SQL Editor 執行 schema 補齊 SQL。");
      return { ok: false, need_schema: true };
    }
    if (ins.error && String(ins.error.message || "").toLowerCase().includes("is_anonymous")) {
      ins = await cli.from("post_replies").insert({
        post_id: pid,
        user_id: uid,
        body: body
      }).select("id,created_at").limit(1);
    }
    if (ins.error) {
      alert("回覆失敗：" + (ins.error.message || "unknown"));
      return { ok: false };
    }

    const replyId = ins.data && ins.data[0] && ins.data[0].id ? ins.data[0].id : null;
    const createdAt = ins.data && ins.data[0] && ins.data[0].created_at ? Date.parse(ins.data[0].created_at) : Date.now();

    if (!isReplyOwnPost) {
      const pay = await hmConsumeInventory("roses", REPLY_OTHER_COST, { reason: "mood_reply" });
      if (!pay || pay.ok === false) {
        if (replyId) {
          try { await cli.from("post_replies").delete().eq("id", replyId); } catch(e){}
        }
        alert((pay && pay.reason) ? pay.reason : "扣除玫瑰失敗");
        return { ok: false };
      }
    }

    writeLocalReplyCooldown(uid, createdAt || Date.now());

    try { await hmBackendGetInventory({ force: true }); } catch (e) {}
    try { await hmSyncInventoryCache(); } catch (e) {}
    try { await hmUpdateMoodRoseUI(); } catch (e) {}
    try { await hmGiftRenderInventory(); } catch (e) {}
    try { await hmRewardRenderUI({ force: true }); } catch (e) {}
    return { ok: true };
  };

  window.hmRenderMoodList = function(){
    const listEl = document.getElementById("moodList");
    const emptyEl = document.getElementById("moodEmptyHint");
    if (!listEl) return;

    const posts = (typeof hmLoadMoodPosts === "function" ? hmLoadMoodPosts() : [])
      .slice()
      .sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));

    listEl.innerHTML = "";
    if (!posts.length) {
      if (emptyEl) { emptyEl.style.display = "block"; emptyEl.textContent = "目前沒有任何貼文"; }
      return;
    }
    if (emptyEl) emptyEl.style.display = "none";

    posts.forEach(post => {
      const card = document.createElement("div");
      card.className = "card mood-item-card";

      const header = document.createElement("div");
      header.className = "mood-item-header";
      const leftWrap = document.createElement("div");
      leftWrap.className = "mood-item-author-wrap";

      const avatarDiv = document.createElement("div");
      avatarDiv.className = "mood-item-avatar";
      const a = hmMoodGetAuthor(post.user_id);
      if (post.is_anonymous) avatarDiv.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#9ca3af;">?</div>';
      else avatarDiv.innerHTML = '<img src="' + ((a && a.avatar) ? a.avatar : "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E") + '" alt="avatar">';

      const authorDiv = document.createElement("div");
      authorDiv.className = "mood-item-author";
      const nameDiv = document.createElement("div");
      nameDiv.className = "mood-item-author-name";
      nameDiv.textContent = post.is_anonymous ? "匿名" : ((a && a.name) ? a.name : "未設定");
      const metaDiv = document.createElement("div");
      metaDiv.className = "mood-item-meta";
      const t = new Date(post.createdAt || Date.now());
      const y = t.getFullYear(), m = String(t.getMonth()+1).padStart(2,"0"), d = String(t.getDate()).padStart(2,"0"), hh = String(t.getHours()).padStart(2,"0"), mm = String(t.getMinutes()).padStart(2,"0");
      metaDiv.textContent = y + "-" + m + "-" + d + " " + hh + ":" + mm;
      authorDiv.appendChild(nameDiv); authorDiv.appendChild(metaDiv);
      leftWrap.appendChild(avatarDiv); leftWrap.appendChild(authorDiv);

      const badge = document.createElement("div");
      badge.className = "mood-item-badge";
      badge.textContent = post.allow_replies ? "可回覆" : "不開放回覆";

      header.appendChild(leftWrap);
      header.appendChild(badge);

      const body = document.createElement("div");
      body.className = "mood-item-content";
      body.textContent = post.content || "";

      card.appendChild(header);
      card.appendChild(body);

      const images = Array.isArray(post.image_urls) ? post.image_urls : parsePostImages(post);
      if (images.length) {
        const grid = document.createElement("div");
        grid.className = "mood-item-image-grid";
        images.slice(0,3).forEach(src => {
          const img = document.createElement("img");
          img.src = src;
          img.alt = "post-image";
          img.className = "mood-item-image";
          img.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            window.open(src, "_blank");
          });
          grid.appendChild(img);
        });
        card.appendChild(grid);
      }

      const actions = document.createElement("div");
      actions.className = "mood-item-actions";
      const replies = hmMoodRepliesCache.get(String(post.id)) || [];
      const replyCount = document.createElement("div");
      replyCount.className = "mood-item-reply-count";
      replyCount.textContent = (replies.length ? (replies.length + " 則回覆") : "尚無回覆");

      if (post.allow_replies) {
        const replyBtn = document.createElement("button");
        replyBtn.type = "button";
        replyBtn.className = "mood-item-reply-btn";
        replyBtn.textContent = "回覆";

        const toggleBtn = document.createElement("button");
        toggleBtn.type = "button";
        toggleBtn.className = "mood-item-reply-btn";
        toggleBtn.textContent = "查看";

        const repliesWrap = document.createElement("div");
        repliesWrap.className = "mood-replies";
        repliesWrap.style.display = "none";

        const list = document.createElement("div");
        list.className = "mood-replies-list";

        const form = document.createElement("div");
        form.className = "mood-reply-form";

        const rule = document.createElement("div");
        rule.className = "mood-reply-rule";

        const anonLabel = document.createElement("label");
        anonLabel.className = "mood-reply-anon";
        anonLabel.innerHTML = '<input type="checkbox" id="anonReply_' + post.id + '"> 匿名回覆';

        const input = document.createElement("textarea");
        input.className = "mood-reply-input";
        input.placeholder = "回覆他人消耗 1 朵玫瑰；回覆自己的帖子免費";

        const stickerRow = document.createElement("div");
        stickerRow.className = "mood-sticker-row";
        STICKERS.forEach(st => {
          const chip = document.createElement("button");
          chip.type = "button";
          chip.className = "mood-sticker-chip";
          chip.textContent = st;
          chip.addEventListener("click", () => {
            input.value = (input.value || "") + st;
            input.focus();
          });
          stickerRow.appendChild(chip);
        });

        const send = document.createElement("button");
        send.type = "button";
        send.className = "btn";
        send.style.padding = "8px 10px";
        send.textContent = "送出";

        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.className = "btn-outline";
        cancel.style.padding = "8px 10px";
        cancel.textContent = "收起";

        function renderRepliesList() {
          list.innerHTML = "";
          const arr = hmMoodRepliesCache.get(String(post.id)) || [];
          if (!arr.length) {
            list.innerHTML = '<div style="padding:8px;color:#6b7280;font-size:12px;">尚無回覆</div>';
            return;
          }
          arr.forEach(r => {
            const item = document.createElement("div");
            item.className = "mood-reply-item";
            const a = hmMoodGetAuthor(r.user_id);
            const av = document.createElement("div");
            av.className = "mood-reply-avatar";
            if (r.is_anonymous) av.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#9ca3af;">?</div>';
            else av.innerHTML = '<img src="' + ((a && a.avatar) ? a.avatar : "data:image/svg+xml;charset=UTF-8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%22200%22%20height%3D%22200%22%20viewBox%3D%220%200%20200%20200%22%3E%0A%3Cdefs%3E%3ClinearGradient%20id%3D%22g%22%20x1%3D%220%22%20x2%3D%221%22%20y1%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fdf2f8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%23ede9fe%22/%3E%3C/linearGradient%3E%3C/defs%3E%0A%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22url%28%23g%29%22/%3E%0A%3Ccircle%20cx%3D%22100%22%20cy%3D%2276%22%20r%3D%2228%22%20fill%3D%22%23d8b4fe%22/%3E%0A%3Crect%20x%3D%2244%22%20y%3D%22116%22%20width%3D%22112%22%20height%3D%2232%22%20rx%3D%2210%22%20fill%3D%22%23c4b5fd%22/%3E%0A%3Ctext%20x%3D%2250%25%22%20y%3D%2290%25%22%20text-anchor%3D%22middle%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2216%22%20fill%3D%22%237c3aed%22%3ELinko%20200%C3%97200%3C/text%3E%0A%3C/svg%3E") + '" alt="avatar">';
            const main = document.createElement("div");
            main.className = "mood-reply-main";
            const top = document.createElement("div");
            top.className = "mood-reply-top";
            const name = document.createElement("div");
            name.className = "mood-reply-name";
            name.textContent = r.is_anonymous ? "匿名" : ((a && a.name) ? a.name : "未設定");
            const time = document.createElement("div");
            time.className = "mood-reply-time";
            const rt = new Date(r.createdAt || Date.now());
            time.textContent = String(rt.getMonth()+1).padStart(2,"0") + "/" + String(rt.getDate()).padStart(2,"0") + " " + String(rt.getHours()).padStart(2,"0") + ":" + String(rt.getMinutes()).padStart(2,"0");
            const body = document.createElement("div");
            body.className = "mood-reply-body";
            body.textContent = r.body || "";
            top.appendChild(name);
            top.appendChild(time);
            main.appendChild(top);
            main.appendChild(body);
            item.appendChild(av);
            item.appendChild(main);
            list.appendChild(item);
          });
        }

        async function updateReplyRule(){
          const currentUid = String(window.hmCurrentUserIdForMood || "");
          const isOwn = String(post.user_id) === currentUid;
          if (!isOwn) {
            rule.textContent = "回覆他人消耗 🌹 1 朵，且需間隔 30 秒。";
            return;
          }
          let remaining = MAX_SELF_REPLIES_PER_POST;
          try {
            const ctx = await hmMoodGetClientAndUid();
            if (ctx && ctx.ok) {
              const count = await getSelfReplyCountForPost(ctx.cli, ctx.uid, String(post.id));
              remaining = Math.max(0, MAX_SELF_REPLIES_PER_POST - count);
            }
          } catch(e){}
          rule.textContent = "回覆自己的帖子免費，不會頂帖；每篇最多自回 5 則（剩餘 " + remaining + " 則）。";
        }

        replyBtn.addEventListener("click", async () => {
          repliesWrap.style.display = "block";
          renderRepliesList();
          await updateReplyRule();
          input.focus();
        });

        toggleBtn.addEventListener("click", async () => {
          const show = repliesWrap.style.display !== "none";
          repliesWrap.style.display = show ? "none" : "block";
          if (!show) {
            renderRepliesList();
            await updateReplyRule();
          }
        });

        cancel.addEventListener("click", () => { repliesWrap.style.display = "none"; });

        send.addEventListener("click", async () => {
          const body = String(input.value || "").trim();
          if (!body) return;
          send.disabled = true;
          const anon = !!document.getElementById("anonReply_" + post.id)?.checked;
          const res = await hmMoodInsertReply(post.id, body, anon);
          send.disabled = false;
          if (res && res.ok) {
            input.value = "";
            await hmRefreshMoodFromSupabase();
            repliesWrap.style.display = "block";
            renderRepliesList();
            await updateReplyRule();
          }
        });

        renderRepliesList();
        form.appendChild(rule);
        form.appendChild(anonLabel);
        form.appendChild(input);
        form.appendChild(stickerRow);

        const btnRow = document.createElement("div");
        btnRow.className = "mood-reply-btnrow";
        btnRow.appendChild(send);
        btnRow.appendChild(cancel);

        form.appendChild(btnRow);
        repliesWrap.appendChild(list);
        repliesWrap.appendChild(form);
        actions.appendChild(replyBtn);
        actions.appendChild(toggleBtn);
        actions.appendChild(replyCount);
        card.appendChild(actions);
        card.appendChild(repliesWrap);
      } else {
        actions.appendChild(replyCount);
        card.appendChild(actions);
      }

      listEl.appendChild(card);
    });
  };

  const oldGetClient = window.hmMoodGetClientAndUid;
  window.hmMoodGetClientAndUid = async function(){
    const res = await oldGetClient();
    try { window.hmCurrentUserIdForMood = res && res.uid ? String(res.uid) : ""; } catch(e){}
    return res;
  };

  function rebindMoodRules(){
    const rulesBtn = document.getElementById("btnMoodRules");
    if (rulesBtn && !rulesBtn.dataset.replaced) {
      const newBtn = rulesBtn.cloneNode(true);
      newBtn.dataset.replaced = "1";
      newBtn.addEventListener("click", function(e){
        e.preventDefault();
        e.stopPropagation();
        alert(
          "心情廣場規則\n\n" +
          "• 發文：每則消耗 🌹 5 朵；每日最多 3 篇\n" +
          "• 發帖可附圖片：最多 3 張\n" +
          "• 回覆自己帖子：免費，但不頂帖\n" +
          "• 每篇最多自回：5 則\n" +
          "• 回覆他人帖子：每則消耗 🌹 1 朵\n" +
          "• 回覆冷卻：每次回覆需間隔 30 秒\n" +
          "• 回覆內容：僅限文字與簡單貼圖\n"
        );
      });
      rulesBtn.parentNode.replaceChild(newBtn, rulesBtn);
    }
  }

  function initPatch(){
    hmPatchDailyRewards();
    hmApplyMoodTexts();
    bindMoodImageInput();
    renderMoodImagePreview();
    rebindMoodRules();
    try { if (typeof hmUpdateMoodRoseUI === "function") hmUpdateMoodRoseUI(); } catch(e){}
    try { if (typeof hmRefreshMoodFromSupabase === "function") hmRefreshMoodFromSupabase(); } catch(e){}
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initPatch);
  else initPatch();
})();
