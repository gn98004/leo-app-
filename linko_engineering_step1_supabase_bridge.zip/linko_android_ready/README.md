# Linko Android-ready

這份是以你原始 `index.html` 為底整理出的 **功能保留版 + Android 可包裝結構**。

## 保留的重點功能
- 巧遇 / 人們頁
- 相簿與鎖圖解鎖
- VIP60 區塊
- 心情日記廣場
- 玫瑰 / 小禮物 / 送禮入口
- 好友限定小語 / 日記
- 聊天 / 排行榜 / 我的頁
- 封鎖 / 檢舉 / Daily reward / Supabase scaffold

## 這次補上的缺口
- 18+ 年齡確認
- 安全中心入口
- 服務條款 / 隱私政策 / 帳號刪除說明頁
- 更清楚的儲值 / VIP 入口
- PWA manifest / app icon
- Capacitor 結構，方便包 Android

## 本機預覽
直接開啟 `www/index.html` 即可。

## 包 Android
```bash
npm install
npx cap add android
npm run copy
npm run android
```

## 上架前仍要做
- Google Play Billing：VIP60 訂閱、玫瑰 / 禮物商品
- 正式 release keystore 與 AAB
- 正式隱私政策內容與客服聯絡方式
- 正式後端表與 RPC 驗證


## 新增：Billing / Supabase 規劃檔

這包已補上可直接交給工程師實作的規劃：

- `docs/google-play-billing-plan.md`
- `docs/supabase-plan.md`
- `docs/android-billing-supabase-integration.md`
- `supabase/migrations/20260421_linko_schema.sql`
- `www/docs/supabase-client-example.js`

### 建議實作順序
1. 先在 Google Play Console 建立商品
2. 在 Supabase 套用 migration
3. 前端把發文 / 回覆 / 送花 / 解鎖 / 購買改成呼叫 RPC
4. 再做 Google Play Developer API 驗證與 RTDN webhook


## 這次新增：Supabase 接線盤點與 Legacy Bridge

因為目前前端已經有部分 Supabase 串接，所以這次不是重寫，而是先把「前端現況」跟「schema 規劃」接起來。

### 新增檔案
- `docs/supabase-audit.md`
- `supabase/migrations/20260421_linko_legacy_bridge.sql`
- `www/assets/js/supabase-bridge.js`

### 先執行的 SQL
請依序在 Supabase SQL Editor 執行：
1. `supabase/migrations/20260421_linko_schema.sql`
2. `supabase/migrations/20260421_linko_legacy_bridge.sql`

### 這次補到的內容
- 補上前端目前真的在用的表：`profile_photos` / `posts` / `post_replies` / `inventories` / `reward_claims` / `monthly_bonuses`
- 補上前端目前真的在 call 的 RPC：
  - `claim_daily_reward`
  - `claim_login_gift`
  - `consume_item`
  - `create_post_with_limit`
  - `create_reply_with_limit`
  - `get_received_gift_stats`
  - `migrate_inventory`
  - `send_gift`
- 補上 `onAuthStateChange(...)` 自動刷新橋接腳本，讓 Android / iOS 包裝時登入狀態更穩
