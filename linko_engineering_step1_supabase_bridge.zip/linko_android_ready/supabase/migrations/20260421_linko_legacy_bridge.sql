
-- Linko legacy bridge migration
-- 目的：讓目前前端 index.html 使用的 legacy table / RPC 可以直接在 Supabase 跑起來
-- 執行順序：請先執行 20260421_linko_schema.sql，再執行本檔

create extension if not exists pgcrypto;

-- =========================
-- legacy tables
-- =========================

create table if not exists public.profile_photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  url text not null,
  is_avatar boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_profile_photos_user_id on public.profile_photos(user_id);
create index if not exists idx_profile_photos_user_avatar on public.profile_photos(user_id, is_avatar);

create table if not exists public.inventories (
  user_id uuid primary key references auth.users(id) on delete cascade,
  roses integer not null default 0 check (roses >= 0),
  gifts integer not null default 0 check (gifts >= 0),
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 500),
  image_url text not null default '',
  is_anonymous boolean not null default true,
  allow_replies boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_posts_user_id on public.posts(user_id);
create index if not exists idx_posts_created_at on public.posts(created_at desc);

create table if not exists public.post_replies (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  is_anonymous boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_post_replies_post_id on public.post_replies(post_id);
create index if not exists idx_post_replies_user_day on public.post_replies(user_id, created_at desc);

create table if not exists public.reward_claims (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  yyyymm text not null,
  day integer not null check (day between 1 and 31),
  reward_type text not null check (reward_type in ('rose', 'gift')),
  amount integer not null default 1 check (amount > 0),
  created_at timestamptz not null default now(),
  unique(user_id, yyyymm, day)
);

create index if not exists idx_reward_claims_user_ym on public.reward_claims(user_id, yyyymm);

create table if not exists public.monthly_bonuses (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  yyyymm text not null,
  bonus_type text not null default 'rose',
  amount integer not null default 5 check (amount > 0),
  created_at timestamptz not null default now(),
  unique(user_id, yyyymm)
);

create table if not exists public.login_gift_claims (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  ymd date not null,
  reward_type text not null default 'rose',
  amount integer not null default 1 check (amount > 0),
  created_at timestamptz not null default now(),
  unique(user_id, ymd)
);

create table if not exists public.gift_transactions (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references auth.users(id) on delete cascade,
  to_user uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('rose', 'gift')),
  qty integer not null check (qty > 0),
  reason text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists idx_gift_transactions_to_user on public.gift_transactions(to_user, created_at desc);
create index if not exists idx_gift_transactions_from_user on public.gift_transactions(from_user, created_at desc);

-- =========================
-- updated_at trigger helper
-- =========================
create or replace function public.tg_set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_inventories_updated_at on public.inventories;
create trigger trg_inventories_updated_at
before update on public.inventories
for each row execute function public.tg_set_updated_at();

-- =========================
-- RLS
-- =========================
alter table public.profile_photos enable row level security;
alter table public.inventories enable row level security;
alter table public.posts enable row level security;
alter table public.post_replies enable row level security;
alter table public.reward_claims enable row level security;
alter table public.monthly_bonuses enable row level security;
alter table public.login_gift_claims enable row level security;
alter table public.gift_transactions enable row level security;

-- profile_photos
drop policy if exists "profile_photos read auth users" on public.profile_photos;
create policy "profile_photos read auth users"
on public.profile_photos
for select
to authenticated
using (true);

drop policy if exists "profile_photos owner insert" on public.profile_photos;
create policy "profile_photos owner insert"
on public.profile_photos
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "profile_photos owner update" on public.profile_photos;
create policy "profile_photos owner update"
on public.profile_photos
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "profile_photos owner delete" on public.profile_photos;
create policy "profile_photos owner delete"
on public.profile_photos
for delete
to authenticated
using (auth.uid() = user_id);

-- inventories
drop policy if exists "inventories owner read" on public.inventories;
create policy "inventories owner read"
on public.inventories
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "inventories owner insert" on public.inventories;
create policy "inventories owner insert"
on public.inventories
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "inventories owner update" on public.inventories;
create policy "inventories owner update"
on public.inventories
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- posts
drop policy if exists "posts read auth users" on public.posts;
create policy "posts read auth users"
on public.posts
for select
to authenticated
using (true);

drop policy if exists "posts owner insert" on public.posts;
create policy "posts owner insert"
on public.posts
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "posts owner update" on public.posts;
create policy "posts owner update"
on public.posts
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "posts owner delete" on public.posts;
create policy "posts owner delete"
on public.posts
for delete
to authenticated
using (auth.uid() = user_id);

-- post_replies
drop policy if exists "post_replies read auth users" on public.post_replies;
create policy "post_replies read auth users"
on public.post_replies
for select
to authenticated
using (true);

drop policy if exists "post_replies owner insert" on public.post_replies;
create policy "post_replies owner insert"
on public.post_replies
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "post_replies owner update" on public.post_replies;
create policy "post_replies owner update"
on public.post_replies
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "post_replies owner delete" on public.post_replies;
create policy "post_replies owner delete"
on public.post_replies
for delete
to authenticated
using (auth.uid() = user_id);

-- reward / bonus / login claims / gift tx
drop policy if exists "reward_claims owner read" on public.reward_claims;
create policy "reward_claims owner read"
on public.reward_claims
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "monthly_bonuses owner read" on public.monthly_bonuses;
create policy "monthly_bonuses owner read"
on public.monthly_bonuses
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "login_gift_claims owner read" on public.login_gift_claims;
create policy "login_gift_claims owner read"
on public.login_gift_claims
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "gift_transactions received read" on public.gift_transactions;
create policy "gift_transactions received read"
on public.gift_transactions
for select
to authenticated
using (auth.uid() = from_user or auth.uid() = to_user);

-- =========================
-- helper functions
-- =========================
create or replace function public.ensure_inventory_row(p_uid uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.inventories(user_id, roses, gifts)
  values (p_uid, 0, 0)
  on conflict (user_id) do nothing;
end;
$$;

grant execute on function public.ensure_inventory_row(uuid) to authenticated;

create or replace function public.local_ymd_taipei(p_ts timestamptz default now())
returns text
language sql
immutable
as $$
  select to_char((p_ts at time zone 'Asia/Taipei')::date, 'YYYY-MM-DD');
$$;

create or replace function public.local_ym_taipei(p_ts timestamptz default now())
returns text
language sql
immutable
as $$
  select to_char((p_ts at time zone 'Asia/Taipei')::date, 'YYYYMM');
$$;

-- =========================
-- RPC: migrate inventory
-- =========================
create or replace function public.migrate_inventory(p_roses integer default 0, p_gifts integer default 0)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  perform public.ensure_inventory_row(v_uid);

  update public.inventories
     set roses = greatest(0, roses + greatest(coalesce(p_roses,0),0)),
         gifts = greatest(0, gifts + greatest(coalesce(p_gifts,0),0))
   where user_id = v_uid;

  return (
    select jsonb_build_object(
      'ok', true,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories
    where user_id = v_uid
  );
end;
$$;

grant execute on function public.migrate_inventory(integer, integer) to authenticated;

-- =========================
-- RPC: consume item
-- =========================
create or replace function public.consume_item(p_item text, p_qty integer default 1, p_reason text default '')
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_qty integer := greatest(coalesce(p_qty,1),1);
  v_row public.inventories%rowtype;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  perform public.ensure_inventory_row(v_uid);

  select * into v_row from public.inventories where user_id = v_uid for update;

  if lower(coalesce(p_item,'')) = 'rose' then
    if v_row.roses < v_qty then
      return jsonb_build_object('ok', false, 'reason', 'insufficient_roses', 'roses', v_row.roses, 'gifts', v_row.gifts);
    end if;
    update public.inventories set roses = roses - v_qty where user_id = v_uid;
  elsif lower(coalesce(p_item,'')) = 'gift' then
    if v_row.gifts < v_qty then
      return jsonb_build_object('ok', false, 'reason', 'insufficient_gifts', 'roses', v_row.roses, 'gifts', v_row.gifts);
    end if;
    update public.inventories set gifts = gifts - v_qty where user_id = v_uid;
  else
    return jsonb_build_object('ok', false, 'reason', 'invalid_item');
  end if;

  return (
    select jsonb_build_object('ok', true, 'roses', roses, 'gifts', gifts, 'reason', coalesce(p_reason,''))
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.consume_item(text, integer, text) to authenticated;

-- =========================
-- RPC: login gift
-- =========================
create or replace function public.claim_login_gift()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_today date := (now() at time zone 'Asia/Taipei')::date;
  v_inserted boolean := false;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  perform public.ensure_inventory_row(v_uid);

  begin
    insert into public.login_gift_claims(user_id, ymd, reward_type, amount)
    values (v_uid, v_today, 'rose', 1);
    v_inserted := true;
  exception when unique_violation then
    v_inserted := false;
  end;

  if v_inserted then
    update public.inventories set roses = roses + 1 where user_id = v_uid;
  end if;

  return (
    select jsonb_build_object(
      'ok', true,
      'claimed', v_inserted,
      'reward', 'rose',
      'reward_qty', case when v_inserted then 1 else 0 end,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.claim_login_gift() to authenticated;

-- =========================
-- RPC: daily reward
-- =========================
create or replace function public.claim_daily_reward(p_date text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_target_date date := coalesce(nullif(p_date,'')::date, (now() at time zone 'Asia/Taipei')::date);
  v_ym text := to_char(v_target_date, 'YYYYMM');
  v_day integer := extract(day from v_target_date);
  v_reward_type text := case when (v_day % 7 = 0) then 'gift' else 'rose' end;
  v_reward_qty integer := case when (v_day % 7 = 0) then 2 else 1 end;
  v_bonus_qty integer := 0;
  v_total_claims integer := 0;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  perform public.ensure_inventory_row(v_uid);

  begin
    insert into public.reward_claims(user_id, yyyymm, day, reward_type, amount)
    values (v_uid, v_ym, v_day, v_reward_type, v_reward_qty);
  exception when unique_violation then
    return jsonb_build_object('ok', false, 'reason', 'already_claimed');
  end;

  if v_reward_type = 'gift' then
    update public.inventories set gifts = gifts + v_reward_qty where user_id = v_uid;
  else
    update public.inventories set roses = roses + v_reward_qty where user_id = v_uid;
  end if;

  select count(*) into v_total_claims
  from public.reward_claims
  where user_id = v_uid and yyyymm = v_ym;

  if v_total_claims >= 28 then
    begin
      insert into public.monthly_bonuses(user_id, yyyymm, bonus_type, amount)
      values (v_uid, v_ym, 'rose', 5);
      v_bonus_qty := 5;
      update public.inventories set roses = roses + v_bonus_qty where user_id = v_uid;
    exception when unique_violation then
      v_bonus_qty := 0;
    end;
  end if;

  return (
    select jsonb_build_object(
      'ok', true,
      'reward', v_reward_type,
      'reward_qty', v_reward_qty,
      'monthly_bonus', v_bonus_qty,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.claim_daily_reward(text) to authenticated;

-- =========================
-- RPC: create post with limit
-- =========================
create or replace function public.create_post_with_limit(
  p_content text,
  p_is_anonymous boolean default true,
  p_allow_replies boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_today_start timestamptz := date_trunc('day', now() at time zone 'Asia/Taipei') at time zone 'Asia/Taipei';
  v_today_end timestamptz := v_today_start + interval '1 day';
  v_count integer := 0;
  v_post_id uuid;
  v_inv public.inventories%rowtype;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  if char_length(trim(coalesce(p_content,''))) = 0 then
    return jsonb_build_object('ok', false, 'reason', 'empty_content');
  end if;

  perform public.ensure_inventory_row(v_uid);

  select count(*) into v_count
  from public.posts
  where user_id = v_uid
    and created_at >= v_today_start
    and created_at < v_today_end;

  if v_count >= 3 then
    return jsonb_build_object('ok', false, 'reason', 'daily_post_limit');
  end if;

  select * into v_inv from public.inventories where user_id = v_uid for update;
  if coalesce(v_inv.roses,0) < 1 then
    return jsonb_build_object('ok', false, 'reason', 'insufficient_roses', 'roses', v_inv.roses, 'gifts', v_inv.gifts);
  end if;

  update public.inventories set roses = roses - 1 where user_id = v_uid;

  insert into public.posts(user_id, content, image_url, is_anonymous, allow_replies)
  values (v_uid, trim(p_content), '', coalesce(p_is_anonymous, true), coalesce(p_allow_replies, true))
  returning id into v_post_id;

  return (
    select jsonb_build_object(
      'ok', true,
      'post_id', v_post_id,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.create_post_with_limit(text, boolean, boolean) to authenticated;

-- =========================
-- RPC: create reply with limit
-- =========================
create or replace function public.create_reply_with_limit(
  p_post_id uuid,
  p_body text,
  p_is_anonymous boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_today_start timestamptz := date_trunc('day', now() at time zone 'Asia/Taipei') at time zone 'Asia/Taipei';
  v_today_end timestamptz := v_today_start + interval '1 day';
  v_count integer := 0;
  v_reply_id uuid;
  v_post public.posts%rowtype;
  v_inv public.inventories%rowtype;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  if char_length(trim(coalesce(p_body,''))) = 0 then
    return jsonb_build_object('ok', false, 'reason', 'empty_body');
  end if;

  select * into v_post from public.posts where id = p_post_id;
  if v_post.id is null then
    return jsonb_build_object('ok', false, 'reason', 'post_not_found');
  end if;

  if not coalesce(v_post.allow_replies, true) then
    return jsonb_build_object('ok', false, 'reason', 'replies_not_allowed');
  end if;

  perform public.ensure_inventory_row(v_uid);

  select count(*) into v_count
  from public.post_replies
  where user_id = v_uid
    and created_at >= v_today_start
    and created_at < v_today_end;

  if v_count >= 3 then
    select * into v_inv from public.inventories where user_id = v_uid for update;
    if coalesce(v_inv.gifts,0) < 1 then
      return jsonb_build_object('ok', false, 'reason', 'insufficient_gifts', 'roses', v_inv.roses, 'gifts', v_inv.gifts);
    end if;
    update public.inventories set gifts = gifts - 1 where user_id = v_uid;
  end if;

  insert into public.post_replies(post_id, user_id, body, is_anonymous)
  values (p_post_id, v_uid, trim(p_body), coalesce(p_is_anonymous, true))
  returning id into v_reply_id;

  return (
    select jsonb_build_object(
      'ok', true,
      'reply_id', v_reply_id,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.create_reply_with_limit(uuid, text, boolean) to authenticated;

-- =========================
-- RPC: send gift
-- =========================
create or replace function public.send_gift(
  p_to uuid,
  p_kind text,
  p_qty integer default 1,
  p_reason text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_kind text := lower(coalesce(p_kind,''));
  v_qty integer := greatest(coalesce(p_qty,1),1);
  v_inv public.inventories%rowtype;
  v_tx_id uuid;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'reason', 'not_authenticated');
  end if;

  if p_to is null or p_to = v_uid then
    return jsonb_build_object('ok', false, 'reason', 'invalid_target');
  end if;

  if not exists(select 1 from public.profiles where id = p_to) then
    return jsonb_build_object('ok', false, 'reason', 'target_not_found');
  end if;

  perform public.ensure_inventory_row(v_uid);
  select * into v_inv from public.inventories where user_id = v_uid for update;

  if v_kind = 'roses' or v_kind = 'rose' then
    if coalesce(v_inv.roses,0) < v_qty then
      return jsonb_build_object('ok', false, 'reason', 'insufficient_roses', 'roses', v_inv.roses, 'gifts', v_inv.gifts);
    end if;
    update public.inventories set roses = roses - v_qty where user_id = v_uid;
    v_kind := 'rose';
  elsif v_kind = 'gifts' or v_kind = 'gift' then
    if coalesce(v_inv.gifts,0) < v_qty then
      return jsonb_build_object('ok', false, 'reason', 'insufficient_gifts', 'roses', v_inv.roses, 'gifts', v_inv.gifts);
    end if;
    update public.inventories set gifts = gifts - v_qty where user_id = v_uid;
    v_kind := 'gift';
  else
    return jsonb_build_object('ok', false, 'reason', 'invalid_kind');
  end if;

  insert into public.gift_transactions(from_user, to_user, kind, qty, reason)
  values (v_uid, p_to, v_kind, v_qty, coalesce(p_reason,''))
  returning id into v_tx_id;

  return (
    select jsonb_build_object(
      'ok', true,
      'tx', v_tx_id,
      'kind', v_kind,
      'qty', v_qty,
      'roses', roses,
      'gifts', gifts
    )
    from public.inventories where user_id = v_uid
  );
end;
$$;

grant execute on function public.send_gift(uuid, text, integer, text) to authenticated;

-- =========================
-- RPC: received gift stats
-- =========================
create or replace function public.get_received_gift_stats(p_user uuid)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'roses', coalesce(sum(case when kind = 'rose' then qty else 0 end), 0),
    'gifts', coalesce(sum(case when kind = 'gift' then qty else 0 end), 0)
  )
  from public.gift_transactions
  where to_user = p_user;
$$;

grant execute on function public.get_received_gift_stats(uuid) to authenticated;
