
(function () {
  var bound = false;
  var tries = 0;

  async function refreshAll(reason, session) {
    try {
      if (typeof hmRefreshAuthStatusUI === "function") await hmRefreshAuthStatusUI();
    } catch (e) {}
    try {
      if (typeof hmRefreshFriendsFromSupabase === "function") await hmRefreshFriendsFromSupabase();
    } catch (e) {}
    try {
      if (typeof hmRefreshMoodFromSupabase === "function") await hmRefreshMoodFromSupabase();
    } catch (e) {}
    try {
      if (typeof hmBackendGetInventory === "function") await hmBackendGetInventory({ force: true });
    } catch (e) {}
    try {
      if (typeof hmGiftRenderInventory === "function") await hmGiftRenderInventory();
    } catch (e) {}
    try {
      if (typeof hmUpdateMoodRoseUI === "function") await hmUpdateMoodRoseUI();
    } catch (e) {}
    try {
      if (typeof hmRewardRenderUI === "function") await hmRewardRenderUI({ force: true });
    } catch (e) {}
    try {
      if (session && session.user && typeof hmLoadPeopleFromSupabase === "function") {
        await hmLoadPeopleFromSupabase({ force: true });
      }
    } catch (e) {}
    try {
      console.info("[Linko] auth refresh complete:", reason || "unknown");
    } catch (e) {}
  }

  async function bindAuthListener() {
    try {
      if (bound) return;
      if (typeof hmGetSupabaseClient !== "function") return;
      var cli = await hmGetSupabaseClient();
      if (!cli || !cli.auth || typeof cli.auth.onAuthStateChange !== "function") return;

      cli.auth.onAuthStateChange(async function (event, session) {
        try {
          await refreshAll(event || "auth_state_change", session || null);
        } catch (e) {
          console.warn("[Linko] auth state refresh failed:", e);
        }
      });

      bound = true;
      try {
        var sess = await cli.auth.getSession();
        var session = sess && sess.data ? sess.data.session : null;
        await refreshAll("initial_session_sync", session || null);
      } catch (e) {}
    } catch (e) {
      console.warn("[Linko] bindAuthListener failed:", e);
    }
  }

  function bootstrap() {
    tries += 1;
    bindAuthListener();
    if (!bound && tries < 40) {
      setTimeout(bootstrap, 500);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrap);
  } else {
    bootstrap();
  }
})();
