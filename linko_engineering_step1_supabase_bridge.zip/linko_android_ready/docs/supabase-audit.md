# Linko Supabase 接線盤點（2026-04-21）

這份盤點是根據目前前端 `www/index.html` 與 `supabase/migrations/20260421_linko_schema.sql` 交叉比對整理。

## 已經接上的部分

### 1. Supabase Client / Auth
- 已有 `createClient(...)`
- 已有 Email/Password `signInWithPassword` / `signUp` / `signOut`
- Session 有使用 `auth.getSession()`
- 前端會依登入狀態切換部分 UI

### 2. 已直接讀寫的資料
前端目前已直接使用這些表：
- `profiles`
- `diaries`
- `friend_requests`
- `blocks`
- `reports`

### 3. 已有 RPC 呼叫的商業邏輯入口
前端目前期待這些 RPC 存在：
- `claim_daily_reward`
- `claim_login_gift`
- `consume_item`
- `create_post_with_limit`
- `create_reply_with_limit`
- `get_received_gift_stats`
- `migrate_inventory`
- `send_gift`

## 半接好的部分

### 1. 心情廣場 / 回覆 / 道具
前端已經有完整 UI 與 RPC fallback，但實際依賴的 legacy table / RPC 與目前 schema 不完全一致：
- `posts`
- `post_replies`
- `inventories`
- `reward_claims`
- `monthly_bonuses`

### 2. 相簿
前端目前使用 `profile_photos`
但先前規劃 schema 用的是 `photos` / `photo_unlocks`。
這代表前端與 schema 命名還沒統一。

## 還缺的關鍵

### 1. Auth 狀態生命週期
目前前端有 `getSession()`，但沒有完整 `onAuthStateChange(...)` 訂閱。
這會造成：
- 登入後部分頁面不一定即時刷新
- 登出後 cache / UI 可能殘留
- 之後 Android / iOS 包裝時，恢復 session 的體驗不夠穩

### 2. 前端使用的 legacy schema 沒有正式 migration
這會造成：
- SQL 已建立但畫面跑不起來
- 或前端有 RPC，後端沒有對應 function

## 這次補上的內容

這次新增了兩塊：

1. `supabase/migrations/20260421_linko_legacy_bridge.sql`
   - 建立前端目前真的在用的 legacy table / RPC
   - 讓現有 UI 可以先跑起來
   - 避免一次重寫整份 index.html

2. `www/assets/js/supabase-bridge.js`
   - 自動監聽 `onAuthStateChange(...)`
   - 登入 / 登出時刷新好友、心情、道具庫存、簽到 UI
   - 讓 Android / iOS 包裝時 session 恢復更穩

## 建議執行順序

1. 先在 Supabase SQL Editor 執行：
   - `20260421_linko_schema.sql`
   - `20260421_linko_legacy_bridge.sql`

2. 再把前端跑起來測：
   - Email 註冊 / 登入
   - 每日簽到
   - 發心情
   - 回覆
   - 送禮
   - 相簿頭像 / 日記

3. 穩定後再進下一步：
   - Google Play Billing 驗單
   - Storage private bucket / signed URL
   - 真正 Android AAB 流程
