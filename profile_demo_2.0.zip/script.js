
/* Full JS content from Part 3 */
