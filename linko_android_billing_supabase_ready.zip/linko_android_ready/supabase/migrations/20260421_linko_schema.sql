
-- Linko / Supabase starter schema
-- v1 billing + wallet + mood + album + social + chat
create extension if not exists pgcrypto;

-- ============ Profiles ============
create table if not exists public.profiles (
  id uuid primary key,
  display_name text not null default '新朋友',
  birth_date date,
  age_verified boolean not null default false,
  region text,
  height_cm int,
  weight_kg int,
  bio text,
  avatar_url text,
  is_vip boolean not null default false,
  vip_expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_settings (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  allow_stranger_chat boolean not null default true,
  allow_mood_replies boolean not null default true,
  show_region boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.social_links (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null,
  handle text,
  url text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now()
);

-- ============ Wallet ============
create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  rose_balance int not null default 0 check (rose_balance >= 0),
  gift_coin_balance int not null default 0 check (gift_coin_balance >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  currency_type text not null check (currency_type in ('rose','gift_coin')),
  delta int not null,
  balance_after int not null,
  reason text not null,
  ref_table text,
  ref_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_wallet_ledger_user_created on public.wallet_ledger(user_id, created_at desc);

-- ============ Photos ============
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null,
  sort_order int not null default 1,
  is_public_preview boolean not null default false,
  requires_vip boolean not null default false,
  requires_ad_unlock boolean not null default false,
  is_cover boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_photos_user_sort on public.photos(user_id, sort_order);

create table if not exists public.photo_unlocks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  unlock_type text not null check (unlock_type in ('ad','vip','gift')),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_photo_unlocks_user_photo on public.photo_unlocks(user_id, photo_id);

-- ============ Diary / Mood ============
create table if not exists public.diaries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  visibility text not null default 'friends' check (visibility in ('private','friends','public')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.mood_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  identity_mode text not null default 'anon' check (identity_mode in ('anon','public')),
  content text not null,
  allow_replies boolean not null default true,
  rose_cost int not null default 1,
  gift_count int not null default 0,
  reply_count int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists idx_mood_posts_created on public.mood_posts(created_at desc);

create table if not exists public.mood_replies (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.mood_posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  identity_mode text not null default 'anon' check (identity_mode in ('anon','public')),
  content text not null,
  gift_coin_cost int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.mood_gifts (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.mood_posts(id) on delete cascade,
  from_user_id uuid not null references public.profiles(id) on delete cascade,
  to_user_id uuid not null references public.profiles(id) on delete cascade,
  gift_type text not null check (gift_type in ('rose','gift_coin')),
  amount int not null check (amount > 0),
  created_at timestamptz not null default now()
);

-- ============ Social / Safety ============
create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  from_user_id uuid not null references public.profiles(id) on delete cascade,
  to_user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(from_user_id, to_user_id)
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_a, user_b)
);

create table if not exists public.blocks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid not null references public.profiles(id) on delete cascade,
  reason text,
  created_at timestamptz not null default now(),
  unique(user_id, target_user_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid references public.profiles(id) on delete set null,
  target_type text not null,
  target_id uuid,
  reason text not null,
  detail text,
  status text not null default 'open' check (status in ('open','reviewing','closed','rejected')),
  created_at timestamptz not null default now()
);

-- ============ Chat ============
create table if not exists public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  thread_type text not null default 'direct' check (thread_type in ('direct','system')),
  created_at timestamptz not null default now()
);

create table if not exists public.chat_members (
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key(thread_id, user_id)
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  sender_user_id uuid not null references public.profiles(id) on delete cascade,
  message_type text not null default 'text' check (message_type in ('text','image','gif','system')),
  content text,
  media_url text,
  created_at timestamptz not null default now()
);
create index if not exists idx_chat_messages_thread_created on public.chat_messages(thread_id, created_at desc);

-- ============ Billing / Entitlements ============
create table if not exists public.billing_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null check (platform in ('google_play')),
  product_id text not null,
  product_type text not null check (product_type in ('subscription','one_time')),
  purchase_token text not null,
  order_id text,
  purchase_state text not null default 'purchased',
  acknowledged boolean not null default false,
  quantity int not null default 1 check (quantity > 0),
  raw_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(platform, purchase_token)
);

create table if not exists public.vip_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null check (platform in ('google_play')),
  product_id text not null,
  base_plan_id text,
  purchase_token text not null,
  order_id text,
  status text not null check (status in ('active','expired','cancelled','revoked','paused')),
  started_at timestamptz not null default now(),
  expires_at timestamptz,
  auto_renewing boolean not null default true,
  raw_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(platform, purchase_token)
);

create table if not exists public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  entitlement_code text not null,
  source_type text not null,
  source_id uuid,
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  status text not null default 'active' check (status in ('active','expired','revoked')),
  created_at timestamptz not null default now()
);

-- ============ Helper functions ============
create or replace function public.ensure_wallet(p_user_id uuid)
returns void
language plpgsql
security definer
as $$
begin
  insert into public.wallets(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;
end;
$$;

create or replace function public.add_wallet_balance(
  p_user_id uuid,
  p_currency_type text,
  p_delta int,
  p_reason text,
  p_ref_table text default null,
  p_ref_id uuid default null,
  p_metadata jsonb default '{}'::jsonb
)
returns public.wallets
language plpgsql
security definer
as $$
declare
  v_wallet public.wallets;
  v_balance_after int;
begin
  perform public.ensure_wallet(p_user_id);

  if p_currency_type = 'rose' then
    update public.wallets
    set rose_balance = rose_balance + p_delta,
        updated_at = now()
    where user_id = p_user_id
    returning * into v_wallet;

    if v_wallet.rose_balance < 0 then
      raise exception 'rose balance insufficient';
    end if;

    v_balance_after := v_wallet.rose_balance;
  elsif p_currency_type = 'gift_coin' then
    update public.wallets
    set gift_coin_balance = gift_coin_balance + p_delta,
        updated_at = now()
    where user_id = p_user_id
    returning * into v_wallet;

    if v_wallet.gift_coin_balance < 0 then
      raise exception 'gift coin balance insufficient';
    end if;

    v_balance_after := v_wallet.gift_coin_balance;
  else
    raise exception 'unsupported currency type';
  end if;

  insert into public.wallet_ledger(
    user_id, currency_type, delta, balance_after, reason, ref_table, ref_id, metadata
  ) values (
    p_user_id, p_currency_type, p_delta, v_balance_after, p_reason, p_ref_table, p_ref_id, p_metadata
  );

  return v_wallet;
end;
$$;

create or replace function public.rpc_create_mood_post(
  p_content text,
  p_allow_replies boolean default true,
  p_identity_mode text default 'anon'
)
returns public.mood_posts
language plpgsql
security definer
as $$
declare
  v_user_id uuid := auth.uid();
  v_today_count int;
  v_post public.mood_posts;
begin
  if v_user_id is null then
    raise exception 'not authenticated';
  end if;

  select count(*) into v_today_count
  from public.mood_posts
  where user_id = v_user_id
    and created_at >= date_trunc('day', now());

  if v_today_count >= 3 then
    raise exception 'daily mood post limit reached';
  end if;

  perform public.add_wallet_balance(
    v_user_id, 'rose', -1, 'mood_post_cost', 'mood_posts', null, '{}'::jsonb
  );

  insert into public.mood_posts(user_id, identity_mode, content, allow_replies, rose_cost)
  values (v_user_id, p_identity_mode, p_content, p_allow_replies, 1)
  returning * into v_post;

  return v_post;
end;
$$;

create or replace function public.rpc_create_mood_reply(
  p_post_id uuid,
  p_content text,
  p_identity_mode text default 'anon'
)
returns public.mood_replies
language plpgsql
security definer
as $$
declare
  v_user_id uuid := auth.uid();
  v_post public.mood_posts;
  v_today_count int;
  v_cost int := 0;
  v_reply public.mood_replies;
begin
  if v_user_id is null then
    raise exception 'not authenticated';
  end if;

  select * into v_post from public.mood_posts where id = p_post_id;
  if not found then
    raise exception 'post not found';
  end if;

  if not v_post.allow_replies then
    raise exception 'replies disabled';
  end if;

  select count(*) into v_today_count
  from public.mood_replies
  where user_id = v_user_id
    and created_at >= date_trunc('day', now());

  if v_today_count >= 3 then
    v_cost := 1;
    perform public.add_wallet_balance(
      v_user_id, 'gift_coin', -1, 'mood_reply_cost', 'mood_posts', p_post_id, '{}'::jsonb
    );
  end if;

  insert into public.mood_replies(post_id, user_id, identity_mode, content, gift_coin_cost)
  values (p_post_id, v_user_id, p_identity_mode, p_content, v_cost)
  returning * into v_reply;

  update public.mood_posts
  set reply_count = reply_count + 1
  where id = p_post_id;

  return v_reply;
end;
$$;

create or replace function public.rpc_send_mood_gift(
  p_post_id uuid,
  p_gift_type text,
  p_amount int default 1
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_user_id uuid := auth.uid();
  v_post public.mood_posts;
begin
  if v_user_id is null then
    raise exception 'not authenticated';
  end if;

  select * into v_post from public.mood_posts where id = p_post_id;
  if not found then
    raise exception 'post not found';
  end if;

  if p_amount <= 0 then
    raise exception 'invalid amount';
  end if;

  perform public.add_wallet_balance(
    v_user_id, p_gift_type, -p_amount, 'send_mood_gift', 'mood_posts', p_post_id, '{}'::jsonb
  );

  insert into public.mood_gifts(post_id, from_user_id, to_user_id, gift_type, amount)
  values (p_post_id, v_user_id, v_post.user_id, p_gift_type, p_amount);

  update public.mood_posts
  set gift_count = gift_count + p_amount
  where id = p_post_id;

  return jsonb_build_object('success', true);
end;
$$;

create or replace function public.rpc_unlock_photo(
  p_photo_id uuid,
  p_unlock_type text
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_user_id uuid := auth.uid();
  v_photo public.photos;
  v_profile public.profiles;
  v_expires timestamptz;
begin
  if v_user_id is null then
    raise exception 'not authenticated';
  end if;

  select * into v_photo from public.photos where id = p_photo_id;
  if not found then
    raise exception 'photo not found';
  end if;

  select * into v_profile from public.profiles where id = v_user_id;

  if v_profile.is_vip and v_profile.vip_expires_at > now() then
    insert into public.photo_unlocks(user_id, photo_id, unlock_type, expires_at)
    values (v_user_id, p_photo_id, 'vip', null);
    return jsonb_build_object('success', true, 'unlock_type', 'vip');
  end if;

  if p_unlock_type = 'ad' then
    v_expires := now() + interval '20 minutes';
    insert into public.photo_unlocks(user_id, photo_id, unlock_type, expires_at)
    values (v_user_id, p_photo_id, 'ad', v_expires);
    return jsonb_build_object('success', true, 'unlock_type', 'ad', 'expires_at', v_expires);
  elsif p_unlock_type = 'gift' then
    perform public.add_wallet_balance(
      v_user_id, 'gift_coin', -1, 'photo_unlock_cost', 'photos', p_photo_id, '{}'::jsonb
    );
    v_expires := now() + interval '20 minutes';
    insert into public.photo_unlocks(user_id, photo_id, unlock_type, expires_at)
    values (v_user_id, p_photo_id, 'gift', v_expires);
    return jsonb_build_object('success', true, 'unlock_type', 'gift', 'expires_at', v_expires);
  else
    raise exception 'unsupported unlock type';
  end if;
end;
$$;

create or replace function public.rpc_apply_google_purchase(
  p_platform text,
  p_product_id text,
  p_purchase_token text,
  p_order_id text,
  p_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_user_id uuid := auth.uid();
  v_order_id uuid;
  v_wallet public.wallets;
begin
  if v_user_id is null then
    raise exception 'not authenticated';
  end if;

  if exists(
    select 1 from public.billing_orders
    where platform = p_platform and purchase_token = p_purchase_token
  ) then
    return jsonb_build_object('success', true, 'duplicate', true);
  end if;

  insert into public.billing_orders(
    user_id, platform, product_id, product_type, purchase_token, order_id, raw_payload
  ) values (
    v_user_id,
    p_platform,
    p_product_id,
    case when p_product_id = 'vip_monthly_60' then 'subscription' else 'one_time' end,
    p_purchase_token,
    p_order_id,
    p_payload
  ) returning id into v_order_id;

  if p_product_id = 'vip_monthly_60' then
    insert into public.vip_subscriptions(
      user_id, platform, product_id, purchase_token, order_id, status, started_at, expires_at, auto_renewing, raw_payload
    ) values (
      v_user_id, p_platform, p_product_id, p_purchase_token, p_order_id, 'active', now(), now() + interval '30 days', true, p_payload
    );

    update public.profiles
    set is_vip = true,
        vip_expires_at = greatest(coalesce(vip_expires_at, now()), now()) + interval '30 days',
        updated_at = now()
    where id = v_user_id;

    insert into public.entitlements(user_id, entitlement_code, source_type, source_id, starts_at, ends_at, status)
    values (v_user_id, 'vip', 'billing_order', v_order_id, now(), now() + interval '30 days', 'active');

  elsif p_product_id = 'rose_pack_s' then
    v_wallet := public.add_wallet_balance(v_user_id, 'rose', 10, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  elsif p_product_id = 'rose_pack_m' then
    v_wallet := public.add_wallet_balance(v_user_id, 'rose', 35, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  elsif p_product_id = 'rose_pack_l' then
    v_wallet := public.add_wallet_balance(v_user_id, 'rose', 80, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  elsif p_product_id = 'gift_coin_pack_s' then
    v_wallet := public.add_wallet_balance(v_user_id, 'gift_coin', 20, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  elsif p_product_id = 'gift_coin_pack_m' then
    v_wallet := public.add_wallet_balance(v_user_id, 'gift_coin', 60, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  elsif p_product_id = 'gift_coin_pack_l' then
    v_wallet := public.add_wallet_balance(v_user_id, 'gift_coin', 150, 'billing_purchase', 'billing_orders', v_order_id, p_payload);
  else
    raise exception 'unsupported product id';
  end if;

  perform public.ensure_wallet(v_user_id);

  return (
    select jsonb_build_object(
      'success', true,
      'user_id', v_user_id,
      'product_id', p_product_id,
      'wallet', jsonb_build_object(
        'rose_balance', rose_balance,
        'gift_coin_balance', gift_coin_balance
      ),
      'profile', jsonb_build_object(
        'is_vip', p.is_vip,
        'vip_expires_at', p.vip_expires_at
      )
    )
    from public.wallets w
    join public.profiles p on p.id = w.user_id
    where w.user_id = v_user_id
  );
end;
$$;

create or replace function public.rpc_sync_vip_status(p_user_id uuid default auth.uid())
returns jsonb
language plpgsql
security definer
as $$
declare
  v_active_expiry timestamptz;
begin
  select max(expires_at) into v_active_expiry
  from public.vip_subscriptions
  where user_id = p_user_id
    and status = 'active'
    and coalesce(expires_at, now()) > now();

  update public.profiles
  set is_vip = (v_active_expiry is not null),
      vip_expires_at = v_active_expiry,
      updated_at = now()
  where id = p_user_id;

  return (
    select jsonb_build_object(
      'is_vip', is_vip,
      'vip_expires_at', vip_expires_at
    ) from public.profiles where id = p_user_id
  );
end;
$$;

-- ============ Basic RLS ============
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.photos enable row level security;
alter table public.photo_unlocks enable row level security;
alter table public.diaries enable row level security;
alter table public.mood_posts enable row level security;
alter table public.mood_replies enable row level security;
alter table public.mood_gifts enable row level security;
alter table public.billing_orders enable row level security;
alter table public.vip_subscriptions enable row level security;

drop policy if exists "profiles are publicly readable" on public.profiles;
create policy "profiles are publicly readable"
on public.profiles for select
using (true);

drop policy if exists "users can update own profile" on public.profiles;
create policy "users can update own profile"
on public.profiles for update
using (auth.uid() = id);

drop policy if exists "users can view own wallet" on public.wallets;
create policy "users can view own wallet"
on public.wallets for select
using (auth.uid() = user_id);

drop policy if exists "users can view own ledger" on public.wallet_ledger;
create policy "users can view own ledger"
on public.wallet_ledger for select
using (auth.uid() = user_id);

drop policy if exists "photos readable" on public.photos;
create policy "photos readable"
on public.photos for select
using (true);

drop policy if exists "users can manage own photos" on public.photos;
create policy "users can manage own photos"
on public.photos for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "mood posts readable" on public.mood_posts;
create policy "mood posts readable"
on public.mood_posts for select
using (true);

drop policy if exists "mood replies readable" on public.mood_replies;
create policy "mood replies readable"
on public.mood_replies for select
using (true);

drop policy if exists "users can see own billing orders" on public.billing_orders;
create policy "users can see own billing orders"
on public.billing_orders for select
using (auth.uid() = user_id);

drop policy if exists "users can see own vip subscriptions" on public.vip_subscriptions;
create policy "users can see own vip subscriptions"
on public.vip_subscriptions for select
using (auth.uid() = user_id);
