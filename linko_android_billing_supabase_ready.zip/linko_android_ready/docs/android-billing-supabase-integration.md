# Android 串接順序：Billing + Supabase

## 你現在可以先跳過的
- release keystore
- AAB 簽名
- Play Console 正式上架流程

## 先做這幾步就好
1. 在 Play Console 建商品：
   - `vip_monthly_60`
   - `rose_pack_s`
   - `rose_pack_m`
   - `rose_pack_l`
   - `gift_coin_pack_s`
   - `gift_coin_pack_m`
   - `gift_coin_pack_l`

2. 在 Supabase 跑 migration：
   - `supabase/migrations/20260421_linko_schema.sql`

3. 前端接兩段：
   - 購買成功後，把 `productId + purchaseToken + orderId + payload` 傳給 `rpc_apply_google_purchase`
   - 發文 / 留言 / 解鎖相簿 改成呼叫對應 rpc

4. 等這些都通了，再去處理 Android Studio 打包

## 你之後一定要補
- Google Play Developer API 驗證
- RTDN / Webhook 同步訂閱狀態
- Storage private bucket + signed URL
- 正式聊天與認證流程
