# Google Play Billing 商品設計

這份規劃以 **Google Play Billing** 的兩種主要商品類型為基礎：
- **Subscriptions（訂閱）**：適合 `VIP60`
- **One-time products（單次型商品）**：適合 `玫瑰`、`小禮物`、活動包等數位道具

Google 官方目前將數位商品分為訂閱與單次商品，並建議以 Billing Library / Google Play Developer API 進行購買與權益處理。citeturn459902search0turn459902search2turn459902search4turn459902search14

## 1. 商品命名原則

建議所有 product id 都採用：
- 小寫
- 英數與底線
- 一旦上線後不要輕易改名

範例：

### 訂閱商品
- `vip_monthly_60`

### 單次商品
- `rose_pack_s`
- `rose_pack_m`
- `rose_pack_l`
- `gift_coin_pack_s`
- `gift_coin_pack_m`
- `gift_coin_pack_l`

## 2. 推薦商品清單

### A. VIP 訂閱
#### 產品：`vip_monthly_60`
- 類型：Subscription
- 週期：1 個月自動續訂
- 建議售價：NT$60
- 基礎權益：
  - 解鎖後 4 張私人相簿
  - 每日留言免費次數提高
  - 送花 / 小禮物成本折扣
  - 可查看更多互動資訊
  - 會員徽章 / 排名特殊樣式

#### 可加的 offers
- 新用戶首月優惠
- 回流優惠
- 季度活動折扣

---

### B. 玫瑰（貼文 / 送花主貨幣）
#### 產品：`rose_pack_s`
- 類型：One-time product
- 建議內容：10 朵玫瑰

#### 產品：`rose_pack_m`
- 類型：One-time product
- 建議內容：35 朵玫瑰

#### 產品：`rose_pack_l`
- 類型：One-time product
- 建議內容：80 朵玫瑰

用途：
- 發心情日記
- 對貼文送花
- 活動排名加權
- 特殊曝光機會

---

### C. 小禮物 / 禮物幣
#### 產品：`gift_coin_pack_s`
- 類型：One-time product
- 建議內容：20 禮物幣

#### 產品：`gift_coin_pack_m`
- 類型：One-time product
- 建議內容：60 禮物幣

#### 產品：`gift_coin_pack_l`
- 類型：One-time product
- 建議內容：150 禮物幣

用途：
- 回覆超過每日免費額度後扣除
- 贈送相簿照片禮物
- 排行榜互動分數

## 3. 商品與權益對應

| 商品 ID | 類型 | 對應權益 |
|---|---|---|
| `vip_monthly_60` | 訂閱 | 啟用 VIP、開放付費相簿、會員徽章、優惠倍率 |
| `rose_pack_s/m/l` | 單次商品 | 增加 `rose_balance` |
| `gift_coin_pack_s/m/l` | 單次商品 | 增加 `gift_coin_balance` |

## 4. 客戶端流程

Google 建議使用 Billing Library 查詢商品細節、啟動購買流程，並用後端安全驗證權益。citeturn459902search4turn459902search10turn459902search14

### 客戶端購買流程
1. App 啟動 BillingClient
2. 查詢商品詳情
3. 使用者點擊購買
4. Google Play 完成交易
5. App 將 `purchaseToken`、`productId`、`orderId` 傳給後端
6. 後端驗證成功後發放權益
7. 前端刷新錢包 / VIP 狀態

## 5. 權益發放原則

### 訂閱商品
- 不要只信任前端購買成功事件
- 以後端驗證為準
- 權益欄位：
  - `is_vip = true`
  - `vip_expires_at`
  - `vip_source = 'google_play'`

### 單次商品
- 驗證成功後一次性加值
- 建議寫入交易流水與錢包流水
- 不要讓前端自己改 balance

## 6. Play Console 建議設定

### Subscriptions
- Product ID：`vip_monthly_60`
- Base plan：`monthly`
- 自動續訂：開啟

### One-time products
建立以下商品：
- `rose_pack_s`
- `rose_pack_m`
- `rose_pack_l`
- `gift_coin_pack_s`
- `gift_coin_pack_m`
- `gift_coin_pack_l`

## 7. 後端必要驗證

Google 官方文件指出，若要安全處理購買、退款、撤銷、續訂等狀態，應搭配 Google Play Developer API 與後端系統處理。citeturn459902search6turn459902search14

後端至少要做：
- 驗證 purchase token
- 防止重複入帳
- 退款 / 撤銷時收回權益
- 訂閱到期時停用 VIP

## 8. 上線順序建議

### 第 1 階段
- 先上 `vip_monthly_60`
- 先上 `rose_pack_m`
- 先上 `gift_coin_pack_m`

### 第 2 階段
- 補齊大中小包
- 加入新手優惠
- 活動 bundle

## 9. 建議價格結構（示意）
> 真實售價請依你的定位再微調

- VIP 月費：NT$60
- 玫瑰小包：NT$30
- 玫瑰中包：NT$90
- 玫瑰大包：NT$170
- 禮物幣小包：NT$30
- 禮物幣中包：NT$90
- 禮物幣大包：NT$170

## 10. 不要做的事
- 不要用前端 localStorage 當正式權益來源
- 不要以「看廣告即視為購買」替代正式 Billing
- 不要讓 product id 在上線後頻繁變更
- 不要把退款邏輯忽略
