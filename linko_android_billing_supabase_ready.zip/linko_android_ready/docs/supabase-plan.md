# Supabase 資料表 / RPC 規劃

這份規劃以 **Supabase Auth + Postgres + Storage + RPC** 為核心。Supabase 官方支援以 Postgres Functions 建立資料庫函式，並可透過 `rpc()` 從客戶端呼叫。citeturn459902search1turn459902search3turn459902search5turn459902search15

## 1. 核心目標

你的 App 目前至少需要支援：

- 帳號 / 個人資料
- 相簿與鎖圖
- VIP 權益
- 錢包（玫瑰 / 禮物幣）
- 心情日記
- 送花 / 禮物 / 留言
- 聊天
- 交易流水
- 封鎖 / 檢舉 / 刪帳

## 2. 表格總覽

### 使用者層
- `profiles`
- `user_settings`
- `user_status_logs`
- `social_links`

### 相簿 / 內容層
- `photos`
- `photo_unlocks`
- `diaries`
- `mood_posts`
- `mood_replies`
- `mood_gifts`

### 關係 / 互動層
- `friend_requests`
- `friendships`
- `blocks`
- `reports`
- `chat_threads`
- `chat_members`
- `chat_messages`

### 金流 / 權益層
- `wallets`
- `wallet_ledger`
- `vip_subscriptions`
- `billing_orders`
- `billing_events`
- `entitlements`

## 3. 重點欄位設計

### `profiles`
每位使用者的公開主檔。

重要欄位：
- `id uuid primary key`（對應 auth.users.id）
- `display_name`
- `birth_date`
- `age_verified`
- `region`
- `height_cm`
- `weight_kg`
- `bio`
- `avatar_url`
- `is_vip`
- `vip_expires_at`
- `created_at`

### `wallets`
每位使用者一筆，存目前餘額。

欄位：
- `user_id`
- `rose_balance`
- `gift_coin_balance`
- `updated_at`

### `wallet_ledger`
所有加扣點流水都寫這裡。

欄位：
- `id`
- `user_id`
- `currency_type` (`rose` / `gift_coin`)
- `delta`
- `balance_after`
- `reason`
- `ref_table`
- `ref_id`
- `created_at`

### `photos`
用於 6 張個人照片與封面設定。

欄位：
- `id`
- `user_id`
- `storage_path`
- `sort_order`
- `is_public_preview`
- `requires_vip`
- `requires_ad_unlock`
- `is_cover`
- `created_at`

### `photo_unlocks`
記錄觀看廣告 / 臨時解鎖。

欄位：
- `id`
- `user_id`
- `photo_id`
- `unlock_type` (`ad`, `vip`, `gift`)
- `expires_at`

### `mood_posts`
心情廣場貼文。

欄位：
- `id`
- `user_id`
- `identity_mode` (`anon`, `public`)
- `content`
- `allow_replies`
- `rose_cost`
- `gift_count`
- `reply_count`
- `created_at`

### `mood_replies`
貼文留言。

欄位：
- `id`
- `post_id`
- `user_id`
- `identity_mode`
- `content`
- `gift_coin_cost`
- `created_at`

### `mood_gifts`
送花 / 禮物紀錄。

欄位：
- `id`
- `post_id`
- `from_user_id`
- `to_user_id`
- `gift_type`
- `amount`
- `created_at`

### `vip_subscriptions`
存正式訂閱狀態，不只看 `profiles.is_vip`。

欄位：
- `id`
- `user_id`
- `platform` (`google_play`)
- `product_id`
- `base_plan_id`
- `purchase_token`
- `order_id`
- `status`
- `started_at`
- `expires_at`
- `auto_renewing`
- `raw_payload jsonb`

### `billing_orders`
單次商品與訂閱購買單。

欄位：
- `id`
- `user_id`
- `platform`
- `product_id`
- `product_type`
- `purchase_token`
- `order_id`
- `purchase_state`
- `acknowledged`
- `quantity`
- `raw_payload`
- `created_at`

### `entitlements`
統一權益表，方便之後擴充。

欄位：
- `id`
- `user_id`
- `entitlement_code`
- `source_type`
- `source_id`
- `starts_at`
- `ends_at`
- `status`

## 4. RPC 建議清單

這些邏輯適合放進資料庫函式，前端只呼叫 RPC。

### 4.1 內容與錢包
- `rpc_create_mood_post(content, allow_replies, identity_mode)`
  - 檢查每日最多 3 篇
  - 檢查玫瑰是否足夠
  - 扣 1 朵玫瑰
  - 寫入 ledger
  - 建立貼文

- `rpc_create_mood_reply(post_id, content, identity_mode)`
  - 檢查是否允許回覆
  - 檢查每日免費回覆次數
  - 超額時扣 1 禮物幣
  - 建立留言
  - 更新 reply_count

- `rpc_send_mood_gift(post_id, gift_type, amount)`
  - 檢查餘額
  - 扣款
  - 建立送禮紀錄
  - 更新貼文 gift_count

### 4.2 相簿 / 權益
- `rpc_unlock_photo(photo_id, unlock_type)`
  - 若 VIP 直接通過
  - 若廣告解鎖，建立 20 分鐘 unlock
  - 若需禮物解鎖，先扣款再解鎖

- `rpc_set_cover_photo(photo_id)`
- `rpc_reorder_photos(photo_ids uuid[])`

### 4.3 關係
- `rpc_send_friend_request(target_user_id)`
- `rpc_accept_friend_request(request_id)`
- `rpc_block_user(target_user_id, reason)`
- `rpc_report_user(target_user_id, reason, detail)`

### 4.4 金流 / 權益
- `rpc_apply_google_purchase(platform, product_id, purchase_token, order_id, payload jsonb)`
  - 驗證是否已處理
  - 寫入 billing_orders
  - 發放玫瑰 / 禮物幣 / VIP
  - 建立 ledger / entitlement
  - 回傳最新 balances

- `rpc_sync_vip_status(user_id)`
  - 將 `vip_subscriptions` 與 `profiles` 同步

### 4.5 刪帳
- `rpc_request_account_deletion()`
  - 標記刪帳申請
  - 停用個人資料可見性
  - 記錄稽核事件

## 5. 權限與 RLS

### 原則
- 使用者只能讀自己的 wallet / ledger
- 公開 profile 可被別人看，但可限制敏感欄位
- 私密照片需透過 RPC 檢查權益
- billing 相關表格不要直接開放前端 insert/update

### 建議
- 對 `wallets`、`wallet_ledger`、`billing_orders`、`vip_subscriptions` 只開 select 給本人
- insert / update 走 `SECURITY DEFINER` RPC
- Storage bucket 設私有，讀圖透過 signed URL 或 RPC 控制

## 6. Realtime / Chat

聊天相關表格：
- `chat_threads`
- `chat_members`
- `chat_messages`

策略：
- thread 只有 member 可讀
- message 只有 member 可讀寫
- 用 Realtime 訂閱 `chat_messages`

## 7. 建議的 Edge Functions

Supabase 官方也支援 Edge Functions，可用於 Webhook 與第三方整合。citeturn459902search13turn459902search19

建議至少做：
- `verify-google-play-purchase`
- `google-rtnd-webhook`（接 Google Play 後端事件）
- `issue-storage-signed-url`
- `moderate-report`

## 8. 開發順序

### 第一階段
- profiles
- wallets
- wallet_ledger
- photos
- mood_posts
- mood_replies
- vip_subscriptions
- billing_orders

### 第二階段
- friendships
- chat tables
- reports
- blocks

### 第三階段
- 自動化 webhooks
- 活動 / 排行榜統計
- 管理後台

## 9. 成功標準

做完後你應該能達成：
- 使用者付款後，錢包自動增加
- VIP 到期會失效
- 發文會扣玫瑰
- 回覆超額會扣禮物幣
- 相簿能依 VIP / 解鎖狀態控權
- 所有重要加扣都有流水可查
