# Android 打包清單（Capacitor）

這包已整理成 Android 可包結構，前端放在 `www/`。

## 1. 安裝
```bash
npm install
npx cap add android
```

## 2. 同步前端到 Android
```bash
npm run copy
```

## 3. 開 Android Studio
```bash
npm run android
```

## 4. 你正式上架前還要補
- 改正式 applicationId / package name
- 接 Google Play Billing：VIP60 訂閱、玫瑰 / 禮物一次性商品
- 接正式推播、廣告與隱私揭露
- 準備隱私政策、帳號刪除、客服信箱
- 設定 release keystore，產出 AAB
