// www/docs/supabase-client-example.js
// 前端呼叫範例（示意）

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

// 建立心情貼文
export async function createMoodPost(content, allowReplies, identityMode) {
  const { data, error } = await supabase.rpc('rpc_create_mood_post', {
    p_content: content,
    p_allow_replies: allowReplies,
    p_identity_mode: identityMode,
  })
  if (error) throw error
  return data
}

// 送花
export async function sendMoodGift(postId, giftType = 'rose', amount = 1) {
  const { data, error } = await supabase.rpc('rpc_send_mood_gift', {
    p_post_id: postId,
    p_gift_type: giftType,
    p_amount: amount,
  })
  if (error) throw error
  return data
}

// 套用 Google Play 購買結果
export async function applyGooglePurchase(productId, purchaseToken, orderId, payload) {
  const { data, error } = await supabase.rpc('rpc_apply_google_purchase', {
    p_platform: 'google_play',
    p_product_id: productId,
    p_purchase_token: purchaseToken,
    p_order_id: orderId,
    p_payload: payload,
  })
  if (error) throw error
  return data
}
